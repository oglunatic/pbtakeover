<?
include 'header.php';

$result = mysql_query("SELECT * FROM `grpgusers` ORDER BY `hourlyattacks` DESC LIMIT 1");
$worked = mysql_fetch_array($result);
$hitman = new User($worked['id']);

$result = mysql_query("SELECT * FROM `cities` WHERE `id`='".$user_class->city."'");
$worked = mysql_fetch_array($result);
?>

<tr><td class="contenthead"><? echo $user_class->cityname; ?></td></tr>
<tr><td class="contentcontent"><?= $worked['description'] ?></td></tr>
<tr><td class="contenthead">Places To Go</td></tr>
<tr><td class="contentcontent">
<table width='100%'>
<tr>
	<td width='33.3%' valign='top' align=center >
	<b>Shops</b><br>
	
	<a class="citymenu" href="astore.php">Armour Store</a>
	<a class="citymenu" href="store.php">Weapon Store</a>
	<a class="citymenu" href="spendpoints.php">Point Shop</a>
	<a class="citymenu" href="pharmacy.php">Pharmacy</a>
	<a class="citymenu" href="pointdealer.php">Points Dealer</a>
	</td>

	<td width='33.3%' valign='top' align=center class="contenthead">
	<b>Town Hall</b><br>
	<a class="citymenu" href="halloffame.php">Hall Of Fame</a>
	<a class="citymenu" href='worldstats.php'>World Stats</a>
	<a class="citymenu" href='search.php'>Mobster Search</a>
	<a class="citymenu" href="citizens.php">Mobsters List</a>
	</td>
	<td width='33.3%' valign='top' align=center >
	<b>Dailies</b><br>
	<a class="citymenu" href="lottery.php">Lottery</a>
	<a class="citymenu" href="slots.php">Slot Machine</a>
	<a class="citymenu" href='5050game.php'>50/50 Game</a>
	<a class="citymenu" href="downtown.php">Search Downtown</a>
	</td>

</tr>

<tr>
	<td width='33.3%' valign='top' align=center class="contenthead">
	<b>Your Home</b><br>
	
	<a class="citymenu" href="refer.php">Referrals</a>
	<a class="citymenu" href="house.php">Move House</a>
	<a class="citymenu" href="fields.php">Manage Land</a>
	<a class="citymenu" href="bank.php">Bank</a><br>
	</td>
	<td width='33.3%' valign='top' align=center>
	<b>Marketplace</b><br>
	<a class="citymenu" href="pointmarket.php">Points Market</a>
	<a class="citymenu" href="itemmarket.php">Item Market</a>
	<a class="citymenu" href="Creditmarket.php">Credit Market</a>
		<a class="citymenu" href="jobs.php">Job Center</a>
	</td>
	<td width='33.3%' valign='top' align=center class="contenthead">
	<b>Downtown</b><br>
	<a class="citymenu" href="buydrugs.php">Shady-Looking Stranger</a>
	<a class="citymenu" href = "gang_list.php">Gang List</a>
	<a class="citymenu" href="<? echo ($user_class->gang == 0) ? "creategang.php" : "gang.php"; ?>">Your Gang</a>
	<a class="citymenu" href="realestate.php">Buy Land</a>
	</td>
</tr>
</table>

<tr><td class="contentcontent">You Currently Have <? echo $user_class->hourlyattacks; ?> Kills.</td></tr>
</td></tr>

<tr><td class="contentspacer"></td></tr><tr><td class="contenthead">Todays Top Hitman</td></tr>
<tr><td class="contentcontent">
<center>
Hitman Of The Hour <?php echo $hitman->formattedname; ?> with <?php echo prettynum($hitman->hourlyattacks); ?> kills.<br />
30 points go to the top hitman at the end of the hour!
</center>
<?
include 'footer.php';
?>