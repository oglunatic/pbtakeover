<?php
include 'header.php';
?>
<tr align=center><td class="contenthead">Credit Balance</td></tr>
<tr align=center><td class="contentcontent">
<b>1 credit = $1</b><br>
<b>Your credits balance is: <font color=green><?=$user_class->Credits;?></font></b><br></tr>

	
	</td></tr>
	<tr><td class='contenthead'>Buy Credits</tr></td>
	<tr>
	  <td class='contentcontent'>Needs to be done<br />
	    <br /><center>
	    
	
          
	
</center></td></tr>
	<tr><td class="contenthead">Stuff To Buy</td></tr>
	<tr><td class="contentcontent">
	<table width='100%'>
<tr>

	<td>Package</td>
	<td>RM Days</td>
	<td>Money</td>
	<td>Points</td>
	<td>Items</td>
	<td>Cost</td>
	<td>Buy</td>
</tr>

	
	
	</tr>
		<tr>
		<td>*30 Day Pack</td>
		<td>30</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>3 Credits</td>
		<td>
		Buy Now
</form>
		</td>
	</tr>
	<tr>
		<td>Prostitutes</td>
		<td>-</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>1 credit (They make you $2000 a night!)</td>
		<td>Buy Now
</form></td>
	</tr>
<tr>
		<td>RM Gun</td>
		<td>-</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>3 credits (Multiplier of 70!)</td>
		<td>Buy Now
</form></td>
	</tr>
	<tr>
		<td>RM Armor</td>
		<td>-</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>3 credits (Multiplier of 70!)</td>
		<td>Buy Now
</form></td>
	</tr>
<tr>
		<td>5 Awake Pills</td>
		<td>-</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>3 credits</td>
		<td>Buy Now
</form></td>
</tr>
<tr>
		<td>25 Awake Pills</td>
		<td>-</td>
		<td>-</td>

		<td>-</td>
		<td>-</td>
		<td>11 credits</td>
		<td>Buy Now
</form></td>
</tr>
	</table>
</td><tr>

<tr align=center><td class="contenthead">Points Package</td></tr>
	<tr><td class="contentcontent">
	<table width='100%'>
<tr>

	<td>Package</td>
	<td>Points</td>
	<td>Credits Required</td>
	<td>Buy Now</td>
	
</tr>

<tr>
		<td>250 Points Pack</td>
		<td>250</td>
		<td>3</td>
		<td class="citymenu">Buy</td>
		
		</tr>
		
		<tr>
		<td>1,000 Points Pack</td>
		<td>1,000</td>
		<td>10</td>
		<td class="citymenu">Buy</td>
		
		</tr>
		
		<tr>
		<td>2,000 Points Pack</td>
		<td>2,000</td>
		<td>20</td>
		<td class="citymenu">Buy</td>
		
		</tr>
		
		<tr>
		<td>5,000 Points Pack</td>
		<td>5,000</td>
		<td>30</td>
		<td class="citymenu">Buy</td>
		
		</tr>
		
		<tr>
		<td>10,000 Points Pack</td>
		<td>10,000</td>
		<td>50</td>
		<td class="citymenu">Buy</td>
		
		</tr>
		
		<tr>
		<td>25,000 Points Pack</td>
		<td>25,000</td>
		<td>100</td>
		<td class="citymenu">Buy</td>
		
		</tr>

</table>


<tr><td class="contenthead">Read This Or Die</td></tr>
<tr><td class="contentcontent">
	If you have any questions, PM me (Kraze).<br>
	Before you buy you must be clear of the following things:<br><br>
	1. No refunds.<br>
	2. You can still be banned for breaking the rules whether you have donated or not.
</td></tr>
<?php
include 'footer.php';
?>


if (isset($_GET['buy'])) {

$resultnew = mysql_query("SELECT * from `items` WHERE `id` = '".$_GET['buy']."' and `buyable` = '1'");
$worked = mysql_fetch_array($resultnew);
 if($worked['id'] != ""){
    if ($user_class->money >= $worked['cost']){
    $newmoney = $user_class->money - $worked['cost'];
    $newsql = mysql_query("UPDATE `grpgusers` SET `money` = '".$newmoney."' WHERE `id`= '".$user_class->id."'");
	Give_Item($_GET['buy'], $user_class->id);//give the user their item they bought
    echo Message("You have purchased a ".$worked['itemname']);
    } else {
    echo Message("You do not have enough money to buy a ".$worked['itemname']);
    }
  } else {
  echo Message("That isn't a real item.");
  }
}