<?php
include('dbcon.php');
include('classes.php');

if(!isset($_GET['code']) || $_GET['code'] != '55555')
    exit;
$result = mysql_query("SELECT * FROM grpgusers ORDER BY hourlyattacks  DESC LIMIT 1");
$fetch = mysql_fetch_array($result);
$usr = new User($fetch['id']);
$newpoints = $usr->points + 30;
Send_Event($usr->id, "You won mobster of the hour with ".$fetch['hourlyattacks']." Kills! You have been awarder 30 points!.");
$result = mysql_query("UPDATE grpgusers SET points = ".$newpoints." WHERE id = '".$usr->id."'");
 $reset = mysql_query("UPDATE grpgusers SET hourlyattacks = '0'");
$query = mysql_query("UPDATE `dailyevents` SET `tophitman` = '<li>Yesterdays top hitman was ".$usr->formattedname." with ".prettynum($fetch['hourlyattacks'])." kills.</li><li>The player was granted 10 points for their hard work!</li>', `tophitmanid` = '".$usr->id."'"); 
    
?>