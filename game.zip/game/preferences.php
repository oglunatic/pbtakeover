<?include 'header.php';
if (isset($_POST['submit'])) {
$avatar = $_POST["avatar"];  
$quote = $_POST["quote"];  
$profileSIG = $_POST["profileSIG"];  
$profilemusic = $_POST["profilemusic"];  
if (!isset($message)){
$result= mysql_query("UPDATE `grpgusers` SET `profileSIG`='".$profileSIG."',`avatar`='".$avatar  ."', `profilemusic`='".$profilemusic."', `quote`='".$quote."' WHERE `id`='".$user_class->id."'");
echo Message('Your preferences have been saved.');
die();  }}?>
<?if (isset($message)) {echo Message($message);}?>
<tr><td class="contenthead">Account Preferences</td></tr>
<tr><td class="contentcontent"><form name='login' method='post'>  
<table width='100%' border='0' align='center' cellpadding='0' cellspacing='0'>  
<td><font size='2' face='verdana'>    
<tr><tr>  <td height='28' ><font size='2' face='verdana'>Quote</font></td>  
<td><font size='2' face='verdana'>    
<input type='text' name='quote' value='<?= $user_class->quote ?>'></font></td></tr>  
<td></td>  <td><font size='2' face='verdana'>    
<input type='submit' name='submit' value='Save Preferences'></font></td></tr>
<tr><tr>  <td height='28' ><font size='2' face='verdana'>Profile Sig</font></td>  
<td><font size='2' face='verdana'><input type='text' name='profileSIG' value='<?= $user_class->profileSIG ?>'></font></td>
</tr><tr>  <td height='28' ><font size='2' face='verdana'>Profile Music [size="1"]*<font color=red>Youtube URL Code ( x7Cvzj_2GzM )</font>*[/size]</td>  
<td><font size='2' face='verdana'><input type='text' name='profilemusic' value='<?= $user_class->profilemusic ?>'></font></td></tr>  
<td></td>  <td><font size='2' face='verdana'><input type='submit' name='submit' value='Save Preferences'></font></td></tr></table></form>
<?include 'footer.php';?>