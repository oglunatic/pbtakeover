<?
include 'header.php';
?>
<tr><td class='contenthead'>Newspaper</td></tr>
<tr><td class='contentcontent'>
If you are interested in writing an article for the Newspaper, keep these things in mind:<br />-Articles must be at least a pargraph long.<br />-Articles can be about real events in GRPG (such as a new feature being added, or a strong gang) or just about life in Generica (So I was walking down the road with my gramma yesterday, and out of nowhere this guy walks up and steals her purse from her!)<br />-Articles may be rejected for any reason at all.<br />-As soon as you submit an article, you no longer have any rights over that article, it becomes the sole property of Brandon Werner (me)<br />-You will get your name credited at the top of the article<br /><br />To send an article, either PM it to Publius with the subject "Newspaper Article", or send an email to myneocorp@gmail.com with the subject "Newspaper Article".
</td></tr>
<tr><td class='contentcontent'>
<iframe 
src ="newspaper/index.php" width="100%" height="400px"></iframe>
</td></tr>
<?
include 'footer.php';
?>