<?
$conn = mysql_connect("localhost","silentm2_1","michaelbraden");
$db = mysql_select_db("silentm2_m2");
?>