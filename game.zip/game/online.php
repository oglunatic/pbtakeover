<?php

include(__DIR__ . '/header.php');

echo '<tr align=center><td class="contenthead">Users Online In The Last 15 Minutes</td></tr>
<tr><td class="contentcontent">
 <table width=75% cellspacing=1> 
  <tr style="background:gray"> 
   <th>User</th> <th>Level</th> <th>Money</th> <th>Last Active</th>
  </tr>';
 $result = mysql_query("SELECT * FROM `grpgusers` ORDER BY `lastactive` DESC");
 while($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
  $secondsago = time()-$line['lastactive'];
  if ($secondsago<=900) {
   $user_online = new User($line['id']);
   echo '<tr>
    <td>'.$user_online->formattedname.'</td>
    <td>'.number_format($user_online->level).'</td>
    <td>$'.number_format($user_online->money).'</td>
    <td>'.howlongago($user_online->lastactive).'</td>
    </tr>';
  } 
 }
 echo '</table>';
 echo '</td></tr>'; 
 include(__DIR__. '/footer.php'); 
?>