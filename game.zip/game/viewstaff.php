<?
include 'header.php';
?>
<tr><td class="contenthead">Town Hall (Staff)</td></tr>
<tr><td class="contentcontent">
<a href="profiles.php?id=1">Publius</a> - GRPG Owner and Programmer<br>
<a href="profiles.php?id=2">senatorhades</a> - Forum Moderator
</td></tr>
<?
include 'footer.php';
?>