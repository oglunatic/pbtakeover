<?php
include 'header.php';
?>
<tr><td class="contenthead">Vote</td></tr>
<tr><td class="contentcontent">
<a href=http://www.toprpgames.com/vote.php?idno=1262&id=<? echo $user_class->id; ?>>Vote!</a> <----- Click this one if you want to recieve the rewards.<br><br><script language="JavaScript" src="http://www.toprpgames.com/rankingad.php?id=1262&style=2"></script>
</td></tr>
<?php
include 'footer.php';
?>