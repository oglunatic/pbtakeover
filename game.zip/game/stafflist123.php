<?php
include "header.php";


{
$staff[$r['userid']]=$r;
}
print "<b>Admins</b><br />
<table width=75% cellspacing=1 class='table'> <tr style='background:gray'><th>User</th> <th>Level</th> <th>Money</th> <th>Last Seen</th> <th>Status</th> </tr>";

foreach($staff as  $r)
{
if($r['user_level']==1)
{
if($r['laston'] >= time()-15*60) { $on="<font color=green><b>Online</b></font>"; } else { $on="<font color=red><b>Offline</b></font>"; }
print "<tr> <td><a href='viewuser.php?u={$r['userid']}'>{$r['username']}</a> [{$r['userid']}]</td> <td>{$r['level']}</td> <td>\${$r['money']}</td> <td>".date('F j, Y, g:i:s a',$r['laston'])."</td> <td>$on</td> </tr>";
}
}
print "</table>";
print "<b>Game Moderator</b><br />
<table width=75% cellspacing=1 class='table'> <tr style='background:gray'><th>User</th> <th>Level</th> <th>Money</th> <th>Last Seen</th> <th>Status</th> </tr>";
foreach($staff as  $r)
{
if($r['user_level']==2)
{
if($r['laston'] >= time()-15*60) { $on="<font color=green><b>Online</b></font>"; } else { $on="<font color=red><b>Offline</b></font>"; }
print "<tr> <td><a href='viewuser.php?u={$r['userid']}'>{$r['username']}</a> [{$r['userid']}]</td> <td>{$r['level']}</td> <td>\${$r['money']}</td> <td>".date('F j, Y, g:i:s a',$r['laston'])."</td> <td>$on</td> </tr>";
}
}
print "</table>";
print "<b>Game moderators</b><br />
<table width=75% cellspacing=1 class='table'> <tr style='background:gray'><th>User</th> <th>Level</th> <th>Money</th> <th>Last Seen</th> <th>Status</th> </tr>";
foreach($staff as  $r)
{
if($r['user_level']==3)
{
if($r['laston'] >= time()-15*60) { $on="<font color=green><b>Online</b></font>"; } else { $on="<font color=red><b>Offline</b></font>"; }
print "<tr> <td><a href='viewuser.php?u={$r['userid']}'>{$r['username']}</a> [{$r['userid']}]</td> <td>{$r['level']}</td> <td>\${$r['money']}</td> <td>".date('F j, Y, g:i:s a',$r['laston'])."</td> <td>$on</td> </tr>";
}
}
print "</table>";


?>

