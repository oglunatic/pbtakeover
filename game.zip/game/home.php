<?
include 'nliheader.php';
?>
    <tr><td class="contenthead">.: Welcome To SilentMafia</td></tr>
	<tr>
    <td class="contentcontent">
		<table width='100%' height='100%' cellpadding='5' cellspacing='2'>
		<tr>
	
			<td width='120' align='center'></td>
			<td align='center'>Welcome to SilentMafia. SilentMafia is a free mafia-style browser based RPG, which means you don't have to download anything at all, you play it all in your web browser, and best of all you don't have to pay for anything. In SilentMafia, you choose your own path. Whether you want to train your stats and become the strongest player, or become the president and actually effect and change aspects of the game, it is entirely up to you.
			</td>
		</tr>
		</table>
	</td></tr>
	</td></tr>


    <tr><td class="contenthead">.: Screenshots</td></tr>
    <tr><td class="contentcontent">
		<img src="images/screen1.png" /><br /><img src="images/screen2.png" />
	</td></tr>
	
	<tr align=center><td class="contenthead">.: Most Experienced :.</td></tr>
	<tr><td class="contentcontent">
<table width='100%'>
<tr>
	<td><strong>Rank</strong></td>
	<td><strong>Mobster</strong></td>
	<td><strong>Level</strong></td>
</tr>
<?
$view = ($_GET['view'] != "") ? $_GET['view'] : 'exp';


$result = mysql_query("SELECT * FROM `grpgusers` ORDER BY `".$view."` DESC LIMIT 5");
$rank = 0;
while($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$rank++;
	$user_hall = new User($line['id']);
	?>
	<tr>
			<td><?= $rank ?></td>
			<td><?= $user_hall->formattedname ?></td>
			<td>Level: <?= $user_hall->level ?></td>
	
	</tr>
	
	<?

}
?>
</td></tr>
</table>
<tr align=center><td class="contenthead">.: Most Recent Players :.</td></tr>
<tr><td class="contentcontent">
<table width='100%'>
<tr>
	<td><strong>Rank</strong></td>
	<td><strong>Mobster</strong></td>
	<td><strong>Time</strong></td>
</tr>
<?
$view = ($_GET['view'] != "") ? $_GET['view'] : 'lastactive';


$result = mysql_query("SELECT * FROM `grpgusers` ORDER BY `".$view."` DESC LIMIT 5");
$rank = 0;
while($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$rank++;
	$user_hall = new User($line['id']);
	$user_online = new User($line['id'])
	?>
	<tr>
			<td><?= $rank ?></td>
			<td><?= $user_hall->formattedname ?></td>
			<td><?= howlongago($user_online->lastactive) ?></td>
	
	</tr>
	
	<?

}
?>
</td></tr>
</table>
<tr align=center><td class="contenthead">.: Most Powerful :.</td></tr>
	<tr><td class="contentcontent">
<table width='100%'>
<tr>
	<td><strong>Rank</strong></td>
	<td><strong>Mobster</strong></td>
	<td><strong>Level</strong></td>
</tr>
<?
$totalatt = ($_GET['view'] != "") ? $_GET['view'] : 'strength';


$result = mysql_query("SELECT * FROM `grpgusers` ORDER BY `".$totalatt."` DESC LIMIT 5");
$rank = 0;
while($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$rank++;
	$user_hall = new User($line['id']);
	?>
	<tr>
			<td><?= $rank ?></td>
			<td><?= $user_hall->formattedname ?></td>
			<td>Level: <?= $user_hall->level ?></td>
	
	</tr>
	
	<?

}
?>
</td></tr>
</table>
<?

	
	
	
	
	
	include 'nlifooter.php';
	?>