<?php
 
 include(__DIR__.'/header.php');
 
if ($user_class->admin != 1) {
  echo Message("You are not authorized to be here.");
  include(__DIR__.'/footer.php');
  die();
}
 
?>
 
<tr><td class="contenthead">Staff Logs</td></tr>
<tr><td class="contentcontent">
    <?php
    $result = mysql_query("SELECT * FROM `events` ORDER BY id DESC LIMIT 50");
    echo "<table width=100%>
                <tr align='center'>
                        <td class=contenthead><b>ID</b></td>
                        <td class=contenthead><b>Time</b></td>
                        <td class=contenthead><b>To</b></td>
                        <td class=contenthead><b>Text</b></td>
                </tr>";
    while($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
        $usr = new User($line['to']);
        $to= Get_ID($line['to']);
        echo "<tr align=center>
                <td class=contentcontent>".$line['id']."</td>
                <td class=contentcontent>".date(F." ".d.", ".Y." ".g.":".i.":".sa,$line['timesent'])."</td>
                <td class=contentcontent><a href=profiles.php?id=".$line['to'].">".$usr->formattedname."</a></td>
                <td class=contentcontent>".$line['text']."</td>
              </tr>";
    }
    echo "</table>";
    include(__DIR__.'/footer.php');
?>