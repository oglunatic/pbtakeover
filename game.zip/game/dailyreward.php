<?php
include_once(DIRNAME(__FILE__) . '/header.php');
 
if (isset($_GET['claim'])){
if($user_class->dailyreward == 1) {
$newpointstwo = $user_class->dailyreward - 1;
$resulttwo = mysql_query("UPDATE `grpgusers` SET `dailyreward`='".$newpointstwo."' WHERE `id`='".$_SESSION['id']."'");
$newpoints = $user_class->points + 50;
$result = mysql_query("UPDATE `grpgusers` SET `points`='".$newpoints."' WHERE `id`='".$_SESSION['id']."'");
$newpointsthree = $user_class->money + 50000;
$resultthree = mysql_query("UPDATE `grpgusers` SET `money`='".$newpointsthree."' WHERE `id`='".$_SESSION['id']."'");
echo '
<tr><td class="contenthead">Daily Reward</td></tr>
<tr><td class="contentcontent">
<center>Thanks for playing today. Here take 50 points and $50,000 bucks!</center>';
die ();
} else {
echo '
<tr><td class="contenthead">Daily Reward</td></tr>
<tr><td class="contentcontent">
<center>You have already recieved your daily grease, come back tomorrow.</center>';
die ();
}
}
?>
<tr><td class="contenthead">Daily Reward</td></tr>
<tr><td class="contentcontent">
<table width="100%">
<tr>
 <td>Click <a href="dailyreward.php?claim" target="_blank">here</a> to claim your daily reward.</td>
</tr>
</table>