<?php
 
include(__DIR__.'/header.php');
 
if(isset($_POST['newannounce'])) {
$_POST['newmessage'] = isset($_POST['newmessage']) && strlen($_POST['newmessage']) > 0 ? mysql_real_escape_string($_POST['newmessage']) : null; 
    if(empty($_POST['newmessage'])) {
        echo Message('You did not enter a valid announcement.'); 
        include(__DIR__.'/footer.php'); 
        exit;
    } 
    else {   
        echo Message('You have posted your announcement.');      
        mysql_query("INSERT INTO `announcements` (`id`, `poster`, `message`, `postime`)"." VALUES (NULL, '$user_class->id', '".$_POST['newmessage']."', '".time()."')");  
        mysql_query("UPDATE `grpgusers` SET `announcement` = `announcement` + 1");
    }
}
?>
 
<tr><td class='contenthead'>Announcements</td></tr>
<tr><td class='contentcontent'>
    <table width=100% cellspacing='1'>  
        <tr style='background:gray'> 
            <th>Poster</th>  
            <th>Message</th> 
            <th>time</th> 
        </tr>
        <?php 
        if($user_class->announcement > 0) {
            $update = mysql_query("UPDATE `grpgusers` SET `announcement` = 0 WHERE `id` = '".$user_class->id."'");
        }
        $res = mysql_query("SELECT * FROM `announcements` ORDER BY `postime`"); 
        while($row = mysql_fetch_array($res)) {
            $poster = new User($row['poster']); 
            echo "<tr>
                    <td>".$poster->formattedname."</td>
                    <td width='50%'>".$row['message']."</td>
                    <td>".date('H:i:s d/m/Y', $row['postime'])."</td> 
                  </tr>";
        }
        echo "</table>";
        ?>
</td></tr>
 
<?php
if($user_class->admin) {
?>
<tr><td class='contenthead'>Add Announcement</td></tr>
<tr><td class='contentcontent'>
    <form method='post'>
        <table width='100%'>
            <tr>
                <th>Message</th>
                <td><textarea name='newmessage' rows='10' cols='60'></textarea></td>
            </tr>
            <tr>
                <td><input type='submit' name='newannounce' value='Post' /></td>
            </tr>
        </table>
    </form>
</td></tr>
<?php
}
include(__DIR__.'/footer.php');
?>
