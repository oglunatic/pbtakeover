<?php 
    session_start();
     
    if ($user_class->admin == 3) { 
    echo "
    <div class='content'>
    <h3>Staff Panel</h3>
    <div style='text-align:center;'>
    You have no access to the Staff Panel. 
    </div></div>"; die();
    }
     
    if ($user_class->admin == 2) { 
    echo "
    <div class='content'>
    <h3>Staff Panel</h3>
    <div style='text-align:center;'>
    You have no access to the Staff Panel. 
    </div></div>"; die();
    }
     
    if ($user_class->admin == 12) { 
    echo "
    <div class='content'>
    <h3>Staff Panel</h3>
    <div style='text-align:center;'>
    You have no access to the Staff Panel. 
    </div></div>"; die();
    }
 
    if (!isset($_SESSION['id'])){
    include('home.php'); die();
    }
 
    include (DIRNAME(__FILE__) . '/dbcon.php');
    include (DIRNAME(__FILE__) . '/classes.php');
    include (DIRNAME(__FILE__) . '/updates.php');
    include (DIRNAME(__FILE__) . '/parser.php');
 
    function microtime_float()
    {
    $time = microtime();
    return (double)substr( $time, 11 ) + (double)substr( $time, 0, 8 );
    }
 
    microtime_float();
    $starttime = microtime_float();
 
    $user_class = new User($_SESSION['id']);
 
    $time = date(F." ".d.", ".Y." ".g.":".i.":".sa,time());
    $result = mysql_query("UPDATE `users` SET `lastactive` = '".time()."', `ip` = '".$_SERVER['REMOTE_ADDR']."' WHERE `id`='".$_SESSION['id']."'");
 
    function callback($buffer){
    $user_class = new User($_SESSION['id']);
 
    $check_contact = mysql_query("SELECT * FROM `contact_messages` WHERE `viewed`='1'");
    $num_mails = mysql_num_rows($check_contact);
    if($num_mails != 0) { $new_contacts = "<span class='newNotify'>NEW</span>"; } else if ($num_mails < 1) { $new_contacts = "-"; }
    $contactmessages = "[".$new_contacts."]";
 
    $check_staffapps = mysql_query("SELECT * FROM `staff_apps` WHERE `viewed` = '1'");
    $num_mails = mysql_num_rows($check_staffapps);
    if($num_mails != 0) { $new_apps = "<span class='newNotify'>NEW</span>"; } else if ($num_mails < 1) { $new_apps = "-"; }
    $staffapps = "[".$new_apps."]";
 
    $out = $buffer;
    $out = str_replace("<!_-money-_!>", number_format($user_class->money), $out);
    $out = str_replace("<!_-bank-_!>", number_format($user_class->bank), $out);
    $out = str_replace("<!_-formhp-_!>", $user_class->formattedhp, $out);
    $out = str_replace("<!_-hpperc-_!>", $user_class->hppercent, $out);
    $out = str_replace("<!_-formenergy-_!>", $user_class->formattedenergy, $out);
    $out = str_replace("<!_-energyperc-_!>", $user_class->energypercent, $out);
    $out = str_replace("<!_-formstamina-_!>", $user_class->formattedstamina, $out);
    $out = str_replace("<!_-staminaperc-_!>", $user_class->staminapercent, $out);
    $out = str_replace("<!_-formnerve-_!>", $user_class->formattednerve, $out);
    $out = str_replace("<!_-nerveperc-_!>", $user_class->nervepercent, $out);
    $out = str_replace("<!_-formexp-_!>", $user_class->formattedexp, $out);
    $out = str_replace("<!_-expperc-_!>", $user_class->exppercent, $out);
    $out = str_replace("<!_-points-_!>", number_format($user_class->points), $out);
    $out = str_replace("<!_-level-_!>", $user_class->level, $out);
    $out = str_replace("<!_-hospital-_!>", $hospital, $out);
    $out = str_replace("<!_-jail-_!>", $jail, $out);
    $out = str_replace("<!_-contactmessages-_!>", $contactmessages, $out);
    $out = str_replace("<!_-staffapps-_!>", $staffapps, $out);
    $out = str_replace("<!_-effects-_!>", $effects, $out);
    $out = str_replace("<!_-cityname-_!>", $user_class->cityname, $out);
    return $out;
    }
 
    ob_start("callback");
    define("DATE_FORMAT","d-m-Y H:i:s");
    define("LOG_FILE","ip.php");
    $userIp    = ( isset($_SERVER['REMOTE_ADDR'])
                      && ($_SERVER['REMOTE_ADDR'] != ""))
                  ? $_SERVER['REMOTE_ADDR']     : "Unknown";
 
    $refferer  = ( isset($_SERVER['HTTP_REFERER'])
                     && ($_SERVER['HTTP_REFERER'] != ""))
                 ? $_SERVER['HTTP_REFERER']    : "Unknown";
 
    $uri       = ( isset($_SERVER['REQUEST_URI'])
                      && ($_SERVER['REQUEST_URI'] != ""))
                  ? $_SERVER['REQUEST_URI']     : "Unknown";
 
    $hostName   = gethostbyaddr($userIp);
 
    $logEntry = " <tr>
        <td width='35%'><center>$time</center></td>
        <td width='35%'><center><a href=http://whatismyipaddress.com/ip/$userIp>$userIp</a></center></td>
        <td width='35%'><center>$user_class->formattedname</center></td>
        <td width='35%'><center>$refferer</center></td>
    </tr>\n";
 
    if (!file_exists(LOG_FILE)) {
        $logFile = fopen(LOG_FILE,"w");
        fwrite($logFile);
    }
    else {
        $logFile = fopen(LOG_FILE,"a");
    }
 
    fwrite($logFile,$logEntry);
    fclose($logFile);
 
    if(!get_magic_quotes_gpc())
    {
    $_GET = array_map('mysql_real_escape_string', $_GET);
    $_POST = array_map('mysql_real_escape_string', $_POST);
    $_COOKIE = array_map('mysql_real_escape_string', $_COOKIE);
    } else {
    $_GET = array_map('stripslashes', $_GET);
    $_POST = array_map('stripslashes', $_POST);
    $_COOKIE = array_map('stripslashes', $_COOKIE);
    $_GET = array_map('mysql_real_escape_string', $_GET);
    $_POST = array_map('mysql_real_escape_string', $_POST);
    $_COOKIE = array_map('mysql_real_escape_string', $_COOKIE);
    }
?>   
     
    <html>
    <head>
    <title>SilentMafia - Staff Panel</title>
    <link rel="shortcut icon" href="/images/favicon.ico?" type="image/x-icon" />
    <link rel="stylesheet" href="style.css" media="screen,projection" type="text/css" />
    <link rel="stylesheet" href="css/lightbox.css" type="text/css" />
    <script src="scripts/lightbox.js" type="text/javascript"></script>
    <style type="text/css" media="screen,print">
    /* Disable properties specified in the imported CSS file */
    .menu a {
        border:none;
        font-weight:normal;
    }
    /* Actual menu CSS starts here */
    .menu,
    .menu ul {
        margin:0;
        padding:0;
        list-style:none;
    }
    .menu {width:170px;}
    .menu li {
        display:block;
        margin:0;
        margin-bottom:1px;
        padding: 0 0 0 0px;
        background-repeat: no-repeat;
        background-position: 8px 8px;
        list-style: none;
    }
    .menu a {
        display:block;
        line-height: 20px;
        color:#FFF;
        padding-left:0px;
        font-weight: bold;
        background:#282828;
        text-decoration:none;
    }
    .menu a:hover,
    .menu a:focus,
    .menu ul li { padding-left:0px;}
    .menu ul a {color:#000; background:#FFF; background-repeat: no-repeat; background-position: 8px 8px;}
    .menu ul a:hover {background:#606060;}
    .hidden {display:none;}
    </style>
    </head>
    <body>
    <script type='text/javascript' src='/javascript/wz_tooltip.js'></script>
     
    <div class="wrapper">
 
    <div class="header">
    <img style="float:left" src="/images/ingamebanner.png" />
 
    <div class="stats">
    <table>
    <tr>
        <td colspan="2">[<? echo $user_class->id; ?>] <a href="profiles.php?id=<? echo $user_class->id; ?>" class="userlink" rel="<? echo $user_class->id; ?>"><?php echo $user_class->formattedname; ?></a></td>
        <td>HP:</td>
        <td width="145px">
    <table width="100%" height="5px" style="border: solid 1px #660000">
    <tr height="5px">
        <td width="100%" style="background-color: #ec0303;" title="<!_-formhp-_!>"></td>
        <td width="<!_-hpperc-_!>%" style="background-color: #343434;" title="<!_-formhp-_!>"><td>
            </div><td>
      </tr>
                    </table>
 
                    </td>
                    <td><span style='color:#999'><!_-hpperc-_!>%</span></td>
                </tr>
                <tr>
                    <td width="55px">Level:</td>
                    <td width="170px"><!_-level-_!></td>
                    <td>Energy:</td>
 
                    <td width="145px">
                    <table width="100%" height="5px" style="border: solid 1px #660000">
                        <tr height="5px">
                        <td width="100%" style="background-color: #ec0303;" title="<!_-formenergy-_!>"></td>
                        <td width="<!_-energyperc-_!>%" style="background-color: #343434;" title="<!_-formenergy-_!>"><td>
            </div><td>
                        </tr>
                    </table>
                    </td>
                    <td><span style='color:#999'><!_-energyperc-_!>%</span></td>
 
                </tr>
                <tr>
                    <td width="55px">Money:</td>
                    <td width="170px">$<!_-money-_!></td>
                    <td>Stamina:</td>
                    <td width="145px">
 
                    <table width="100%" height="5px" style="border: solid 1px #660000">
                        <tr height="5px">
                        <td width="100%" style="background-color: #ec0303;" title="<!_-formstamina-_!>"></td>
                        <td width="<!_-staminaperc-_!>%" style="background-color: #343434;" title="<!_-formstamina-_!>"><td>
            </div></td>
                        </tr>
                    </table>
                    </td>
                    <td><span style='color:#999'><!_-staminaperc-_!>%</span></td>
 
                </tr>
                <tr>
                    <td width="55px">Bank:</td>
                    <td width="170px">$<!_-bank-_!></td>
                    <td>Nerve:</td>
                    <td width="145px">
                    <table width="100%" height="5px" style="border: solid 1px #660000">
                        <tr height="5px">
                        <td width="100%" style="background-color: #ec0303;" title="<!_-formnerve-_!>"></td>
                        <td width="<!_-nerveperc-_!>%" style="background-color: #343434;" title="<!_-formnerve-_!>"><td>
            </div></td>
 
      </tr>
                    </table>
                    </td>
                    <td><span style='color:#999'><!_-nerveperc-_!>%</span></td>
                </tr>
 
                <tr>
                    <td width="55px">Points:</td>
                    <td width="170px"><!_-points-_!> [<a href = "spendpoints.php">use</a>] [<a href = "rmstore.php">buy</a>]</td>
                    <td>EXP:</td>
                    <td width="145px">
 
                    <table width="100%" height="5px" style="border: solid 1px #660000">
                        <tr height="5px">
                        <td width="<!_-expperc-_!>%" style="background-color: #ec0303;" title="<!_-formexp-_!>"></td>
                        <td width="100%" style="background-color: #343434;" title="<!_-formexp-_!>"><td>
                       </div></td>
      </tr>
                    </table>
                    </td>
                    <td><span style='color:#999'><!_-expperc-_!>%</span></td>
                </tr>
 
                </tr>
            </table>
        </div><!-- end .stats -->
 
        <div class="newsbar">
            <span><a href="refer.php">Refer For Points</a> | <a href="upgrade.php">Upgrade Account</a> | <a href='dailyreward.php'>Daily Reward</a></span><? echo $time; ?>  |  Day Update: 12:00am
        </div>
        </div><!-- end .header  -->
     
    <div class='left'>
    <ul class="menu">
    <li><a href=".">Users</a>
        <ul>
            <li><a href='staff_panel.php?action=mailban'>  Mailban Player</a></li>
            <li><a href='staff_panel.php?action=revokemail'>&nb  sp;Revoke Mailban</a></li>
            <li><a href='staff_panel.php?action=forumban'>  ;Forum Ban Player</a></li>
            <li><a href='staff_panel.php?action=revokeforum'>&n  bsp;Revoke Forum Ban</a></li>
            <li><a href='staff_panel.php?action=freeze'>F  reeze Player</a></li>
            <li><a href='staff_panel.php?action=revokefreeze'>&  nbsp;Revoke Freeze</a></li>
            <li><a href='staff_panel.php?action=playernotes'>&n  bsp;View Player Notes</a></li>
        </ul>
    </li>
    <li><a href=".">Logs</a>
        <ul>
            <li><a href='staff_panel.php?action=attacklog'>&nbs  p;Attack Logs</a></li>
            <li><a href='staff_panel.php?action=moneylog'>  ;Money Xfer Logs</a></li>
            <li><a href='staff_panel.php?action=pointlog'>  ;Points Xfer Logs</a></li>
            <li><a href='staff_panel.php?action=itemlog'>  Item Xfer Logs</a></li>
                        <li><a href='staff_panel.php?action=maillog'>  Mail Logs</a></li>
        </ul>
    </li>
    <li><a href="." id="collapsed">Other Tools</a>
        <ul>
            <li><a href='staff_panel.php?action=contactmessages'>&nbs  p;Contact Messages <!_-contactmessages-_!></a></li>
            <li><a href='staff_panel.php?action=supporttickets'>  ;Support Tickets <!_-support-_!></a></li>
            <li><a href='staff_panel.php?action=staffnotes'>&nb  sp;View Staff Notes</a></li>
            <li><a href='staff_panel.php?action=addnote'>  Add Staff Note</a></li>
            <li><a href='staff_panel.php?action=ipsearch'>  ;Ip Search</a></li>
            <li><a href='home.php'>Back To Game</a></li>
        </ul>
    </li>
    </ul>
    </div>
     
<?php
     
    $_GET['action'] = isset($_GET['action']) && ctype_alpha($_GET['action']) ? trim($_GET['action']) : 'staff_index';
     
    switch($_GET['action'])
    {
    case 'mailban' : mail_ban(); break;
    case 'submitmailban' : submit_mailban(); break;
    case 'revokemail' : revoke_mailban(); break;
    case 'submitmailrevoke' : submit_mailrevoke(); break;
    case 'forumban' : forum_ban(); break;
    case 'submitforumban' : submit_forumban(); break;
    case 'revokeforum' : revoke_forumban(); break;
    case 'submitforumrevoke' : submit_forumrevoke(); break;
    case 'freeze' : freeze_player(); break;
    case 'submitfreeze' : submit_freeze(); break;
    case 'revokefreeze' : revoke_freeze(); break;
    case 'submitfreezerevoke' : submit_freezerevoke(); break;
    case 'ipsearch' : ip_search(); break;
    case 'ipsubmit' : ipsearch_submit(); break;
    case 'contactmessages' : contact_messages(); break;
    case 'attacklog' : attack_logs(); break; 
    case 'moneylog' : money_logs(); break;
    case 'pointlog' : point_logs(); break;
    case 'itemlog' : item_logs(); break;
    case 'maillog' : mail_logs(); break;
    case 'submitmaillog' : submit_maillog(); break;
    case 'staffnotes' : staff_notes(); break;
    case 'addnote' : add_note(); break;
    case 'submitnote' : submit_note(); break;
    case 'supporttickets' : support_tickets(); break;
    default : staff_index(); break;
    }
     
    function staff_index()
    {
    echo "
    <div class='content'>
    <h3>Staff Panel</h3>
 
    <table width='100%'>
    <tr>
        <td colspan='2'><h4>Last 3 Staff Notes</h4></td>
    </tr>";
     
    $result = mysql_query("SELECT * FROM `staffnotes` ORDER BY `timesent` DESC LIMIT 3");
        while ($line = mysql_fetch_array($result)){
        $staff_notes = new User($line['user']);
        $notes = mysql_num_rows($result);
    echo "
    <tr>
        <td class='forumSide' align='center' valign='top'>".date(d." ".M.", ".y." ".g.":".i."".a,$line['timesent'])."  ".$staff_notes->formattedname."</td>
        <td class='forumPost' valign='top'>".$line['note']."</td>
    </tr>";
    }
     
    if($notes < 1){
    echo "
    <table width='100%'>
    <tr>
        <td colspan='2'><div style='text-align:center;'><i>There are no staff notes.</i></div></td>
    </tr>
    </table>";
    }
   }include(__DIR__. '/footer.php'); 
?>
        
       