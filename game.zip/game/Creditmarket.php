<?php
include 'header.php';

if ($_POST['buyCredits']){

	$result = mysql_query("SELECT * FROM `Creditsmarket` WHERE `id`='".$_POST['Credits_id']."'");
    $worked = mysql_fetch_array($result);
    $price = $worked['price'];
    $amount = $worked['amount'];
 	$totalcost = $price * $_POST['amount'];
 	$newCreditsinmarket = $amount - $_POST['amount'];
 	$user_Credits = new User($worked['owner']);

	if ($worked['owner'] == $user_class->id) {
		echo Message("You have taken ".$_POST['amount']." Credits off the market.");
		$newCredits = $user_class->Credits + $_POST['amount'];;
		$result = mysql_query("UPDATE `grpgusers` SET `Credits` = '".$newCredits."' WHERE `id`='".$user_class->id."'");
		$user_class = new User($_SESSION['id']);
			if ($newCreditsinmarket == 0){
				$result = mysql_query("DELETE FROM `Creditsmarket` WHERE `id`='".$worked['id']."'");
			} else {
				$result = mysql_query("UPDATE `Creditsmarket` SET `amount` = '".$newCreditsinmarket."' WHERE `id`='".$worked['id']."'");
		}
	include 'footer.php';
	die();
	}
 	if($_POST['amount'] > $amount){
		echo Message("They are not selling that many Credits.");
	}
	if($_POST['amount'] < 1){
		echo Message("Please enter a valid amount of Credits to buy.");
	}
	if ($totalcost > $user_class->money){
		echo Message("You don't have enough money.");
	}
	if($_POST['amount'] >= 1 && $_POST['amount'] <= $amount && $totalcost <= $user_class->money){
		echo Message("You have bought ".$_POST['amount']." Credits for $".$totalcost);
		$newCredits = $user_class->Credits + $_POST['amount'];
		$newmoney = $user_class->money - $totalcost;
		$result = mysql_query("UPDATE `grpgusers` SET `money` = '".$newmoney."', `Credits` = '".$newCredits."' WHERE `id`='".$user_class->id."'");
		$newmoney = $user_Credits->money + $totalcost;
		$result = mysql_query("UPDATE `grpgusers` SET `money` = '".$newmoney."' WHERE `id`='".$user_Credits->id."'");
		$user_class = new User($_SESSION['id']);
			if ($newCreditsinmarket == 0){
				$result = mysql_query("DELETE FROM `Creditsmarket` WHERE `id`='".$worked['id']."'");
			} else {
				$result = mysql_query("UPDATE `Creditsmarket` SET `amount` = '".$newCreditsinmarket."' WHERE `id`='".$worked['id']."'");
			}
	}
}

if ($_POST['addCredits']){
 	if($_POST['amount'] > $user_class->Credits){
		echo Message("You don't have that many Credits.");
	}
	if($_POST['amount'] < 1){
		echo Message("Please enter a valid amount of Credits.");
	}
	if($_POST['price'] < 1){
		echo Message("Please enter a valid amount of money.");
	}
	if($_POST['amount'] >= 1 && $_POST['amount'] <= $user_class->Credits && $_POST['price'] >= 1){
		echo Message("You have added ".$_POST['amount']." Credits to the market a price of $".$_POST['price']." per Credit.");
		$result= mysql_query("INSERT INTO `Creditsmarket` (owner, amount, price)"."VALUES ('$user_class->id', '$_POST[amount]', '$_POST[price]')");
		$newCredits = $user_class->Credits - $_POST['amount'];
		$result = mysql_query("UPDATE `grpgusers` SET `Credits` = '".$newCredits."' WHERE `id`='".$user_class->id."'");
		$user_class = new User($_SESSION['id']);
	}
}

?>
<tr><td class="contenthead">Credit Market</td></tr>
<tr><td class="contentcontent">
Use this form to add Credits to the Credits market.<br><br>
<form method='post'>
<table align="center">
<tr>
<td>Amount of Credits</td><td>&nbsp;&nbsp;<input type='text' name='amount' size='10' maxlength='20' value='<? echo $user_class->Credits ?>'></td>
</tr>
<tr>
<td>Price per Credit</td><td>$<input type='text' name='price' size='10' maxlength='20'></td>
<tr><td align="center" colspan="2"><input type='submit' name='addCredits' value='Add Credits'></form></td>
</tr></table>
</td></tr>
<tr><td class="contentcontent">
<?php
$result = mysql_query("SELECT * FROM `Creditsmarket` ORDER BY `price` DESC");
while($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	$user_Credits = new User($line['owner']);
	if ($user_Credits->id == $user_class->id){
		$submittext = "Remove Credits";
	} else {
		$submittext = "Buy";
	}
	echo "<form method='post'>";
	echo $user_Credits->formattedname." - ".$line['amount']." Credits for $".$line['price']." per Credit <input type='text' name='amount' size='3' maxlength='20' value='".$line['amount']."'><input type='hidden' name='Credits_id' value='".$line['id']."'><input type='submit' name='buyCredits' value='".$submittext."'></form><br>";
}
?>
</td></tr>
<?php
include 'footer.php';
?>