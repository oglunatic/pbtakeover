<?
 
include 'header.php';
 
$result = mysql_query("SELECT * FROM `grpgusers` ORDER BY `id` ASC");
 
$totalmobsters = mysql_num_rows($result);
 
$result2 = mysql_query("SELECT * FROM `grpgusers` WHERE `rmdays`!='0'");
 
$totalrm = mysql_num_rows($result2);
 
 
$result = mysql_query("SELECT SUM(bank) FROM `grpgusers`") or trigger_error(mysql_error(),E_USER_ERROR);
$bank = mysql_result($result,0);
 
$result = mysql_query("SELECT SUM(money) FROM `grpgusers`") or trigger_error(mysql_error(),E_USER_ERROR);
$money = mysql_result($result,0);
 
$result = mysql_query("SELECT SUM(points) FROM `grpgusers`") or trigger_error(mysql_error(),E_USER_ERROR);
$points = mysql_result($result,0);
  
  
?>
<link href="style.css" rel="stylesheet" type="text/css" />
 
 
<tr>
  <td class=""><table width="100%" border="0" class="contenthead">
    <tr>
    <td align="center"><b>Mobsters Stats</b></td>
    </tr>
  </table>
    <table width="100%" border="0" class="contentcontent">
    <tr>
        <td><span class="textl"><b>total Mobsters:
            <?= $totalmobsters ?>
        </b></span></td>
        <td></td>
    </tr>
    <tr>
        
    </tr>
    <tr>
        <td><span class="textl"><b>Respected Mobsters:
            <?= $totalrm ?>
        </b></span></td>
        <td></td>
    </tr>
    <tr>
        <td><b>total Freinds: <? echo prettynum($freinds) ?></b></td>
        <td></td>
    </tr>
    <tr>
        <td><b>total enemys: <? echo prettynum($enemy) ?></b></td>
        <td></td>
    </tr>
    </table>
<table width="100%" border="0" class="contenthead">
  <tr>
    <td height="1" align="center"><span class="textl"><b>Money..points...gangbanks</b></span></td>
  </tr>
</table></td></tr>
 
<tr>
  <td class="contentcontent">
 
 
 
<table width='100%' cellpadding='4' cellspacing='0' class="contentcontent">
 
<tr>
  <td colspan="2" align="center" class='textl'></td>
  <td class='textr'></td>
</tr>
<tr>
  <td class='textl'><b>total money <? echo prettynum($money) ?></b></td>
  <td width="45%" class='textl'><b>toal gang money banked <? echo prettynum($gangmoney) ?></b></td>
  <td width="1%" class='textr'></td>
</tr>
<tr>
  <td class='textl'>total points <b><? echo prettynum($points) ?></b></td>
  <td class='textl'><b>total gang points banked <? echo prettynum($gangpoints) ?></b></td>
  <td class='textr'></td>
</tr>
<tr>
  <td height="26" class='textl'><b>total banekd <? echo prettynum($bank) ?></b></td>
  <td class='textl'><b>total gang wars won (soon)</b></td>
  <td class='textr'></td>
</tr>
<tr>
  <td height="26" class='textl'><b>total points banked <? echo prettynum($pbank) ?></b></td>
  <td class='textl'><b>total gang wars lost (soon)</b></td>
  <td class='textr'></td>
</tr>
<tr>
 
    <td width='54%' height="26" class='textl'></td>
 
    <td class='textl'></td>
 
    <td class='textr'></td>
 
</tr>
 
</table>
 
</td></tr>
 
<?
 
include 'footer.php';
 
?>