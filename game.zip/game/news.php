<?
include 'header.php';
 
 
//Set News to 0
$result = mysql_query("UPDATE `grpgusers` SET `news` = '0' WHERE `id` = '".$user_class->id."'");
//End
 
//Pages Stuff
 
// find out how many rows are in the table 
$result = mysql_query("SELECT COUNT(*) FROM `ftopics` WHERE `sectionid` = '1'");
$r = mysql_fetch_row($result);
$numrows = $r[0];
 
// number of rows to show per page
$rowsperpage = 15;
// find out total pages
$totalpages = ceil($numrows / $rowsperpage);
if ($totalpages <= 0) {
$totalpages = 1;
} else {
$totalpages = ceil($numrows / $rowsperpage);
}
 
// get the current page or set a default
if (isset($_GET['page']) && is_numeric($_GET['page'])) {
   // cast var as int
   $currentpage = (int) $_GET['page'];
} else {
   // default page num
   $currentpage = 1;
} // end if
 
// if current page is greater than total pages...
if ($currentpage > $totalpages) {
   // set current page to last page
   $currentpage = $totalpages;
} // end if
 
// if current page is less than first page...
if ($currentpage < 1) {
   // set current page to first page
   $currentpage = 1;
} // end if
 
// the offset of the list, based on current page 
$offset = ($currentpage - 1) * $rowsperpage;
 
$result = mysql_query("SELECT * from `ftopics` WHERE `sectionid` = '1' ORDER BY `timesent` DESC LIMIT $offset, $rowsperpage");
while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) { 
 
$reply_class = new User($row['playerid']);
if ($reply_class->avatar != "") {
$avatar = $reply_class->avatar;
} else {
$avatar = "/images/no-avatar.png";
}
 
$rcomments = mysql_query("SELECT * from `freplies` WHERE `topicid` = '".$row['forumid']."'");
$comments = mysql_num_rows($rcomments);
 
?>
<tr><td class="contentspacer"></td></tr><tr><td class="contenthead"><?php echo $row['subject'] ?></td></tr>
<tr><td class="contentcontent">
<table width="100%" cellpadding="5" cellspacing="0" style="border:1px solid #222222; table-layout:fixed; width:100%; word-wrap:break-word;">
<tr>
<td width="20%" bgcolor="#030303" align="center"><?php echo date(d." ".F." ".Y.", ".g.":".ia,$row['timesent']) ?><a href="profiles.php?id=<?php echo $reply_class->id; ?>"><img src="<?php echo $avatar; ?>" height="100" width="100" style="border:1px solid #666666" /></a><?php echo $reply_class->formattedname; ?></td>
<td width="80%" bgcolor="#090909" valign="top"><?php echo BBCodeParse(strip_tags($row['body'])); ?></td>
</tr>
</table>
<table width="100%">
<tr><td></td></tr>
<tr>
<td align="right"><a href="viewpost.php?id=<?php echo $row['forumid']; ?>">Comments [<?php echo $comments; ?>]</a></td>
</tr>
</table>
</td></tr>
<?php
}
 
echo '<tr><td class="contentspacer"></td></tr><tr><td class="contenthead">Pagination</td></tr>
<tr><td class="contentcontent">';
 
/******  build the pagination links ******/
// range of num links to show
$range = 5;
 
// if not on page 1, don't show back links
if ($currentpage > 1) {
   // show << link to go back to page 1
   echo " <a href='{$_SERVER['PHP_SELF']}?id={$_GET['id']}&page=1'><<</a> ";
} // end if 
 
// loop to show links to range of pages around current page
for ($x = ($currentpage - $range); $x < (($currentpage + $range) + 1); $x++) {
   // if it's a valid page number...
   if (($x > 0) && ($x <= $totalpages)) {
      // if we're on current page...
      if ($x == $currentpage) {
         // 'highlight' it but don't make a link
         echo " [<b>$x</b>] ";
      // if not current page...
      } else {
         // make it a link
         echo " <a href='{$_SERVER['PHP_SELF']}?id={$_GET['id']}&page=$x'>$x</a> ";
      } // end else
   } // end if 
} // end for
                  
// if not on last page, show forward and last page links        
if ($currentpage < $totalpages) {
   // echo forward link for lastpage
   echo " <a href='{$_SERVER['PHP_SELF']}?id={$_GET['id']}&page=$totalpages'>>></a> ";
} // end if
/****** end build pagination links ******/
 
echo '</td></tr>';
 
include("footer.php");
?>