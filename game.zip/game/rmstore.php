<?
include "header.php";
if ($_GET['buy'] == "thirtyrm"){
     if($user_class->Credits > 2) {
     $newcredit = $user_class->Credits - 3;
     $time = time();
        $creditbalance = 30 + $user_class->rmdays;
$result = mysql_query("UPDATE `grpgusers` SET `money` = money + 10000, `points` = points + 50, `rmdays` = '".$creditbalance."', `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
             $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '30 Day RM', '3')");
echo Message("You spent 3 Credits for the 30 Day Respected Mobster Status.");
Send_Event($user_class->id, "You have been credited with your 30 Day Respected Mobster Status, $10,000 and 50 points.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "sixtyrm"){
    if($user_class->Credits > 5) {
     $newcredit = $user_class->Credits - 6;
    $time = time();
         $creditbalance = 60 + $user_class->rmdays;
     $result = mysql_query("UPDATE `grpgusers` SET `money` = money + 25000, `points` = points + 120, `rmdays` = '".$creditbalance."', `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
        $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '60 Day RM', '6')");
      
echo Message("You spent 6 Credits for the 60 Day Respected Mobster Status.");
         Send_Event($user_class->id, "You have been credited with your 60 Day Respected Mobster Status, $25,000 and 120 points.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "nintyrm"){
    if($user_class->Credits > 8) {
     $newcredit = $user_class->Credits - 9;
    $time = time();
         $creditbalance = 90 + $user_class->rmdays;
     $result = mysql_query("UPDATE `grpgusers` SET `money` = money + 75000, `points` = points + 300, `rmdays` = '".$creditbalance."', `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
        $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '90 Day RM', '9')");
      
echo Message("You spent 9 Credits for the 90 Day Respected Mobster Status.");
         Send_Event($user_class->id, "You have been credited with your 90 Day Respected Mobster Status, $75,000 and 300 points..".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "oneawakepill"){
    if($user_class->Credits > 0) {
     $newcredit = $user_class->Credits - 1;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
        $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '1 Awake Pill', '1')");
        Give_Item(42, $user_class->id);//give the user their item they bought
     echo Message("You spent 1 credit for an Awake pill.");
         Send_Event($user_class->id, "You have been credited with your Awake pill.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "fiveawakepill"){
    if($user_class->Credits > 4) {
     $newcredit = $user_class->Credits - 5;
    $time = time();
        $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '5 Awake Pills', '5')");
     $result = mysql_query("UPDATE `grpgusers` SET `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
 
     echo Message("You spent 5 Credits for 5 Awake pills.");
         Send_Event($user_class->id, "You have been credited with your Awake pills.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "tenawakepill"){
    if($user_class->Credits > 9) {
     $newcredit = $user_class->Credits - 10;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
        $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '10 Awake Pills', '10')");
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought 
           Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
     echo Message("You spent 10 Credits for 10 Awake pills.");
         Send_Event($user_class->id, "You have been credited with your Awake pills.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "fifteenawakepill"){
    if($user_class->Credits > 14) {
     $newcredit = $user_class->Credits - 15;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
        $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '15 Awake Pills', '15')");
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought 
           Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
           Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
        Give_Item(42, $user_class->id);//give the user their item they bought
     echo Message("You spent 15 Credits for 15 Awake pills.");
         Send_Event($user_class->id, "You have been credited with your Awake pills.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "rmpack"){
    if($user_class->Credits > 23) {
     $newcredit = $user_class->Credits - 24;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
        $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '10 rm packs', '10')");
        Give_Item(16, $user_class->id);//give the user their item they bought
        Give_Item(16, $user_class->id);//give the user their item they bought
        Give_Item(16, $user_class->id);//give the user their item they bought
        Give_Item(16, $user_class->id);//give the user their item they bought
        Give_Item(16, $user_class->id);//give the user their item they bought 
           Give_Item(16, $user_class->id);//give the user their item they bought
        Give_Item(16, $user_class->id);//give the user their item they bought
        Give_Item(16, $user_class->id);//give the user their item they bought
        Give_Item(16, $user_class->id);//give the user their item they bought
        Give_Item(16, $user_class->id);//give the user their item they bought
     echo Message("You spent 24 Credits for 10 RM Packs.");
         Send_Event($user_class->id, "You have been credited with your 10 RM Packs.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "pointpack1"){
    if($user_class->Credits > 2) {
     $newcredit = $user_class->Credits - 3;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `points` = points + 250, `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
             $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '250 Points', '3')");
echo Message("You spent 3 Credits for the 250 points pack.");
         Send_Event($user_class->id, "You have been credited with your 250 points pack.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "pointpack2"){
    if($user_class->Credits > 9) {
     $newcredit = $user_class->Credits - 10;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `points` = points + 1000, `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
        $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '1,000 Points Pack', '10')");
 echo Message("You spent 10 Credits for the 1,000 points pack.");
         Send_Event($user_class->id, "You have been credited with your 1,000 points pack.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "pointpack3"){
    if($user_class->Credits > 19) {
     $newcredit = $user_class->Credits - 20;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `points` = points + 2200, `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
     $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '2,200 Points Pack', '20')");
echo Message("You spent 10 Credits for the 2,200 points pack.");
         Send_Event($user_class->id, "You have been credited with your 2,200 points pack.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "pointpack5"){
    if($user_class->Credits > 29) {
     $newcredit = $user_class->Credits - 30;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `points` = points + 5000, `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
     $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '5,000 Points Pack', '30')");
     echo Message("You spent 30 Credits for the 5000 points pack.");
         Send_Event($user_class->id, "You have been credited with your 5000 points pack.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "pointpack6"){
    if($user_class->Credits > 54) {
     $newcredit = $user_class->Credits - 55;
    $time = time();
     $result = mysql_query("UPDATE `grpgusers` SET `points` = points + 10000, `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
     $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '10,000 Points Pack', '55')");
     echo Message("You spent 55 Credits for the 10,000 points pack.");
         Send_Event($user_class->id, "You have been credited with your 10,000 points pack.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
if ($_GET['buy'] == "pointpack7"){
    if($user_class->Credits > 119) {
     $newcredit = $user_class->Credits - 120;
     $result = mysql_query("UPDATE `grpgusers` SET `points` = points + 25000, `Credits`='".$newcredit."' WHERE `id`='".$_SESSION['id']."'");
     $result = mysql_query("INSERT INTO `spentCredits` (timestamp, spender, spent, amount)"."VALUES ('".$time."', '".$user_class->id."', '25,000 Points Pack', '120')");
     echo Message("You spent 120 Credits for the 25,000 points pack.");
         Send_Event($user_class->id, "You have been credited with your 25,000 points pack.".$user_class->formattedusername);
    } else {
        echo Message("You don't have enough Credits.You can buy some at the upgrade store");
    }
}
 
 
 
?>
<tr><td class='contenthead'>Your Wallet</td></tr>
<tr><td class="contentcontent">   
<center>1 credit= $1</center>
<center>Your Credits balance is: <font color=green><b><?php echo $user_class->Credits; ?></center></font></b></td></tr>
<tr><td class="contenthead">Please note!</td></tr>
<tr><td class="contentcontent">   
<center>If you want to  donate, message Kraze, ID 1- Page not finished.</center>
</td></tr>
<tr><td class="contenthead">Upgrade Store</td></tr>
<tr><td class="contentcontent">   <a href="/rmstoreoffers.php"><font size=3>Offers Here Click Me</font></a>
 <center>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target=_blank class="style8">
    <select name=amount style="background-color:#ffffff; font: 10pt verdana; border: 1px solid #000000;">
      <option value=1>1 Credit = $1.00</option>
      <option value=3>3 Credits = $3.00</option>
      <option value=6>6 Credits = $6.00</option>
      <option value=9>9 Credits = $9.00</option>
      <option value=15>15 Credits = $15.00</option>
      <option value=20>20 Credits = $20.00</option>
      <option value=30>30 Credits = $30.00</option>
      <option value=120>120 Credits = $120.00</option>
      <option value=200>200 Credits = $200.00</option>
    </select>
    <input type="hidden" name="cmd" value="_xclick">
    <input type="hidden" name="currency_code" value="USD">
    <input type="hidden" name=custom value=<?= $user_class->id ?>>
    <input type="hidden" name="business" value="N/A">
    <input type="hidden" name="item_number" value="1">
    <input type="hidden" name="item_name" value="N/A Credits for <?= $user_class->username ?>">
<input type="hidden" name="notify_url" value="/ipn_Credits.php">
    <input type="submit" class="button" border="0" value="Continue" onClick="confirmbuy()" name="submit" alt=""></form></td>
</td></tr>
<tr><td class="contenthead">Upgrade Store</td></tr>
<tr><td class="contentcontent">
<center> <img src="/rmupgrade.png"width=400 height=100";<center>  
<table width='100%'> 
<tr> 
    <td>&nbsp;</td> 
    <td>Free Member</td> 
    <td>RM (30 days)</td> 
    <td>RM (60 days)</td> 
    <td>RM (90 days)</td> 
</tr> 
<tr> 
    <td>Money Bonus (One Time)</td> 
    <td>-</td> 
    <td>$10,000</td> 
    <td>$25,000</td> 
    <td>$75,000</td> 
</tr> 
<tr> 
    <td>Points Bonus (One Time)</td> 
    <td>-</td> 
    <td>50</td> 
    <td>125</td> 
    <td>300</td> 
</tr> 
<tr> 
    <td>Access to RM Horse Races</td> 
    <td>No</td> 
    <td>Yes</td> 
    <td>Yes</td> 
    <td>Yes</td> 
</tr> 
<tr> 
    <td>Talk to the Drug Dealer</td> 
    <td>No</td> 
    <td>Yes</td> 
    <td>Yes</td> 
    <td>Yes</td> 
</tr>
<tr> 
    <td>Energy Regain (Per 5 Mins)</td> 
    <td>10%</td> 
    <td>20%</td> 
    <td>20%</td> 
    <td>20%</td> 
</tr> 
<tr> 
    <td>Bank Interest</td> 
    <td>1%</td> 
    <td>3%</td> 
    <td>3%</td> 
    <td>3%</td> 
</tr> 
<tr> 
    <td>Max Items</td> 
    <td>100</td> 
    <td>250</td> 
    <td>250</td> 
    <td>250</td> 
</tr> 
<tr> 
    <td>Credits Needed</td> 
    <td>Free</td> 
    <td><b>3</b></td> 
    <td><b>6</b></td> 
    <td><b>9</b></td> 
</tr> 
<tr> 
    <td>Buy Now!</td> 
    <td>Free</td> 
    <td><a href="/rmstore.php?buy=thirtyrm"><b>Buy</b></a></td> 
    <td><a href="/rmstore.php?buy=sixtyrm"><b>Buy</b></a></td> 
    <td><a href="/rmstore.php?buy=nintyrm"><b>Buy</b></td> 
</tr>
<tr> 
    <td>&nbsp;</td> 
    <td>&nbsp;</td> 
     
      
</tr> 
</table>
 
</td></tr>
    <tr><td class="contenthead">The Respected Mobsters Packs</td></tr>
    <tr><td class="contentcontent">
    <table width="100%">
<tbody><tr>
    <td>Package</td>    
    <td>Points</td>
    <td>Items</td>
    <td>Credits Required</td>
    <td>Buy</td>
</tr>
 
     
        <tr>
        <td>10 RM Packs</td>
        <td>-</td>               
                 
        <td>RM Packs [x10]</td>
        <td>24</td>
         
        <td align="center"><a href="/rmstore.php?buy=rmpack"><b>Buy</b></td>
 
    </tr>
        <tr>
        <td>1 Awake Pill</td>
        <td>-</td>
 
        <td>Awake Pill [x1]</td>
        <td>1</td>
         
        <td align="center"><a href="/rmstore.php?buy=oneawakepill"><b>Buy</b></td>
 
    </tr>
     
     
    <tr>
        <td>5 Awake Pills</td>
        <td>-</td>
        <td>Awake Pill [x5]</td>
 
        <td>5</td>
         
        <td align="center"><a href="/rmstore.php?buy=fiveawakepill"><b>Buy</b></td>
    </tr>
     
     
    <tr>
 
        <td>10 Awake Pills</td>
        <td>-</td>
        <td>Awake Pill [x10]</td>
        <td>10</td>
         
 
        <td align="center"><a href="/rmstore.php?buy=tenawakepill"><b>Buy</b></td>
    </tr>
     
     
    <tr>
        <td>15 Awake Pills</td>
        <td>-</td>
        <td>Awake Pill [x15]</td>
 
        <td>15</td>
         
        <td align="center"><a href="/rmstore.php?buy=fifteenawakepill"><b>Buy</b></td>
    </tr>
     
     
    <tr>
 
        <td>250 Points Pack</td>
        <td>250</td>
        <td></td>
        <td>3</td>
         
        <td align="center"><a href="/rmstore.php?buy=pointpack1"><b>Buy</b></td>
    </tr>
     
     
    <tr>
        <td>1,000 Points Pack</td>
        <td>1,000</td>
        <td>-</td>
 
        <td>10</td>
         
        <td align="center"><a href="/rmstore.php?buy=pointpack2"><b>Buy</b></td>
    </tr>
     
     
    <tr>
 
        <td>2,200 Points Pack</td>
        <td>2,200</td>
        <td>-</td>
        <td>20</td>
         
        <td align="center"><a href="/rmstore.php?buy=pointpack3"><b>Buy</b></td>
    </tr>
     
     
    </form>
    <tr>
        <td>5,000 Points Pack</td>
        <td>5,000</td>
        <td>-</td>
 
        <td>40</td>
         
        <td align="center"><a href="/rmstore.php?buy=pointpack5"><b>Buy</b></td>
    </tr>
     
     
    <tr>
 
        <td>10,000 Points Pack</td>
        <td>10,000</td>
        <td>-</td>
        <td>75</td>
         
        <td align="center"><a href="/rmstore.php?buy=pointpack6"><b>Buy</b></td>
    </tr>
     
     
    <tr>
        <td>25,000 Points Pack</td>
        <td>25,000</td>
        <td>-</td>
 
        <td>120</td>
     
        <td align="center"><a href="/rmstore.php?buy=pointpack7"><b>Buy</b></td>
    </tr>
     
 
    <tr>
 
 
    </table>
</td><tr>
<tr><td class="contenthead">Rules Please Read:</td></tr>
<tr><td class="contentcontent">
    By donating to N/A you are agreeing on the following terms:
    1. If you didn't get your pack you brought please contact an admin or a member of staff with your transaction id and email address used to buy the package.
    2. Just because you have bought a package from us doesn't mean you can go around breaking rules. So be warned, you can still get banned for breaking them.
    3. No refunds will be given as the game runs on donations.
    4. If your trying to <b>refund</b> your money through PayPal, we will ban you account.
</td></tr>
<?php
include 'footer.php';
?>