<?

/*
$color[0] = "#333";
$color[1] = "#ddd";
$color[2] = "#444";
$color[3] = "#ffffff";
$color[4] = "#111";
$color[5] = "#000000";
$color[6] = "#666666";
$color[7] = "#FFFF00";
$color[8] = "#1E1E1E";
$color[9] = "#ffcc00";
$color[10] = "#4d75a0";
$color[11] = "#7d9fc4";
$color[12] = "#FFFF33";
*/
session_start();

if (!isset($_SESSION['id'])){

	include('home.php');

	die();

}

include 'dbcon.php';

include 'classes.php';

include 'updates.php';

if ($_GET['action'] == "logout"){

	session_destroy();

	die('You have been logged out.<meta http-equiv="refresh" content="0;url=index.php">');

}



function microtime_float()

{

 $time = microtime();

 return (double)substr( $time, 11 ) + (double)substr( $time, 0, 8 );

}



microtime_float();

$starttime = microtime_float();



if (Is_User_Banned($_SESSION['id']) == 1){

	echo "<h1>" . Why_Is_User_Banned($_SESSION['id']) . "</h1>";

	die();

}

$user_class = new User($_SESSION['id']);

// get style info
$cresult = mysql_query("SELECT `value` FROM `styles` WHERE `style`='".$user_class->style."'");
$i = 0;
while($line = mysql_fetch_array($cresult, MYSQL_ASSOC)) {
	$color[$i] = $line['value'];
	$i++;
}
//get style info

$result = mysql_query("SELECT * FROM `serverconfig`");
$worked = mysql_fetch_array($result);
if($worked['serverdown'] != "" && $user_class->admin != 1){
	die("<h1><font color='red'>SERVER DOWN, BE PATIENT WILL BE BACK UP SOON<br><br>".$worked['serverdown']."</font></h1>");
}

$time = date(F." ".d.", ".Y." ".g.":".i.":".sa,time());

$result = mysql_query("UPDATE `grpgusers` SET `lastactive` = '".time()."', `ip` = '".$_SERVER['REMOTE_ADDR']."' WHERE `id`='".$_SESSION['id']."'");


function callback($buffer){ 
  $user_class = new User($_SESSION['id']);

  $checkhosp = mysql_query("SELECT * FROM `grpgusers` WHERE `hospital`!='0'");
  $nummsgs = mysql_num_rows($checkhosp);
  $hospital = "[".$nummsgs."]";
  
  $checkjail = mysql_query("SELECT * FROM `grpgusers` WHERE `jail`!='0'");
  $nummsgs = mysql_num_rows($checkjail);
  $jail = "[".$nummsgs."]";
  
  $checkmail = mysql_query("SELECT * FROM `pms` WHERE `to`='$user_class->username' and `viewed`='1'");
  $nummsgs = mysql_num_rows($checkmail);
  $mail = "[".$nummsgs."]";
  
  $checkmail = mysql_query("SELECT * FROM `events` WHERE `to`='$user_class->id' and `viewed` = '1'");
  $numevents = mysql_num_rows($checkmail);
  $events = "[".$numevents."]";
  
	$result = mysql_query("SELECT * from `effects` WHERE `userid`='".$user_class->id."'");
	if (mysql_num_rows($result) != 0){
		$effects = '<div class="headbox">Current Effects</div>';
		while($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
	         $effects .= '<a class="leftmenu" href="effects.php?view='.$line['effect'].'">'.$line['effect']." (".floor($line['timeleft']).")".'</a></ul><br />';
		}
	}

  $out = $buffer;
  $out = str_replace("<!_-money-_!>", $user_class->money, $out);
  $out = str_replace("<!_-formhp-_!>", $user_class->formattedhp, $out);
  $out = str_replace("<!_-hpperc-_!>", $user_class->hppercent, $out);
  $out = str_replace("<!_-formenergy-_!>", $user_class->formattedenergy, $out);
  $out = str_replace("<!_-energyperc-_!>", $user_class->energypercent, $out);
  $out = str_replace("<!_-formawake-_!>", $user_class->formattedawake, $out);
  $out = str_replace("<!_-formexp-_!>", $user_class->formattedexp, $out);
  $out = str_replace("<!_-awakeperc-_!>", $user_class->awakepercent, $out);
  $out = str_replace("<!_-formnerve-_!>", $user_class->formattednerve, $out);
  $out = str_replace("<!_-nerveperc-_!>", $user_class->nervepercent, $out);
  $out = str_replace("<!_-points-_!>", $user_class->points, $out);
  $out = str_replace("<!_-level-_!>", $user_class->level, $out);
  $out = str_replace("<!_-hospital-_!>", $hospital, $out);
  $out = str_replace("<!_-jail-_!>", $jail, $out);
  $out = str_replace("<!_-mail-_!>", $mail, $out);
  $out = str_replace("<!_-events-_!>", $events, $out);
  $out = str_replace("<!_-effects-_!>", $effects, $out);
  $out = str_replace("<!_-cityname-_!>", $user_class->cityname, $out);
  
  return $out;
}

ob_start("callback");


?>

  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html>

<head>

<title>SilentMafia</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<link href="style.css" rel="stylesheet" type="text/css">
<link rel="icon" type="image/ico" href="http://www.silentmafia.co.uk/favicon.ico"/>

</head>
<body>
<table style="background-color: rgba(0,0,0,0.5);" border="0" cellspacing="0" cellpadding="0" width="100%" >
<tr>
  <td>
	<!--<img src="images/forconor[1]-1.png" />-->

	  <table class="topbar">
	<tr>
		<td>
			> Server Time: <? echo $time; ?> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <a href="refer.php">Refer For Points</a> | <a href="rmstore.php">Upgrade Account</a> | <a href="dailyreward.php">Daily Reward!</a>		</td>
	</tr>
	</table> 
</td>
</tr>
<tr>
    <td colspan="3" class="pos1" height="55" valign="middle">
      <div class="topbox">
	<table width='800'>
        <tr>
          <td width="50%"><img src="images/logo.gif" /> </td>
          <div class='user_info'>
          <td width="30%"> [<? echo $user_class->id; ?>] <a href='profiles.php?id=<? echo $_SESSION['id'] ?>'><? echo $user_class->formattedname; ?></a><br />
            Level:
            <!_-level-_!>
            <br />
            Money: $
            <!_-money-_!>
            <a href = "bank.php">[Bank]</a> <br />
            Points:
            <!_-points-_!>
            <a href = "spendpoints.php">[Use]</a> <a href = "sendpoints.php">[Send]</a><br />
             Credits:
             <?=$user_class->Credits;?>
            <a href = "rmstore.php">[Use]</a> <a href = "sendCredits.php">[Send]</a></td>
            </div>
             <td width="20%"> <a>HP:</a>
            <div class="bar_a" title="<!_-formhp-_!>">
              <div class="bar_b" style="height:8px;width: <!_-hpperc-_!>%;" title="<!_-formhp-_!>">&nbsp;</div>
              <a> EXP:</a>
            <div class="bar_a" title="<!_-formexp-_!>">
              <div class="bar_b" style="height:8px;width: <!_-exppercent-_!>%;" title="<!_-formexp-_!>">&nbsp;</div>
           
            <a title = 'Refill this bar' href='spendpoints.php?spend=energy'>Energy</a>:
            <div class="bar_a" title="<!_-formenergy-_!>">
              <div class="bar_b" style="height:8px;width: <!_-energyperc-_!>%;" title="<!_-formenergy-_!>">&nbsp;</div>
            </div>
            <a title = 'Refill this bar' href='spendpoints.php?spend=awake'>Awake</a>:
            <div class="bar_a" title="<!_-formawake-_!>">
              <div class="bar_b" style="height:8px;width: <!_-awakeperc-_!>%;" title="<!_-formawake-_!>">&nbsp;</div>
            </div>
            <a title = 'Refill this bar' href='spendpoints.php?spend=nerve'>Nerve</a>:
            <div class="bar_a" title="<!_-formnerve-_!>">
              <div class="bar_b" style="height:8px;width: <!_-nerveperc-_!>%;" title="<!_-formnerve-_!>">&nbsp;</div>
            </div></td>
        </tr>
      </table>
	  </div>
    </td>
  </tr>
 
<tr><td>
	<table class="topbar">
	<tr>
		<td>
		<?
		$result = mysql_query("SELECT * from `serverconfig`");
        $worked = mysql_fetch_array($result);
		$messagetext = str_replace("^","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",$worked['messagefromadmin']);
		echo "<marquee scrollamount='3'>".$messagetext."</marquee>";
		?>
		</td>
	</tr>
	</table>
<table class="topbar">
	<tr>
		<td>
<?php
if($user_class->announcement > 0)
{
?>
    <a class="leftmenu" href="announcement.php">Announcement [<?php echo $user_class->announcement; ?>]</a>
<?php 
}
else
{ 
?>
    <a class="leftmenu" href="announcement.php">Announcement [0]</a>|
<?php
}
if($user_class->chatroom > 0)
{
?>
    <a class="leftmenu" href="chatroom.php">Chatroom [<?php echo $user_class->chatroom; ?>]</a>
<?php 
}
else
{ 
?>
    <a class="leftmenu" href="chatroom.php">chatroom [0]</a>
<?php
}
?>
		</center></span></h2>
		</td>
	</tr>
</table>  

  <tr>
    <td>	
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="top" width="150">
		  <div style="height:7px;"></div>
		  	<div>
			
		 <?= ($user_class->admin == 1) ? '
		 <div class="headbox">Control Panel</div>
			  <a class="leftmenu" href="control.php">Marquee/Maintenance</a>
			  <a class="leftmenu" href="control.php?page=rmoptions">RM Options</a>
			  <a class="leftmenu" href="control.php?page=setplayerstatus">Player Options</a>
			  <a class="leftmenu" href="massmail.php">Mass Mail</a>
			  <a class="leftmenu" href="control.php?page=referrals">Manage Referrals</a>
			  <a class="leftmenu" href="stafflogs.php">Event Logs</a>
			  <a class="leftmenu" href="maillogs.php">Mail Logs</a>
		</div><br>
		 <div class="headbox">Game Modification</div>
			  <a class="leftmenu" href="control.php?page=crimes">Manage Crimes</a>
			  <a class="leftmenu" href="control.php?page=cities">Manage Cities</a>
			  <a class="leftmenu" href="control.php?page=jobs">Manage Jobs</a>
			  <a class="leftmenu" href="control.php?page=playeritems">Manage Items</a>
		  </div>
		  <br />
		 ' : "" ?>	

                 <?= ($user_class->admin == 3) ? '
		 <div class="headbox">Moderator Panel</div>
			  <a class="leftmenu" href="control.php?page=rmoptions">RM Options</a>
			  <a class="leftmenu" href="control.php?page=setplayerstatus">Player Options</a>
		</div><br>
		 ' : "" ?>	

			
          	  <div class="headbox">Menu</div>
			 <a href="index.php" class="leftmenu style1">.: Home</a>
			  <a class="leftmenu" href="city.php">.: <!_-cityname-_!></a>
			  <a class="leftmenu" href="bus.php">.: Travel</a>
			  <a class="leftmenu" href="inventory.php">.: Inventory</a>
			  <a class="leftmenu" href="bank.php">.: Bank</a>
			  <a class="leftmenu" href="<? echo ($user_class->gang == 0) ? "creategang.php" : "gang.php"; ?>">.: Your Gang</a>
			  <a class="leftmenu" href="gym.php">.: Gym</a>
			  <a class="leftmenu" href="hospital.php">.: Hospital <!_-hospital-_!></a>

			  <a class="leftmenu" href="jail.php">..: Jail <!_-jail-_!></a>
			  <a class="leftmenu" href="events.php">.: Events <!_-events-_!></a>
			  <a class="leftmenu" href="crime.php">.: Crime</a>
            <a class="leftmenu" href="http://forum.thegrpg.com/" target="_blank">.: Forums</a>
			<a class="leftmenu" href="rmstore.php">.: RM Store</a>
			 <a class="leftmenu" href="search.php">.: Mobster Search</a>
			  <a class="leftmenu" href="spylog.php">.: Spy Log</a>
		 </ul>
		 
		 <br />
		   <div class="headbox">Communication</div>
		   <a class="leftmenu" href="pms.php">.: Mailbox <!_-mail-_!></a>
		   <a class="leftmenu" href="classifieds.php">.: Classified Ads</a>
		    <a class="leftmenu" href="chatroom.php">.: Chat Room</a>
		    <?php
if($user_class->announcement > 0)
{
?>
    <a class="leftmenu" href="announcement.php">NEWS <font color='red'[new]</a>
<?php 
}
else
{ 
?>
    <a class="leftmenu" href="announcement.php">Announcement [0]</a>
<?php
}
?>
		    
		    <br />
			 <div class="headbox">Account</div>
			  <a class="leftmenu" href="index.php?action=logout">.: Logout</a>
			  <a class="leftmenu" href="preferences.php">.: Change Preferences</a>
			  <a class="leftmenu" href="cpassword.php">.: Change Password</a>
			  <a class="leftmenu" href="changestyle.php">.: Change Color Scheme</a>			  
		  </div>
		  <br />
		
		
<!_-effects-_!>
		 
			</center>
			</div>
          </td>
          <td valign="top">
            <table border="0" cellspacing="0" cellpadding="0" width="100%">
              <tr>
                <td width="10"></td>
                <td valign="top" class="mainbox">

<table class="content">
<?
if ($user_class->admin == 1 || $user_class->rmdays > 0){
} else {
?>
		<tr><td class="contentcontent">
		<center>
<script type="text/javascript"><!--
google_ad_client = "pub-0905156377500300";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2007-07-25: grpg
google_ad_channel = "8497905351";
google_color_border = "000000";
google_color_bg = "333333";
google_color_link = "ffcc00";
google_color_text = "FFFFFF";
google_color_url = "ffcc00";
google_ui_features = "rc:10";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
		</center>

		</td></tr>

    <?php
}

    //echo ($user_class->admin == 1) ? "Admin Toolbar<br>"."<a href='" . "http://bourbanlegends.com/grpg" . $_SERVER['PHP_SELF']."?hackthegibson=iamgayandwantfullhealth'>Full Health</a>"." | <a href='" . "http://bourbanlegends.com/grpg" . $_SERVER['PHP_SELF']."?hackthegibson=iamgayandwantfullnerve'>Full Nerve</a>" . " | <a href='" . "http://bourbanlegends.com/grpg" . $_SERVER['PHP_SELF']."?hackthegibson=iamgayandwantoutofthehospital'>Get Out Of Hospital</a>" . " | <a href='" . "http://bourbanlegends.com/grpg" . $_SERVER['PHP_SELF']."?hackthegibson=iamgayandwantfullenergy'>Full Energy</a>" : "";


	//echo ($user_class->admin > 0) ? "<tr><td class='contenthead'>DJ Toolbar</td></tr><tr><td class='contentcontent' align='center'><a href='staff.php?radio=on'>Turn Radio On</a> | <a href='staff.php?radio=off'>Turn Radio Off</a> | <a href='staff.php?random=person'>Pick A Random Player</a></td></tr>" : "";

		$result = mysql_query("SELECT * FROM `ganginvites` WHERE `username` = '$user_class->username'");
		//$invites_exist = mysql_num_rows($result);

		if (mysql_num_rows($result) > 0){
			$invite_class = New Gang($line['gangid']);
		echo "<tr><td class='contentcontent'>You have new gang invitatations <a href='ganginvites.php'>View Gang Invites</a></td></tr>";
		}
		if ($user_class->level == 1){
			echo Message("It looks like you are a new player. Please Mail Owner for Starter Pack <a href='http://silentmafia.co.uk/profiles.php?id=1'>Here</a>");
		}
		
	 	if ($user_class->jail > 0){
			echo "<tr><td class='contenthead'>Jail</td></tr><tr><td class='contentcontent' align='center'>You are currenty in jail for " . floor($user_class->jail / 60) . " more minutes.</td></tr>";
			
		}
		if ($user_class->hospital > 0){
			echo "<tr><td class='contenthead'>Hospital</td></tr><tr><td class='contentcontent' align='center'>You are in the hospital for " . floor($user_class->hospital / 60) . " more minutes.</td></tr>";
			
		}
?>