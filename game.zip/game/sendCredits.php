<?php
include 'header.php';

if($_POST['sendCredits'] != ""){
  $money_person = new User($_POST['theirid']);

  if($user_class->Credits >= $_POST['amount'] && $_POST['amount'] > 0 && $user_class->id != $money_person->id){
	$newCredits = $user_class->Credits - $_POST['amount'];
	$result = mysql_query("UPDATE `grpgusers` SET `Credits` = '".$newCredits."' WHERE `id`='".$_SESSION['id']."'");
	
	$newCredits = $money_person->Credits + $_POST['amount'];
	$result = mysql_query("UPDATE `grpgusers` SET `Credits` = '".$newCredits."' WHERE `id`='".$_POST['theirid']."'");
	echo "You have successfully transferred ".$_POST['amount']." Credits to ".$money_person->formattedname.".";
  } else {
	echo "You don't have enough Credits to do that!";
  } 
}
?>

<div class="content"><u>Send Credits</u><br>
<form name='login' method='post' action='sendCredits.php'>
  <p>&nbsp;</p>
  <table border='0' cellpadding='0' cellspacing='0'>
    <tr> 
      <td width='35%' height='27'>Amount Of Credits</td>
      <td width='65%'>
        <input name='amount' type='text' size='22'>
    	</td>
    </tr>
        <tr> 
      <td width='35%' height='27'>User ID</td>
      <td width='65%'>
        <input name='theirid' type='text' size='22' value='<? echo $_GET['person'] ?>'>
    	</td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>
        <input type='submit' name='sendCredits' value='Send Credits'>
        </td>
    </tr>
  </table>
</form>
</div>


<?php
include 'footer.php';
?>