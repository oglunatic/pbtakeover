<?php
define('title', 'Logs', true);
require_once('./system.php');
require_once('./includes/pagination.php');
	$_GET['cmd'] = (isset($_GET['cmd']) && !empty($_GET['cmd'])) ? trim($_GET['cmd']) : false;
	$_GET['ID'] = (isset($_GET['ID']) && !empty($_GET['ID'])) ? intval($_GET['ID']) : false;
$width = round(100/3, 2);
$top = '<table width="100%" class="table" align="center">
<tr><td>
    <table width="100%" class="table" align="center">
    <tr>
	<td width="'. $width.'%"><a href="logs.php"><img src="images/logs/logs.png" height="48px" width="48px" /></a><br /><a href="logs.php">Logs</a></td>
	<td width="'. $width.'%"><a href="logs.php?cmd=saved"><img src="images/logs/saved.png" height="48px" width="48px" /></a><br /><a href="logs.php?cmd=saved">Saved Logs</a></td>
	<td width="'. $width.'%"><a href="logs.php?cmd=prune"><img src="images/logs/prune.png" height="48px" width="48px" /></a><br /><a href="logs.php?cmd=prune">Prune</a></td>
    </tr>
    </table>
</td></tr>';
switch($_GET['cmd']) {
    case 'save' : save(); break;
    case 'saved' : saved(); break;
    case 'prune' : prune(); break;
    case 'delete' : delete(); break;
    default: logs(); break;
}
function logs() {
global $db, $user, $top, $setting;
$items = 15;  // per page
$_GET['page'] = (isset($_GET['page']) && !empty($_GET['page'])) ? intval($_GET['page']) : false;
$count = $db->single($db->execute('SELECT COUNT(`id`) FROM `logs` WHERE (`to` = '. $user->userid .');'));
$page = (isset($_GET['page']) && !empty($_GET['page'])) ? intval($_GET['page']) : 1;
if(!empty($_GET['page']) && $page = $_GET['page']) {
	$limit = (($page - 1) * $items) .", $items";
} else {
	$limit = $items;
}
	$p = new pagination;
	$p->target('logs.php');
	$p->items($count);
        $p->parameterName('page');
	$p->limit($items);
	$p->showcounter(true);
	$p->currentPage($page);
	$p->show();
	echo $top;
echo'<tr>
    <td>
	<table width="100%" class="table" align="center">
	<tr>
            <th width="80%">'. $setting['log'] .'s</th>
            <th width="20%">Links</th>
	</tr>';
	$logs = $db->execute('SELECT * FROM `logs` WHERE ((`to` = '. $user->userid .') AND (`deleted` = 0)) LIMIT '. $limit .';');
	    if($db->num_rows($logs) == 0) {
		echo'<tr>
                    <td colspan="2">You have no '. strtolower($setting['log']) .'s</td>
		</tr>';
            }
            else {
	    while($log = $db->obj($logs)) {
		echo'<tr>
                	<td>'. $log->log .'</td>
		    	<td>'. (($log->read == 0) ? '<span style="font-weight: bold; color: red;">Unread</span><br />' : '') .'
                            <a href="logs.php?cmd=delete&ID='. $log->id .'"><img src="images/logs/delete.png" alt="Delete" title="Delete" /></a>
                            <a href="logs.php?cmd=save&ID='. $log->id .'">'. (($log->saved == 1) ? '' : '<img src="images/logs/save.png" alt="Save" title="Save" /></a>') .'</td>
			</tr>';
            }
            }
		if($user->logs != 0) {
                    $db->execute('UPDATE `users` SET `logs` = 0 WHERE (`userid` = '. $user->userid .') LIMIT 1;');
                    $db->execute('UPDATE `logs` SET `read` = 1 WHERE ((`to` = '. $user->userid .') AND (`read` = 0));');
                }
}
function saved() {
global $db, $user, $top, $setting;
$items = 15;  // per page
$_GET['page'] = (isset($_GET['page']) && !empty($_GET['page'])) ? intval($_GET['page']) : false;
$count = $db->single($db->execute('SELECT COUNT(`id`) FROM `logs` WHERE (`to` = '. $user->userid .');'));
$page = (isset($_GET['page']) && !empty($_GET['page'])) ? intval($_GET['page']) : 1;
if(!empty($_GET['page']) && $page = $_GET['page']) {
	$limit = (($page - 1) * $items) .", $items";
} else {
	$limit = $items;
}
	$p = new pagination;
	$p->target('logs.php');
	$p->items($count);
        $p->parameterName('page');
	$p->limit($items);
	$p->showcounter(true);
	$p->currentPage($page);
	$p->show();
	echo $top;
echo'<tr>
	<td>
	    <table width="100%" class="table" align="center">
	    <tr>
		<th width="80%">'. $setting['log'] .'s</th>
		<th width="20%">Links</th>
	    </tr>';
	$logs = $db->execute('SELECT `log`, `id` FROM `logs` WHERE ((`to` = '. $user->userid .') AND (`deleted` = 0) AND (`saved` = 1)) LIMIT '. $limit .';');
	    if($db->num_rows($logs) == 0) {
		echo'<tr>
			<td colspan="2">You have no saved '. strtolower($setting['log']) .'s</td>
		    </tr>';
	    } else {
	    while($log = $db->obj($logs)) {
		echo'<tr>
			<td>'. $log->log .'</td>
			<td><a href="logs.php?cmd=delete&ID='. $log->id .'"><img src="images/logs/delete.png" alt="Delete" title="Delete" /></a></td>
			</tr>';
	    }
	    }
}
function save() {
global $db, $user, $top, $setting;
echo $top;
    echo'<tr>
	<td style="font-weight: bold;">';
if(empty($_GET['ID'])) {
		echo'No '. strtolower($setting['log']) .' selected.';
} else {
    $logs = $db->execute('SELECT `id`, `saved`, `deleted` FROM `logs` WHERE (`id` = '. $_GET['ID'] .') LIMIT 1;');
	if(!mysql_num_rows($logs)) {
		echo'This '. strtolower($setting['log']) .' doesnt exist.';
	} else {
		$log = $db->obj($logs);
	if($log->saved == 1) {
		echo'This '. strtolower($setting['log']) .' is already saved.';
	} elseif($log->deleted == 1) {
		echo'This '. strtolower($setting['log']) .' doesnt exist.';
	}
	    $db->execute('UPDATE `logs` SET `saved` = 1 WHERE ((`id` = '. $_GET['ID'] .') AND (`to` = '. $user->userid .')) LIMIT 1;');
		if($db->affected_rows()) {
		    echo'This '. strtolower($setting['log']) .' has been saved.';
		} else {
		    echo'There seems to be an error.';
		}
	}
	}
}
	function delete() {
	global $db, $user, $top, $setting;
	echo $top;
	echo'<tr>
		<td style="font-weight: bold;">';
	if(empty($_GET['ID'])) {
		echo'No '. strtolower($setting['log']) .' selected.';
	} else {
	    $logs = $db->execute('SELECT `id`, `saved`, `deleted` FROM `logs` WHERE (`id` = '. $_GET['ID'] .') LIMIT 1;');
	if($db->num_rows($logs) == 0) {
		echo'This '. strtolower($setting['log']) .' doesnt exist.';
	} else {
		$log = $db->obj($logs);
	if($log->saved == 1) {
	    $db->execute('UPDATE `logs` SET `saved` = 0 WHERE (`id` = '. $log->id .') LIMIT 1;');
			if($db->affected_rows()) {
			    echo'This '. strtolower($setting['log']) .' has been removed from the saved '. strtolower($setting['log']) .'s. You will now have to re-delete it incase you made a mistake.';
			} else {
			    echo'There seems to be an error.';
			}
	} elseif($log->deleted == 1) {
		echo'This '. strtolower($setting['log']) .' doesnt exist.';
	} else {
	    $db->execute('UPDATE `logs` SET `deleted` = 1 WHERE ((`id` = '. $_GET['ID'] .') AND (`to` = '. $user->userid .')) LIMIT 1;');
		if($db->affected_rows()) {
		    echo'This '. strtolower($setting['log']) .' has been deleted.';
		} else {
		    echo'There seems to be an error.';
		}
	}
	}
	}
	}
	function prune() {
	    global $db, $user, $top, $setting;
	echo $top;
	echo'<tr>
		<td style="font-weight: bold;">';
		$time = time() - 60*60*25*7;
		$db->execute('UPDATE `logs` SET `deleted` = 1 WHERE ((`time` < '. $time .') AND (`saved` = 0) AND (`read` = 1) AND (`to` = '. $user->userid .'));');
			if($db->affected_rows()) {
			    echo number_format($db->affected_rows()) .' '. strtolower($setting['log']) .'(s) have been deleted. These '. strtolower($setting['log']) .'s where read, unsaved, and older than a week.';
			} else {
			    echo'No '. strtolower($setting['log']) .'s where deleted.';
			}
		echo'</td></tr></table>';
	}
echo'			</table>
		</td>
	</tr>
</table>';
$template->endtemplate();