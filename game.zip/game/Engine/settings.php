<?php
define('title', 'Settings');
define('EXTRAUSERS', ', `salt`, `password`');
require_once('./system.php');
/*
 Settings:
  @Name
  @Template
  @Password
  @Email
*/
define('name_show', ($setting['namechange'] > 0 ? format($setting['namechange'], $setting['currency']) : 'Free')); //Dont touch
define('pass_show', ($setting['passchange'] > 0 ? format($setting['passchange'], $setting['currency']) : 'Free')); // Dont touch
define('email_show', ($setting['emailchange'] > 0 ? format($setting['emailchange'], $setting['currency']) : 'Free')); // Dont touch
$names = array('', 'Abrasive - <span style="font-weight: bold;">Default</span>', 'Emporium', 'Pluralism'); //Leave first one blank


$email = $db->obj($db->execute('SELECT * FROM `email` WHERE (`userid` = '. $user->userid .') LIMIT 1;'));
$_GET['cmd'] = (isset($_GET['cmd']) && !empty($_GET['cmd'])) ? mysql_real_escape_string(trim($_GET['cmd'])) : '';
switch($_GET['cmd']) {
	case 'name' : name(); break;
	case 'pass' : pass(); break;
	case 'email' : email(); break;
	case 'temp' : template(); break;
	default : settings(); break;
}
function settings( ) {
global $setting;
?>
<table width="100%" class="table" align="center">	<tr>
		<td width="100%"><a href="settings.php?cmd=name">Name Change (<?php echo name_show; ?>)</a></td>
</tr> 	<tr>
		<td width="100%"><a href="settings.php?cmd=pass">Password Change (<?php echo pass_show; ?>)</a></td>
</tr>	<tr>
		<td width="100%"><a href="settings.php?cmd=email">Email Change (<?php echo email_show; ?>)</a></td>
</tr>	<tr>
		<td width="100%"><a href="settings.php?cmd=temp">Template Changer</a></td>
</tr> </table>
<?php
}
function name( ) {
global $template, $db, $user, $setting;
	if($user->money < $setting['namechange']) {
		echo'You don\'t have enough money to change your name.';
		exit($template->endtemplate());
	}
	$_POST['name'] = (isset($_POST['name']) && !empty($_POST['name'])) ? strip_tags(mysql_real_escape_string(trim($_POST['name']))) : '';
if(empty($_POST['name'])) {
?>
<table width="100%" class="table" align="Center">
	<tr>
		<td width="50%" rowspan="2">New Name</td>
		<td width="50%"><form action="settings.php?cmd=name" method="post"><input type="text" name="name" value="" /></td>
	</tr>
	<tr>
		<td><input type="submit" value="Change!" /></form></td>
	</tr>
</table>
<?php
} else {
$check = $db->single($db->execute('SELECT COUNT(`userid`) AS `count` FROM `users` WHERE (`username` = \''. $_POST['name'] .'\');'));
	if($check != 0) {
		echo'This name is taken.';
		exit($template->endtemplate());
	}
	$db->execute('UPDATE `users` SET `username` = \''. $_POST['name'] .'\', `money` = `money` - '. $setting['namechange'] .' WHERE (`userid` = '. $user->userid .') LIMIT 1;');
	if($db->affected_rows()) {
		echo'Name changed.<br /><big>This changes your login name.</big>';
	}
}
}
function pass( ) {
global $template, $user, $db, $email, $setting;
require_once('./includes/password.php');
$password = new password;
if($user->money < $setting['passchange']) {
	echo'You don\'t have enough money to change your password.';
	exit($template->endtemplate());
}
//$_POST['oldpassword'] = (isset($_POST['oldpassword']) && !empty($_POST['oldpassword'])) ? strip_tags(mysql_real_escape_string(trim($_POST['oldpassword']))) : '';
$_POST['password'] = (isset($_POST['password']) && !empty($_POST['password'])) ? strip_tags(mysql_real_escape_string(trim($_POST['password']))) : '';
if(empty($_POST['password'])) {
?>
<form action="settings.php?cmd=pass" method="post">
<table width="100%" class="table" align="Center">
	<tr>
		<td width="50%" >Old Password</td>
		<td width="50%"><input type="password" name="oldpassword" value="" /></td>
	</tr>
	<tr>
		<td width="50%" rowspan="2">New Password</td>
		<td width="50%"><input type="password" name="password" value="" /></td>
	</tr>
	<tr>
		<td><input type="submit" value="Change!" /></form></td>
	</tr>
</table>
<?php
} else {
$oldpass = $password->newpass($_POST['oldpassword'], $email->email, $user->salt);
//echo $oldpass .'<br />';
	if($oldpass != $user->password) :
		echo'Old passwords don\'t match.';
		exit($template->endtemplate());
	endif;
	$newsalt = $password->newsalt();
	$newpass = $password->newpass($_POST['password'], $email->email, $newsalt);
	$db->execute('UPDATE `users` SET `salt` = \''. $newsalt .'\', `password` = \''. $newpass .'\', `money` = `money` - '. $setting['passchange'] .' WHERE (`userid` = '. $user->userid .') LIMIT 1;');
		echo'Password changed, you will now need to verify yourself.';
		$_SESSION['verify'] = 1;
}
}
function email( ) {
global $db, $user, $email, $template, $setting;
require_once('./includes/password.php');
$password = new password;
if($user->money < $setting['passchange']) {
	echo'You don\'t have enough money to change your email.';
exit($template->endtemplate());
}
$_POST['email'] = (isset($_POST['email']) && !empty($_POST['email'])) ? strip_tags(mysql_real_escape_string(trim($_POST['email']))) : '';
$_POST['password'] = (isset($_POST['password']) && !empty($_POST['password'])) ? strip_tags(mysql_real_escape_string(trim($_POST['password']))) : '';
if(empty($_POST['password'])) {
?>
<form action="settings.php?cmd=email" method="post">
	<table width="100%" class="table" align="Center">
		<tr>
			<td width="50%">New Email</td>
			<td width="50%"><input type="text" name="email" value="" /></td>
		</tr>
		<tr>
			<td width="50%">Confirm Password</td>
			<td width="50%"><input type="password" name="password" value="" /></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" value="Change!" /></form></td>
		</tr>
	</table>
</form>
		<?php
} else {
	$newmail = (verify_email($_POST['email'])) ? $_POST['email'] : $email->email;
	$salt = $user->salt;
	$pass = $_POST['password'];
	$email = $email->email;
		$thepass = $password->newpass( $pass, $email, $salt );
	if($thepass != $user->password) {
		echo'The password you entered isnt correct.';
		exit($template->endtemplate());
	}
	$newpass = $password->newpass( $pass, $newmail, $salt );
	$db->execute('UPDATE `users` SET `password` = \''. $newpass .'\', `email` = \''. $newmail .'\', `money` = `money` - '. $setting['passchange'] .' WHERE (`userid` = '. $user->userid .') LIMIT 1;');
	echo'Email changed, you will now need to verify yourself.';
	$_SESSION['verify'] = 1;	
}
}
function template() {
global $names,$template;
$_GET['ID'] = (isset($_GET['ID']) && !empty($_GET['ID'])) ? intval($_GET['ID']) : '';
$_COOKIE['template'] = (isset($_COOKIE['template']) && !empty($_COOKIE['template'])) ? intval($_COOKIE['template']) : 1;
	if(empty($_GET['ID'])) {
		echo'<table width="100%" class="table" align="center">';
			for($i = 1; $i <= (count($names)-1); $i++) {
			echo'<tr>
				<th width="50%">Name:<br />Apply:</th>
				<td width="50%">';
			echo ($_COOKIE['template'] == $i) ? '<span style="color: green;">'. $names[$i] .'</span>' : '<span style="color: red;">'. $names[$i] .'</span>';
			echo'<br /><a href="settings.php?cmd=temp&ID='. $i .'">Apply</a><br />';
			echo'</tr>';
			}
		echo'</table>';
	exit($template->endtemplate());
	}
		setcookie('template', $_GET['ID'], (time()+60*60*24*30), '/');
		echo'<br />Template changed.';
}
$template->endtemplate();