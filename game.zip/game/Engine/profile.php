<?php
define('title', 'Profile', true);
require_once('./system.php');
$_GET['ID'] = (isset($_GET['ID']) && !empty($_GET['ID'])) ? intval( $_GET['ID'] ) : $user->userid;
	$profile = $db->obj($db->execute('SELECT * FROM `users` WHERE (`userid` = '. $_GET['ID'] .') LIMIT 1;'));echo'
<table width="100%" class="table" align="center">
	<tr>
		<th width="50%">Name:</th>
		<td width="50%">'. $user->profile($profile->userid,0,1,0).'</td>
	</tr>
	<tr>
		<th width="50%">Staff Level:</th>
		<td width="50%">'. access($profile->access) .'</td>
	</tr>
	<tr>
		<th width="50%">Level:</th>
		<td width="50%">'. format($profile->level) .'</td>
	</tr>
	<tr>
		<th width="50%">'. ucwords($setting['money']) .':</th>
		<td width="50%">'. format($profile->money, $setting['currency']) .'</td>
	</tr>
	<tr>
		<th width="50%">'. ucwords($setting['token']) .'s:</th>
		<td width="50%">'. format($profile->tokens) .'</td>
	</tr>
	<tr>
		<th width="50%">Laston:</th>
		<td width="50%">'. laston($profile->laston) .'</td>
	</tr>';
if($profile->jail > time()) {
echo'	<tr>
		<th width="50%">'. ucwords($setting['jail']) .':</th>
		<td width="50%">'. timeleft($profile->jail) .'</td>
	</tr>
	<tr>
		<th width="50%">'. ucwords($setting['jail']) .' Reason:</th>
		<td width="50%">'. $profile->jailreason .'</td>
	</tr>';
}
if($profile->hospital > time()) {
echo'	<tr>
		<th width="50%">'. ucwords($setting['hospital']) .':</th>
		<td width="50%">'. timeleft($profile->hospital) .'</td>
	</tr>
	<tr>
		<th width="50%">'. ucwords($setting['hospital']) .' Reason:</th>
		<td width="50%">'. $profile->hospreason .'</td>
	</tr>';
}
echo'</table>';
$template->endtemplate();
?>