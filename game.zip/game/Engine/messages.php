<?php
//define('EXTRAUSERS', ', `gang`');
define('title', 'Messages', true);
	require_once('./system.php');
	//require_once('./lib/bbcode.php');
	require_once('./lib/smiley.php');
?><script type="text/javascript">function isNumberKey(evt){var charCode=(evt.which)?evt.which:event.keyCode if(charCode>31&&(charCode<48||charCode>57)){return false;}return true;}</script><?php
	$_GET['cmd'] = (isset($_GET['cmd']) && !empty($_GET['cmd'])) ? trim($_GET['cmd']) : false;
	$_GET['order'] = (isset($_GET['order']) && !empty($_GET['order'])) ? trim($_GET['order']) : false;
	$_GET['ID'] = (isset($_GET['ID']) && !empty($_GET['ID'])) ? intval($_GET['ID']) : 0;
	$_GET['user'] = (isset($_GET['user']) && !empty($_GET['user'])) ? intval($_GET['user']) : false;
//$width = ($user->gang != 0) ? round(100/6, 2) : 100/5;
	$width = 100/5;
?><table width="99%" class="table" align="center">
	<tr>
		<td>
		<table width="100%" align="center">
			<tr>
				<td width="<?php echo $width; ?>%"><a href="messages.php"><img src="images/mail/inbox.png" height="48px" width="48px" /></a><a href="messages.php"><br />Inbox</a></td>
				<td width="<?php echo $width; ?>'%"><a href="messages.php?cmd=write"><img src="images/mail/compose.png" height="48px" width="48px" /></a><a href="messages.php?cmd=write"><br />Write</a></td>
			<!--//if($user->gang != 0) {-->
			<!--//	echo'<td width="<?php //echo $width; ?>%"><a href="messages.php?cmd=gangs"><img src="images/mail/inbox.png" height="48px" width="48px" /></a><a href="messages.php?cmd=gangs"><br />'. $setting['gang'] .' Mails</a></td>
			<!--//}
			echo'-->
				<td width="<?php echo $width; ?>%"><a href="messages.php?cmd=sent"><img src="images/mail/outbox.png" height="48px" width="48px" /></a><a href="messages.php?cmd=sent"><br />Outbox</a></td>
				<td width="<?php echo $width; ?>%"><a href="messages.php?cmd=saved"><img src="images/mail/saved.png" height="48px" width="48px" /></a><a href="messages.php?cmd=saved"><br />Saved Mails</a></td>
				<td width="<?php echo $width; ?>%"><a href="messages.php?cmd=prune"><img src="images/mail/delete.png" height="48px" width="48px" /></a><a href="messages.php?cmd=prune"><br />Prune Mails</a></td>
			</tr>
		</table>
		</td>
</tr>
<?php
	switch($_GET['cmd']) {
		case 'write' : write(); break;
		//case 'gangs' : gangs(); break;
		case 'gangs' : inbox(); break;
		case 'sent' : sent(); break;
		case 'saved' : saved(); break;
		case 'save' : save(); break;
		case 'delete' : delete(); break;
		case 'prune' : prune(); break;
		case 'read' : read(); break;
		default : index(); break;
	}
	function index() {
		global $db, $user, $setting;
	echo'<tr>
		<td>Show:<br />&bull; <a href="messages.php?order=unread">Unread Only</a> &bull; <a href="messages.php?order=read">Read Only</a> ';
	//if($user->gang != 0) {
	//	echo'&bull; <a href="messages.php?cmd=gangs">'. ucwords($setting['gang']) .' Only</a>';
	//}
	echo'
		&bull; <a href="messages.php">All Mail</a></td>
	</tr>
	<tr>
		<td>
		<table width="100%" align="center">
			<tr>
				<th width="20%">Name</th>
				<th width="60%">Subject</th>
				<th width="10%">Read</th>
				<th width="10%">Actions</th>
			</tr>';
		$query = 'SELECT u.`username`, u.`userid`, m.* FROM `mail` AS `m` LEFT JOIN `users` AS `u` ON m.`from` = u.`userid` WHERE ((m.`to` = '. $user->userid .')';
		$query .= (isset($_GET['order']) && !empty($_GET['order']) && $_GET['order'] = 'unread') ? ' AND (m.`read` = 0)' : '';
		$query .= (isset($_GET['order']) && !empty($_GET['order']) && $_GET['order'] = 'read') ? ' AND (m.`read` = 1)' : '';
		$query .=  ' AND (m.`deleted` = 0)) ORDER BY m.`read` ASC, m.`time` DESC LIMIT 15;';
			$messages = $db->execute($query);
			if(!$db->num_rows($messages)) {
				echo'<tr>
					<th colspan="4">You have no messages</th>
				</tr>';
			} else {
				while($mail = $db->obj($messages)) {
					echo'<tr>
						<td><a href="profile.php?ID='. $mail->userid .'">'. $mail->username .'</a></td>
						<td>'. $mail->subject .'</td>
						<td>'. (($mailf->read == 0) ? '<a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/unread.png" alt="Unread" title="Unread" /></a>' : '<a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/read.png" alt="Read" title="Read" /></a>') .'</td>
						<td><a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/read2.png" height="16px" width="16px" alt="read" title="Read Message" /></a>
						<a href="messages.php?cmd=delete&ID='. $mail->id .'"><img src="images/mail/delete2.png" title="Delete Message" alt="Delete" />'.(($mail->saved == 1) ? '' : '<a href="messages.php?cmd=save&ID='. $mail->id .'"><img src="images/mail/save.png" title="Save Message" alt="Save" /></a>') .'</td>
					</tr>';
				}
			}
		echo'</table>
		</td>
	</tr>
</table>';
	}
	function read() {
		global $db, $user; //, $setting;
echo'<tr><td>';
		$mail = $db->obj($db->execute('SELECT u.`username`, u.`userid`, m.* FROM `users` AS `u` LEFT JOIN `mail` AS `m` ON m.`from` = u.`userid` WHERE (((m.`to` = '. $user->userid .') OR (m.`from` = '. $user->userid .')) AND (m.`id` = '. $_GET['ID'] .')) LIMIT 1;'));
	echo'<table width="100%" align="center">
		<tr>
			<td width="20%" rowspan="2">Send By: <a href="profile.php?ID='. $mail->userid .'">'. $mail->username .'</a><br />Time: '. date('j F, Y. <br /> g:i:s a', $mail->time) .'</td>
			<th width="60%">Subject: '. $mail->subject .'</th>
			<td width="20%" rowspan="2"><a href="messages.php?cmd=write&ID='. $mail->id .'"><img src="images/mail/reply.png" alt="Reply" title="Reply to this Message" /></a><br /><a href="messages.php?cmd=delete&ID='. $mail->id .'"><img src="images/mail/delete2.png" title="Delete Message" alt="Delete" /></a>'. (($mail->saved == 1) ? '' : '<a href="messages.php?cmd=save&ID='. $mail->id .'"><img src="images/mail/save.png" title="Save Message" alt="Save" /></a>') .'</td>
		</tr>
		<tr>
			<td>'. $mail->message .'</td>
		</td>
		</tr>
		</table>
	</td>
	</tr>
	</table>';
	if($mail->read == 0) {
		$db->execute('UPDATE `mail` SET `read` = 1 WHERE (`id` = '. $mail->id .') LIMIT 1;');
		$db->execute('UPDATE `users` SET `messages` = `messages` - 1 WHERE (`userid` = '. $mail->to .') LIMIT 1;');
	}
}
function write() {
	global $db, $user, $template;
		$smiley = new smiley;
			$message = $db->execute('SELECT * FROM `mail` WHERE ((`id` = '. $_GET['ID'] .') AND (`to` = '. $user->userid .')) LIMIT 1;');
	if(!$db->num_rows($message)) {
		$subject = '';
	} else {
		$mail = $db->obj($message);
		$subject = 'RE: '. $mail->subject;
		$_GET['user'] = $mail->from;
	}
		echo'<tr><td>';
	if(isset($_POST['ID'])) {
		if($_POST['ID'] == $user->userid) {
			echo'You cannot send a message to yourself.</td></tr></table>';
			exit($template->endtemplate());
		}
	$_POST['subject'] = trim(strip_tags(addslashes($_POST['subject'])));
	$_POST['message'] = $smiley->pharse(strip_tags(addslashes($_POST['message'])), 1);
		$db->execute('INSERT INTO `mail` VALUES ("", "'. $_POST['subject'] .'", "'. $_POST['message'] .'", '. $_POST['ID'] .', '. $user->userid .', 0, '. time() .', 0, 0);');
		if($db->affected_rows()) {
			$db->execute('UPDATE `users` SET `messages` = `messages` + 1 WHERE (`userid`  = '. $user->userid .') LIMIT 1;');
				echo'Your message has been sent.</td></tr></table>';
				exit($template->endtemplate());
		} else {
			echo'There was an error whilst sending your message.</td></tr></table>';
			exit($template->endtemplate());
		} //Something went reallllllly wrong
		echo'</td></tr></table>';
		exit($template->endtemplate());
	}
	echo'
	<form action="messages.php?cmd=write" method="post">
		<table width="100%" align="center">
			<tr>
				<td style="text-algin: center;" width="50%">Member\'s ID: <input type="text" name="ID" value="'. $_GET['user'] .'" onKeyPress="return isNumberKey(event)" /></td>
				<td style="text-align: center;" width="50%">Subject: <input type="text" name="subject" value="'. $subject .'" /></td>
			</tr>
			<tr>
				<td style="text-align: center;" colspan="2">In this message you can use <a href="bbcode.php" target="_blank">BBCode</a>, and <a href="smilies.php" target="_blank">Smilies</a></td>
			</tr>
			<tr>
				<td style="text-align: center;" colspan="2">Message<br /><textarea name="message" rows="10" cols="45%"></textarea></td>
			</tr>
			<tr>
				<td style="text-align: center;" colspan="2"><input type="submit" value="Send Message" /></td>
			</tr>
		</table>
			<tr>
	</td>
	</tr>
	</table>';
}
	/*function gangs() {
		global $db, $user, $setting, $template;
	if($user->gang == 0) {
			index();
		exit($template->endtemplate());
	}
echo'<tr><td>Show:<br />&bull; <a href="messages.php?cmd=gangs&order=unread">Unread Only</a> &bull; <a href="messages.php?cmd=gangs&order=read">Read Only</a> &bull; <a href="messages.php?cmd=gangs">'. ucwords($setting['gang']) .' Only</a> &bull; <a href="messages.php">All Mail</a></td>
	</tr>
	<tr>
		<td>
			<table width="100%" align="center">
				<tr>
					<th width="20%">Name</th>
					<th width="60%">Subject</th>
					<th width="10%">Read</th>
					<th width="10%">Actions</th>
				</tr>';
		$query = 'SELECT u.`username`, u.`userid`, m.* FROM `mail` AS `m` LEFT JOIN `users` AS `u` ON m.`from` = u.`userid` WHERE ((m.`to` = '. $user->userid .')';
		$query .= (isset($_GET['order']) && !empty($_GET['order']) && $_GET['order'] = 'unread') ? ' AND (m.`read` = 0)' : '';
		$query .= (isset($_GET['order']) && !empty($_GET['order']) && $_GET['order'] = 'read') ? ' AND (m.`read` = 1)' : '';
		$query .=  ' AND (u.`gang` = '. $user->gang .') AND (m.`deleted` = 0))';
		$query .= ' ORDER BY m.`read` ASC, m.`time` DESC LIMIT 15;';
		if($user->gang == 0) {
			echo'<tr>
				<th colspan="4">You\'r not in a gang</th>
			</tr>
		</table>
		</td>
	</tr>
</table>';
		exit($template->endtemplate());
		}
		$messages = $db->execute($query);
			if(!$db->num_rows($messages)) {
			echo'<tr>
					<th colspan="4">You have no messages.</th>
				</tr>';
			} else {
				while($mail = $db->obj($messages)) {
					echo'<tr>
						<td><a href="profile.php?ID='. $mail->userid .'">'. $mail->username .'</a></td>
						<td>'. $mail->subject .'</td>
						<td>'. (($mail->read == 0) ? '<a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/unread.png" alt="Unread" title="Unread" /></a>' : '<a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/read.png" alt="Read" title="Read" /></a>') .'</td>
						<td><a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/read2.png" height="16px" width="16px" alt="Read" title="Read Message" /></a><a href="messages.php?cmd=delete&ID='. $mail->id .'"><img src="images/mail/delete2.png" title="Delete Message" alt="Delete" /></a><a href="messages.php?cmd=save&ID='. $mail->id .'"><img src="images/mail/save.png" title="Save Message" alt="Save" /></a></td>
					</tr>';
				}
			}
		echo'</table>
		</td>
	</tr>
</table>';
	}*/
	function delete() {
		global $db, $user, $template;
	echo'<tr><td style="font-weight: bold;">';
		if(empty($_GET['ID'])) {
			echo'You haven\'t selected a message to delete.
		</td>		
	</tr>
</table>';
	exit($template->endtemplate());
		}
	$mail = $db->obj($db->execute('SELECT `id`, `deleted`, `saved` FROM `mail` WHERE (`id` = '. intval($_GET['ID']) .') LIMIT 1;'));
		($mail->saved == 1) ? $db->execute('UPDATE `mail` SET `saved` = 0 WHERE ((`id` = '. intval($_GET['ID']) .') AND (`to` = '. $user->userid .')) LIMIT 1;') : $db->execute('UPDATE `mail` SET `deleted` = 1 WHERE ((`id` = '. intval($_GET['ID']) .') AND (`to` = '. $user->userid .')) LIMIT 1;');
			if($db->affected_rows()) {
				if($mail->saved == 1) {
					echo'Your message has now been un-saved, it will require you to delete it again, incase you made a mistake.';
				} else {
					echo'Your message has been deleted.';
				}
		echo'</td>
	</tr>
</table>';
			}
			else {
			echo'Theres seems to be a problem, your message hasnt been deleted.
		</td>
	</tr>
</table>';
		}
	}
	function save() {
		global $db, $user, $template;
echo'<tr><td style="font-weight: bold;">';
		if(empty($_GET['ID'])) {
			echo'No message selected.</td></tr></table>';
		exit($template->endtemplate());
		}
	$db->execute('UPDATE `mail` SET `saved` = 1 WHERE ((`id` = '. intval($_GET['ID']) .') AND (`to` = '. $user->userid .') AND (`deleted` = 0)) LIMIT 1;');
	if($db->affected_rows()) {
		echo'Your message has been saved.</td></tr></table>';
		exit($template->endtemplate());
	}
	}
	function sent() {
		global $db, $user;
echo'	<tr>
		<td>
			<table width="100%" align="center">
				<tr>
					<th width="20%">Name</th>
					<th width="60%">Subject</th>
					<th width="10%">Read</th>
					<th width="10%">Actions</th>
				</tr>';
		$query = 'SELECT u.`username`, u.`userid`, m.* FROM `mail` AS `m` LEFT JOIN `users` AS `u` ON m.`from` = u.`userid` WHERE ((m.`from` = '. $user->userid .')';
		$query .= (isset($_GET['order']) && !empty($_GET['order']) && $_GET['order'] = 'unread') ? ' AND (m.`read` = 0)' : '';
		$query .= (isset($_GET['order']) && !empty($_GET['order']) && $_GET['order'] = 'read') ? ' AND (m.`read` = 1)' : '';
		$query .=  ' AND (m.`deleted` = 0))';
		$query .= ' ORDER BY m.`read` ASC, m.`time` DESC LIMIT 15;';
	$messages = $db->execute($query);
		if(!$db->num_rows($messages)) {
			echo'<tr>
					<th colspan="4">You have sent no messages</th>
				</tr>';
		} else {
			while($mail = $db->obj($messages)) {
				echo'<tr>
					<td><a href="profile.php?ID='. $mail->userid .'">'. $mail->username .'</a></td>
					<td>'. $mail->subject .'</td>
					<td>'. (($mail->read == 0) ? '<a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/unread.png" alt="Unread" title="Unread" /></a>' : '<a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/read.png" alt="Read" title="Read" /></a>') .'</td>
					<td><a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/read2.png" height="16px" width="16px" alt="Read" title="Read Message" /></a></td>
				</tr>';
			}
		}
		echo'</table>
		</td>
	</tr>
</table>';
	}
	function saved() {
		global $user, $db;
echo'<tr>
		<td>
			<table width="100%" align="center">
				<tr>
					<th width="20%">Name</th>
					<th width="60%">Subject</th>
					<th width="10%">Read</th>
					<th width="10%">Actions</th>
				</tr>';
		$messages = $db->execute('SELECT u.`username`, u.`userid`, m.* FROM `mail` AS `m` LEFT JOIN `users` AS `u` ON m.`from` = u.`userid` WHERE ((m.`from` = '. $user->userid .')' . ' AND (m.`deleted` = 0) AND (m.`saved` = 1))' . ' ORDER BY m.`read` ASC, m.`time` DESC LIMIT 15;');
			if(!$db->num_rows($messages)) {
				echo'<tr>
					<th colspan="4">You have no saved messages</th>
				</tr>';
			} else {
				while($mail = $db->obj($messages)) {
				echo'<tr>
					<td><a href="profile.php?ID='. $mail->userid .'">'. $mail->username .'</a></td>
					<td>'. $mail->subject .'</td>
					<td>'. (($mail->read == 0) ? '<a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/unread.png" alt="Unread" title="Unread" /></a>' : '<a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/read.png" alt="Read" title="Read" /></a>') .'</td>
					<td><a href="messages.php?cmd=read&ID='. $mail->id .'"><img src="images/mail/read2.png" height="16px" width="16px" alt="Read" title="Read Message" /></a><a href="messages.php?cmd=delete&ID='. $mail->id .'"><img src="images/mail/delete2.png" title="Delete Message" alt="Delete" /></td>
				</tr>';
				}
			}
		echo'</table>
		</td>
	</tr>
</table>';
	}
	function prune() {
		global $db, $user;
echo'<tr><td style="font-weight: bold;">';
	$time = time() - 60*60*25*7;
		$db->execute('UPDATE `mail` SET `deleted` = 1 WHERE ((`time` < '. $time .') AND (`saved` = 0) AND (`read` = 1) AND (`to` = '. $user->userid .'));');
			if($db->affected_rows()) {
				echo number_format($db->affected_rows()) .' message(s) have been deleted. These messages where read, unsaved, and older than a week.';
			} else {
				echo'No messages where deleted.';
			}
		echo'</td></tr></table>';
	}
$template->endtemplate();
?>