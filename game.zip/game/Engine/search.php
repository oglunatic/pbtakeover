<?php
define('title', 'Search', true);
require_once('./system.php');
addjquery();
addupdater();
?>
<script type="text/javascript">
function userid() {
    var userid = $('#userid').val();
        window.location.href="profile.php?ID=" + userid;
}
function username() {
try {
    var username = $('#username').val();
    //alert(typeof username);
    if(typeof(username) == 'string') {
        $.get('lib/search.caller.php?name=' + username, function(data) {
            //alert(data);
            update(data, 'update');
        })
    }
} catch(err) { alert(err) }
}
function reset() {
    $.get('lib/search.caller.php', function(data) {
        update(data, 'update');
    })
}
function isNumber(event) {
    var charCode = (event.which) ? event.which : event.keyCode
        if(charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
}
</script>
<?php
	echo'<div id="update"><table width="100%" class="table" align="center">
			<tr>
				<td width="50%" rowspan="2">Userid</td>
				<td width="50%"><form action="javascript: userid();" method="get"><input id="userid" onkeypress="return isNumber(event)"  /></td>
			</tr>
			<tr>
				<td><input type="submit" value="Search!" /></form></td>
			</tr>
			<tr>
				<td width="50%" rowspan="2">Username</td>
				<td width="50%"><form action="javascript: username();" method="get"><input id="username" /></td>
			</tr>
			<tr>
				<td><input type="submit" value="Search!" /></form></td>
			</tr>
		</table></div>
';
$template->endtemplate();
