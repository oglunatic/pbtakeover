<?php
define('title', 'Stats', true);
require_once('./system.php');
        //Get totals
    $mails = $db->single($db->execute('SELECT COUNT(`id`) AS `cnt` FROM `mail`;'));
    $logs = $db->single($db->execute('SELECT COUNT(`id`) AS `cnt` FROM `logs`;'));
    $users = $db->single($db->execute('SELECT COUNT(`userid`) AS `cnt` FROM `users`;'));
    $money = $db->single($db->execute('SELECT SUM(`money`) FROM `users`;'));
    $tokens = $db->single($db->execute('SELECT SUM(`tokens`) FROM `users`;'));
    $levels = $db->single($db->execute('SELECT SUM(`level`) FROM `users`;'));
        //Get adverages
    $level = intval($levels/$users);
    $advmoney = intval($money/$users);
    $token = intval($tokens/$users);
echo'<h2>Game Stats</h2>
        <table width="100%" class="table" align="center">
            <tr>
		<th width="50%">Stat</th>
		<th width="50%">Value</th>
            </tr>
	    <tr>
		<td style="font-weight: bold;">No. of '. strtolower($setting['message']) .'s</td>
		<td>'. format($mails) .'</td>
	    </tr>
	    <tr>
		<td style="font-weight: bold;">No. of '. strtolower($setting['log']) .'s</td>
		<td>'. format($logs) .'</td>
            </tr>
            <tr>
		<td style="font-weight: bold;">No. of players</td>
		<td>'. format($users) .'</td>
            </tr>
            <tr>
		<td style="font-weight: bold;">Total '. strtolower($setting['money']) .'</td>
		<td>'. format($money, $setting['currency']) .'</td>
            </tr>
	    <tr>
		<td style="font-weight: bold;">Total '. strtolower($setting['token']) .'s</td>
		<td>'. format($tokens) .'</td>
            </tr>
            <tr>
                <td style="font-weight: bold;">Adverage level</td>
		<td>'. format($level) .'</td>
            </tr>
            <tr>
                <td style="font-weight: bold;">Adverage '. strtolower($setting['money']) .'</td>
                <td>'. format($advmoney) .'</td>
            </tr>
            <tr>
                <td style="font-weight: bold;">Adverage '. strtolower($setting['token']) .'s</td>
                <td>'. format($token) .'</td>
            </tr>
	</table>';
$template->endtemplate();
?>