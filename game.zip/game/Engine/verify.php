<?php
define('title', 'Verify Account', true);
require_once('./system.php');
require_once('./includes/password.php');
addjquery();
?>
<script type="text/javascript">
      <!--
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
      function newimage() {
	try {
			$('#cap').attr('src', 'lib/Captcha.php')
			$('#numb').attr('value', '')
	}catch(err) {
		//alert(err)
	}
      }
      //-->
</script>
<?php
$password = new password;
	if(!isset($_SESSION['verify']) || empty($_SESSION['verify'])) { $_SESSION['verify'] = 1; }
	unset($_SESSION['verified']);
$_GET['cont'] = (isset($_GET['cont']) && !empty($_GET['cont'])) ? trim($_GET['cont']) : 'dashboard.php';
	if(isset($_POST['password']) && !empty($_POST['password']) && isset($_POST['code']) && !empty($_POST['code'])) {
		$salt = $db->obj($db->execute('SELECT `salt` FROM `users` WHERE (`userid` = '. $userid .')'));
		$email = $db->single($db->execute('SELECT `email` FROM `email` WHERE (`userid` = '. $userid .');'));
	$created_pass = $password->newpass($_POST['password'], $email, $salt->salt);
	$pass = $db->obj($db->execute('SELECT `userid` FROM `users` WHERE (`password` = "'. $created_pass .'");'));
		if(!$pass->userid) {
			foreach($_SESSION as $key => $value){ unset($_SESSION[$key]); }
			foreach($_COOKIE as $key => $value){ unset($_COOKIE[$key]); }		  
			session_unset(); session_destroy();
		echo'Password did not match.<br />You will now need to re-login.<meta http-equiv="refresh" content="5;url=http://www.'.$setting['domain'].'/login.php" />';
		exit($template->endtemplate());
		}
		if($_POST['code'] != $_SESSION['security_code']) {
			echo'Captcha is wrong, please verify again.<br /><a href="verify.php">Go back and verify.</a>';
			exit($template->endtemplate());
		}
	if(!isset($_SESSION['userid'])) $_SESSION['userid'] = $_COOKIE['userid'];
		echo'Account verified.<br /><a href="'. urldecode($_GET['cont']) .'">Click here to continue</a>';
		$db->execute('UPDATE `users` SET `last_ip` = \''. $_SERVER['REMOTE_ADDR'] .'\' WHERE (`userid` = '. $userid .');');
		$_SESSION['verify'] = 0;
		$_SESSION['verified'] = time();
	exit($template->endtemplate());
	}
	echo'You have come to this page because you are still loggedin, and we would like to verify that it is acually you. We ask you to enter your password, and the 4 didget number shown below. You have one attempt before you get logged out. Thanks.';
	?>
	<form action="" method="post">
		<table width="70%" class="table" align="center" valign="center">
			<tr>
				<th colspan="3">&nbsp;</th>
			</tr>
			<tr>
				<td width="33%">Password:</td><td width="33%">&nbsp;</td><td width="34%"><input type="password" name="password" value="" /></td>
			</tr>
			<tr>
				<td colspan="3">&nbsp;</td>
			</tr>
			<tr>	
				<td width="33%">Numbers:</td><td width="33%"><small><a href="javascript: newimage();">Reload image</a></small><br /><img src="lib/Captcha.php" id="cap" /></td><td width="34%"><input type="text" id="numb" name="code" value="" onKeyPress="return isNumberKey(event)" /></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" value="Verify!" /></td>
				<td>&nbsp;</td>
			</tr>
		</table>
	</form>
	<?php
$template->endtemplate();
?>