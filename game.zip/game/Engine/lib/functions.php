<?php
function format($number = 0, $currency = false) {
return (($currency == false) ? number_format($number) : $currency.number_format($number));
}
function access($access, $needed = false, $return = 'name') {
	switch($return) {
	case 'name' : 
		switch($access) {
		case 'a' : return 'Administrator'; break;
		case 'm' : return 'User Moderator'; break;
		case 'h' : return 'Helper'; break;
		case 'f' : return 'Fourm Moderator'; break;
		case 'n' : return 'Member'; break;
		}
	break;
	case 'access' :
		if($access == 'a') { return true; } //admins can view anything
		if(($access == 'm') AND ($needed != 'a')) { return true; } else { return false; }
		if(($access == 'h') AND ($needed != ('a' || 'm'))) { return true; } else { return false; }
		if(($access == 'f') AND ($needed != ('a' || 'm' || 'h'))) { return true; } else { return false;}
		if(($access == 'n') AND ($needed != 'n')) { return false; } else { return true; }
	}
}
function laston( $laston ) {
$time = time()-$laston;
$unit = ' seconds';
if($time >= 60) {
$time = intval($time/60);
$unit = ' minutes';
}
if($time >=60) {
$time = intval($time/60);
$unit = ' hours';
if($time >= 24) {
$time = intval($time/24);
$unit = ' days';
}
}
return  number_format($time) . $unit;
}
function worktime( $seconds ) {
	$time = intval($seconds);
if($time < 60) {
	return $time .' seconds';
} else if($time/60 < 60) {
	return $time/60 .' minutes';
} else if($time/(60*60) < 60) {
	return $time/(60*60) .' hours';
} else if($time/(60*60*24)) {
	return $time/(60*60*24) .' days';
} else if($time/(60*60*24*364)) {
	return $time/(60*60*24*365) .' years';
} else {
	return $time .' seconds';
}
}
function timeleft( $time ) {
$newtime = $time - time();
$time = intval($newtime/60);
	$return = ($newtime < 60) ? $newtime . ' seconds' : ((($time/60) > 60) ? (($time/60)/60) . ' hours' : $time . ' minutes');
return $return;
}
function verify_email( $email ) {
	if(!filter_var($email, FILTER_VALIDTAE_EMAIL)) {
		return false;
	}
		list($before, $domain) = explode('@', $email);
	if(!checkdnsrr($domain, 'MX')) {
		return false;
	}
	return true;
}
function workcheck() {
global $db, $userid, $user, $setting;
	$work = $db->single($db->execute('SELECT `work` FROM `users` WHERE (`userid` = '. $user->userid .');'));// or die(mysql_error());
	list($user->time, $user->job) = explode('|', $work);
	if((time() > $user->time) && ($user->time != 0)) {
		$job = $db->obj($db->execute('SELECT `money`, `tokens` FROM `work` WHERE (`id` = '. $user->job .');'));
		$db->execute('UPDATE `users` SET `money` = `money` + '. $job->money .', `tokens` = `tokens` + '. $job->tokens .', `work` = \'0|0\' WHERE (`userid` = '. $user->userid .');');
		$user->logger('You completed your job, and gained, '. format($job->money, $setting['currency']) .' and '. format($job->tokens) .' '. $setting['tokens'].'.');

	}
}
function verifycheck() {
global $db, $userid;
if(($_SESSION['verify'] != 0) && (title != 'Verify Account') && ($_SESSION['justloggedin'] == false) ) { // Enterented password / Refreshed?
	header('Location: verify.php?cont=' . urlencode($_SERVER['SCRIPT_NAME']));
}
$user = $db->obj($db->execute('SELECT `last_ip`, `laston` FROM `users` WHERE (`userid` = '. $userid .');'));
if(($user->laston < (time()-(60*15))) && title != 'Verify Account' && ($_SESSION['justloggedin'] == false) ) { // Last activity more than 15 minutes ago?
	header('Location: verify.php?cont=' . urlencode($_SERVER['SCRIPT_NAME']));
}
if(($user->last_ip != $_SERVER['REMOTE_ADDR']) && title != 'Verify Account' && ($_SESSION['justloggedin'] == false) ) { // Different IP but still logged in?
	header('Location: verify.php?cont=' . urlencode($_SERVER['SCRIPT_NAME']));
}
if(($_SESSION['userid'] != $_COOKIE['userid']) && title != 'Verify Account' && ($_SESSION['justloggedin'] == false) )  { // Different usernames?
	header('Location: verify.php?cont=' . urlencode($_SERVER['SCRIPT_NAME']));
}
}
function addjquery() {
	echo'<script>!window.jQuery && document.write(\'<script src="http://code.jquery.com/jquery-1.4.2.min.js"><\/script>\');</script>';
}
function addupdater() {
	echo'<script>document.write(\'<script src="lib/updater.js"><\/script>\');</script>';
}
?>