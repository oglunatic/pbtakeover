<?php
$querydriver = 'MySqlDB';
require_once(dirname(dirname(__file__)) .'/includes/settings.db.php');
require_once(dirname(dirname(__file__)) .'/includes/'. $querydriver .'.db.php');
    $db = new $querydriver(host, name, pass, db); //make the connection
require_once(dirname(dirname(__file__)) .'/includes/ajax.users.php');
$user = new user;
$user->init($_COOKIE['userid']);
//$_GET['user'] = (isset($_GET['user']) && !empty($_GET['user'])) ? header('Location: profile.php?ID='. intval( $_GET['user'] )) : false;
$_GET['name'] = (isset($_GET['name']) && !empty($_GET['name'])) ? mysql_real_escape_string(trim($_GET['name'])) : '';
if(!empty($_GET['name'])) {
    $list = $db->execute('SELECT `userid`, `level`, `access`, `money` FROM `users` WHERE (`username` LIKE \'%%'. $_GET['name'] .'%%\');');
echo'<table width="100%" class="table" align="center">
	<tr>
            <th>Name</th>
            <th>Access</th>
            <th>Level</th>
            <th>Money</th>
	    <th>Links</th>
	</tr>';
    if(!$db->num_rows($list)) {
	echo'<tr>
		<td colspan="5">No user found.</td>
	    </tr>
	    <tr>
		<th colspan="5"><a href="javascript: reset();">Back to search</a></th>
	    </tr>
	</table>';
	exit();
    }
    while($list = @$db->obj($list)) {
	echo'<tr>
		<td>'. $user->profile($list->userid,0,1) .'</td>
        	<td>'. access($list->access) .'</td>
		<td>'. format($list->level) .'</td>
		<td>'. format($list->money, $setting['currency']) .'</td>
		<td>'. $user->profile($list->userid,1,0,1) .'</td>
            </tr>';
    }
    echo'<tr><th colspan="5"><a href="javascript: reset();">Back to search</a></th></tr></table>';
exit();
}
echo'<table width="100%" class="table" align="center">
    <tr>
	<td width="50%" rowspan="2">Userid</td>
        <td width="50%"><form action="javascript: userid();" method="get"><input id="userid" /></td>
    </tr>
    <tr>
	<td><input type="submit" value="Search!" /></form></td>
    </tr>
    <tr>
	<td width="50%" rowspan="2">Username</td>
	<td width="50%"><form action="javascript: username();" method="get"><input id="username" /></td>
    </tr>
    <tr>
	<td><input type="submit" value="Search!" /></form></td>
    </tr>
</table>';
