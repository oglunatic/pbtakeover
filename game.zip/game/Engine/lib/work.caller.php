<?php
$querydriver = 'MySqlDB';
require_once(dirname(dirname(__file__)) .'/includes/settings.db.php');
require_once(dirname(dirname(__file__)) .'/includes/'. $querydriver .'.db.php');
    $db = new $querydriver(host, name, pass, db); //make the connection
define('USERS', ', `work`');
require_once(dirname(dirname(__file__)) .'/includes/ajax.users.php');
$user = new user;
$user->init($_COOKIE['userid']);
$_GET['ID'] = (isset($_GET['ID']) && !empty($_GET['ID'])) ? intval($_GET['ID']) : false;
//die(print_r($user));
    list($user->time, $user->job) = explode('|', $user->work);
        if($user->time > 0) {
            echo'Your already doing a job.<br /><br />';
            exit();
        }
	if($user->job > 0) {
            echo'Your already doing a job.<br /><br />';
            exit();
        }
        $work = $db->execute('SELECT `seconds`, `id`, `name` FROM `work` WHERE (`id` = '. $_GET['ID'] .') LIMIT 1;');
        if(!@$db->num_rows($work)) {
	    echo'This isnt a real job.<br /><br />';
            exit();
        }
            $work = $db->obj($work);
	$update = time()+$work->seconds .'|'. $_GET['ID'];
        $db->execute('UPDATE `users` SET `work` = \''. $update .'\' WHERE (`userid` = '. $user->userid .') LIMIT 1;');
    	if($db->affected_rows()) {
		echo'You have successfully started the job: '. $work->name .'.<br />It will take '. worktime($work->seconds) .'.<br /><br />';
		exit();
        } else {
		echo'Sorry, something went wrong.<br /><br />';
		exit();
        }
exit();