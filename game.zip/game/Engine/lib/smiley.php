<?php
class smiley {
	public function pharse($converting, $useBBC = 1) {
		require_once(dirname(dirname(__file__)) .'/includes/game.setting.php');
	$converting = htmlentities($converting);
		$tosearch = array(':)','(A)',':@',':grr:',':brb:',':S',':\'(','(L)','B)',':-*',':O',':(','oO','8o',':yawn:',':think:',':P',':D',';)',':-/');
		$tochange = array('<img src="'. $setting['domain'] .'/images/smilies/Happy_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Angel_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Angry_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Baring_teeth_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Be_Right_Back_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Confused_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Crying_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Heart.png" />','<img src="'. $setting['domain'] .'/images/smilies/Hot_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Kiss.png" />','<img src="'. $setting['domain'] .'/images/smilies/Oh_my_God_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Sad_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Shocked_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Sick_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Sleepy_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Thinking_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Tonque_out_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Very_happy_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Winking_smiley.png" />','<img src="'. $setting['domain'] .'/images/smilies/Dont_know_smiley.png" />');
			$replaced = str_replace($tosearch, $tochange, $converting);
	if($useBBC == 1){
		require_once('./lib/bbcode.php');
			$bbc = new bbcode;
			$replaced = $bbc->pharse($replaced);
	}
	return $replaced;
	}
}