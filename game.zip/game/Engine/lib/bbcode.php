<?php
class bbcode {
        public function pharse($converting) {
$arrayone = array("#\[b\](.*?)\[\/b\]#is","#\[i\](.*?)\[\/i\]#is","#\[u\](.*?)\[\/u\]#is","#\[s\](.*?)\[\/s\]#is","#\[size=([1-9]|1[0-9]|20)\](.*?)\[\/size\]#is",'#\[color=(.*?)\](.*?)\[\/color\]#is','#\[colour=(.*?)\](.*?)\[\/colour\]#is',"#\[img\](http|https?://.*?\.(?:jpg|jpeg|png))\[\/img\]#i","#\[sub\](.*?)\[\/sub\]#is","#\[sup\](.*?)\[\/sup\]#is","#\[big\](.*?)\[\/big\]#is","#\[small\](.*?)\[\/small\]#is","#\[email=(.+?)\]#is","#\[email\](.*?)\[\/email\]#is","#\[left\](.*?)\[\/left]#is","#\[center\](.*?)\[\/center]#is","#\[centre\](.*?)\[\/centre]#is","#\[right\](.*?)\[\/right]#is",'#\[profile=(.*?)\]#i');
$arraytwo = array('[br]', '[br /]', '[hr]', '[hr /]');
$arraythree = array("<span style='font-weight: bold;'>$1</span>","<em>$1</em>","<span style='text-decoration: underline;'>$1</span>","<span style='text-decoration: line-through;'>$1</span>","<span style='font-size: $1px;'>$2</span>","<span style='color: $1;'>$2</span>","<span style='color: $1;'>$2</span>","<img src='$1' alt='Image Not Available' class='image' />","<sub>$1</sub>","<sup>$1</sup>","<big>$1</big>","<small>$1</small>","<a href='mailto:$1'>$1</a>","<a href='mailto:$1'>$1</a>","<div style='text-align: left;'>$1</div>","<div style='text-align: center;'>$1</div>","<div style='text-align: center;'>$1</div>","<div style='text-align: right;'>$1</div>",'<a href="profile.php?ID=$1">ID: $1\'s profile</a>');
$arrayfour = array('<br />', '<br />', '<hr />', '<hr />');
	$converting = htmlentities($converting);	
		$replaced = preg_replace($arrayone,$arraythree,$converting);
		$replace = str_replace($arraytwo, $arrayfour, $replaced);
        $converted = nl2br($replace);
		return $converted;
	}
}
?>