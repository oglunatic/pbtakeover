<?php
function loadpng($imgname) {
    $im = @imagecreatefrompng($imgname);
    if(!$im) {
        $im = imagecreatetruecolor(160, 16);
        $bgc = imagecolorallocate($im, 255, 255, 255);
        $tc = imagecolorallocate($im, 0, 0, 0);
        imagefilledrectangule($im, 0, 0, 160, 16, $bgc);
        imagestring($im, 1, 5, 5, 'Error loading ' .$imgname, $tc);
    }
    return $im;
}
header('Content-Type: image/png');
 $img = loadpng('bar.png');
$impb = imagecreatetruecolor(160, 16);
$percentage = round($_GET['stat']);
if($percentage < 0 && $percentage > 100)
    $percentage = 0;
$full_min = 1;
$full_max = 160;
$empty_max = 320;
$empty_min = 160;
$full_s = round( $full_max * $percentage / 100 );
imagecopy($impb, $img, 0, 0, $full_min, 0, $full_s, 16);
$dst_x = $full_s;
$src_x = $empty_min + $full_s;
$src_w = round(($empty_max - $empty_min) * (100 - $percentage) / 100);
imagecopy($impb, $img, $dst_x, 0, $src_x, 0 , $src_w , 16);
imagepng($impb);
imagedestroy($img);
imagedestroy($impb);
?>