<?php
if($_GET['part'] == 'stats') {
echo'<h3>Stats</h3>
<table width="50%" class="table" align="center">
    <tr>
	<td><a href="list.php?l=user">User List</a></td>
    </tr>
    <tr>
	<td><a href="list.php?l=online">Online Users</a></td>
    </tr>
    <tr>
	<td><a href="list.php?l=staff">Staff List</a></td>
    </tr>
    <tr>
	<td><a href="stats.php">Game stats</a></td>
    </tr>
    <tr>
	<td><a href="javascript: fetch(\'explore\');">Back</a></td>
    </tr>
</table>';
exit();
}
elseif($_GET['part'] == 'money') {
echo'<h3>Stats</h3>
<table width="50%" class="table" align="center">
    <tr>
	<td><a href="bank.php">Bank</a></td>
    </tr>
    <tr>
	<td><a href="work.php">Work</a></td>
    </tr>
    <tr>
	<td><a href="javascript: fetch(\'explore\');">Back</a></td>
    </tr>
</table>';
exit();
}
elseif($_GET['part'] == 'town') {
echo'<h3>Explore</h3>
<table width="50%" class="table" align="center">
    <tr>
	<td><a href="search.php">Search</a></td>
    </tr>
    <tr>
    	<td><a href="javascript: fetch(\'explore\');">Back</a></td>
    </tr>
</table>';
exit();
}
else {
echo'<h3>Town</h3>	
<table width="50%" class="table" align="center">
    <tr>
	<td><a href="javascript: fetch(\'town\');">Town</a></td>
    </tr>
    <tr>
	<td><a href="javascript: fetch(\'money\');">Money</a></td>
    </tr>
    <tr>
	<td><a href="javascript: fetch(\'stats\');">Stats</a></td>
    </tr>
</table>';
exit();
}
