<?php
error_reporting(E_ALL);
define('ADD_HALF', true); //keep true so half the cost of the bank is added to the account
define('cost', 1000, true); //open bank cost (half is put in account) default set at $10,000
define('dep_fee', 10, true); //deposit fee in % default set 10%
$querydriver = 'MySqlDB';
require_once(dirname(dirname(__file__)) .'/includes/game.setting.php');
require_once(dirname(dirname(__file__)) .'/includes/settings.db.php');
require_once(dirname(dirname(__file__)) .'/includes/'. $querydriver .'.db.php');
    $db = new $querydriver(host, name, pass, db); //make the connection
define('USERS', ', `money`, `bank`');
require_once(dirname(dirname(__file__)) .'/includes/ajax.users.php');
$user = new user;
$user->init($_COOKIE['userid']);
    if($_GET['cmd'] == 'open') {
    if($user->money < cost ) {
        echo'You dont have enough money to open a bank account.<br /><br />';
        exit();
    }
    $bank = ( ADD_HALF == true ) ? (cost / 2) : 0;
        $db->execute('UPDATE `users` SET `money` = `money` - '. cost .', `bank` = '. $bank .' WHERE (`userid` = '. $_COOKIE['userid'] .') LIMIT 1;');
	if($db->affected_rows()) {
	    echo'You have opened a bank. You were charged '. format( cost , $setting['currency'] ) .'. '. ((ADD_HALF == true) ? 'You now have '. format($bank, $setting['currency']) .' in your account.' : '') .'.<br />';
	}
	else {
	    echo'Something seems to have gone wrong.';
	}
	echo'<br /><a href="bank.php">Refresh</a><br /><br />';
	    exit();
    } else if($_GET['cmd'] == 'withdraw') {
	$_GET['money'] = (isset($_GET['money']) && !empty($_GET['money'])) ? intval($_GET['money']) : false;
	    if($_GET['money'] > $user->bank) {
		echo'You dont have enough money to withdraw this amount.';
		exit();
	    }
	    $db->execute('UPDATE `users` SET `money` = `money` + '. $_GET['money'] .', `bank` = `bank` - '. $_GET['money'] .' WHERE (`userid` = '. $_COOKIE['userid'] .') LIMIT 1;');
		if($db->affected_rows()) {
		    $user->bank -= $_GET['money'];
			echo'You withdrawn '. format($_GET['money'], $setting['currency']) .' from your bank.<br />You now have '. format($user->bank, $setting['currency']) .' in your bank.';
		} else {
				echo'There seems to be an error!';
		}
	echo'<br /><a href="bank.php">Refresh</a><br /><br />';
	    exit();
    } else if($_GET['cmd'] == 'deposit') {
	$_GET['amount'] = (isset($_GET['money']) && !empty($_GET['money'])) ? intval($_GET['money']) : false;
	
	    if($_GET['money'] > $user->money) {
		echo'You dont have enough money to deposit this amount';
		exit();
	    }
		$fee = (($_GET['money']/100) * dep_fee);
		$money = $_GET['money'] - $fee;
		    $db->execute('UPDATE `users` SET `money` = `money` - '. $_GET['amount'] .', `bank` = `bank` + '. $money .' WHERE (`userid` = '. $_COOKIE['userid'] .') LIMIT 1;');
		if($db->affected_rows()) {
		    echo'A total of '. format($money, $setting['currency']) .' has been placed in your bank.<br />There was a '. dep_fee .'% fee taken off, which was a total of '. format($fee, $setting['currency']) .'.';
		} else {
		    echo'Something went wrong.';
		}
	echo'<br /><a href="bank.php">Refresh</a><br /><br />';
	    exit();
    }