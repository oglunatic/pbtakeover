<?php
define('title', 'BBCode', true);
require_once('./system.php');
require_once('./lib/bbcode.php');
$bbcode = new bbcode();
	echo'<table width="60%" class="table" align="center">
			<tr>
				<th colspan="2" width="100%">BBCode</td>
			</tr>
			<tr>
				<th width="50%">Input</th>
				<th width="50%">Output</th>
			</tr>
			<tr>
				<td>[b]Text[/b]</td>
				<td>'. $bbcode->pharse('[b]Text[/b]') .'</td>
			</tr>
			<tr>
				<td>[i]Text[/i]</td>
				<td>'. $bbcode->pharse('[i]Text[/i]') .'</td>
			</tr>
				<td>[u]Text[/u]</td>
				<td>'. $bbcode->pharse('[u]Text[/u]') .'</td>
			</tr>
			<tr>
				<td>[size=20]Text[/size]<br /><small>Max 20</small></td>
				<td>'. $bbcode->pharse('[size=20]Text[/size]') .'</td>
			</tr>
			<tr>
				<td>[color=red]Text[/color]</td>
				<td>'. $bbcode->pharse('[color=red]Text[/color]') .'</td>
			</tr>
			<tr>
				<td>[colour=red]Text[/colour]</td>
				<td>'. $bbcode->pharse('[colour=red]Text[/colour]') .'</td>
			</tr>
			<tr>
				<td>[img]http://www.'. $setting['domain'] .'/images/similies/Heart.png[/img]<br /><small>Extenstions allowed: .jpg, .jpeg .png</small></td>
				<td>'. $bbcode->pharse('[img]http://www.'. $setting['domain'] .'/newengine/images/smilies/Heart.png[/img]') .'</td>
			</tr>
			<tr>
				<td>[sub]Text[/sub]Text</td>
				<td>'. $bbcode->pharse('[sub]Text[/sub]Text') .'</td>
			</tr>
			<tr>
				<td>[sup]Text[/sup]Text</td>
				<td>'. $bbcode->pharse('[sup]Text[/sup]Text') .'</td>
			</tr>
			<tr>
				<td>[big]Text[/big]</td>
				<td>'. $bbcode->pharse('[big]Text[/big]') .'</td>
			</tr>
			<tr>
				<td>[small]Text[/small]</td>
				<td>'. $bbcode->pharse('[small]Text[/small]') .'</td>
			</tr>
			<tr>
				<td>[email=contact@'. $setting['domain'] .']</td>
				<td>'. $bbcode->pharse('[email=contact@'. $setting['domain'] .']') .'</td>
			</tr>
			<tr>
				<td>[email]contact@'. $setting['domain'] .'[/email]</td>
				<td>'. $bbcode->pharse('[email]contact@'. $setting['domain'] .'[/email]') .'</td>
			</tr>
			<tr>
				<td>[left]Text[/left]</td>
				<td>'. $bbcode->pharse('[left]Text[/left]') .'</td>
			</tr>
			<tr>
				<td>[center]Text[/center]</td>
				<td>'. $bbcode->pharse('[center]Text[/center]') .'</td>
			</tr>
			<tr>
				<td>[centre]Text[/centre]</td>
				<td>'. $bbcode->pharse('[centre]Text[/centre]') .'</td>
			</tr>
			<tr>
				<td>[right]Text[/right]</td>
				<td>'. $bbcode->pharse('[right]Text[/right]') .'</td>
			</tr>
			<tr>
				<td>Text[br /]Text</td>
				<td>'. $bbcode->pharse('Text[br /]Text') .'</td>
			</tr>
			<tr>
				<td>Text[br]Text</td>
				<td>'. $bbcode->pharse('Text[br]Text') .'</td>
			</tr>
			<tr>
				<td>Text[hr /]Text</td>
				<td>'. $bbcode->pharse('Text[hr /]Text') .'</td>
			</tr>
			<tr>
				<td>Text[hr]Text</td>
				<td>'. $bbcode->pharse('Text[hr]Text') .'</td>
			</tr>
			<tr>
				<td>[profile=1]</td>
				<td>'. $bbcode->pharse('[profile=1]') .'</td>
			</tr>
		</table>';
$template->endtemplate();