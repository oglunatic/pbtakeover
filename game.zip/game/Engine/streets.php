<?php
define('title', 'Streets');
define('EXTRAUSERS', ', `jail`, `hospital`, `steps`');
require_once('./system.php');
if(($user->hospital > time()) OR ($user->jail > time())) {
    echo'You root around, but find nothing.';
    exit($template->endtemplate());
}
if(isset($_POST['steps']) && $_POST['steps'] >= 1) {
echo'<table width="80%" class="table" align="center">';

    $_POST['steps'] = filter_var($_POST['steps'], FILTER_SANITIZE_NUMBER_INT);
    for($i = 1; $i<= $_POST['steps']; $i++) {
        echo'<tr>
            <td>';
       /* if($_SESSION['stop']) {
            echo'&nbsp;</td></tr></table>';
            exit($template->endtemplate());
            unset($_SESSION['stop']);
        }*/
        $thisstep = $db->obj($db->execute("SELECT * FROM `steps` ORDER BY RAND();"));
        if($thisstep->money != 0) {
            
            $user->money += $thisstep->money;
        }
        if($thisstep->tokens != 0) {
            $user->tokens += $thisstep->tokens;
        }
        if($thisstep->jail != '') {
            $_SESSION['stop'] = 1;
            list($time, $reason) = explode('|', $thisstep->jail);
            $time = time() + 60 * $time;
            $db->execute('UPDATE `users` SET `jail` = '. $time .', `jailreason` = \''. $reason .'\', `steps` = `steps` - 1 WHERE (`userid` = '. $user->userid .');');
            echo str_replace('{time}', $time, $thisstep->step) .'</td></tr></table>';
            exit($template->endtemplate());
        }
        if($thisstep->hospital != '') {
            $_SESSION['stop'] = 1;
            list($time, $reason) = explode('|', $thisstep->hospital);
            $time = time() + 60 * $time;
            $db->execute('UPDATE `users` SET `hospital` = '. $time .', `hospreason` = \''. $reason .'\', `steps` = `steps` - 1 WHERE (`userid` = '. $user->userid .');');
            echo str_replace('{time}', $time, $thisstep->step) .'</td></tr></table>';
            exit($template->endtemplate());
        }
        if($thisstep->fight != 0) {
            $_SESSION['attacking'] = $fight;
            $db->execute('UPDATE `users` SET `steps` = `steps` - 1 WHERE (`userid` = '. $userid .');');
            echo $thisstep->step .'<meta http-equiv="refresh" content="2;attack.php?id='. $thisstep->fight.'" /></td></tr></table>';
            exit($template->endtemplate());
        }
        $step->tokens = ($thisstep->tokens == false || '') ? 0 : $thisstep->tokens;
        $step->money = ($thisstep->money == false || '') ? 0 : $thisstep->money;
        //Dont waste 3 queries
        $db->execute('UPDATE `users` SET `tokens` = `tokens` + '. $step->tokens .', `money` = `money` + '. $step->money .', `steps` = `steps` - 1 WHERE (`userid` = '. $user->userid .');');
        echo str_replace(array('{money}', '{tokens}'), array(format($step->money, $setting['currency']), format($step->tokens)), $thisstep->step);
        echo'</td>
        </tr>';
    }
echo'</table>';
    exit($template->endtemplate());
}
echo'<h2>Streets</h2>
You have '. format($user->steps) .' steps left.
<table width="80%" class="table" align="center">
    <tr>
        <td>How many steps do you want to take?<br /><form action="streets.php" method="post"><input type="text" value="'. $user->steps .'" name="steps" /><br /><input type="submit" value="Search!" /></td>
    </tr>
</table>';
$template->endtemplate();