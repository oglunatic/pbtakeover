<?php
define('title', 'Staff Panel');
define('staffmenu', true);
require_once('./system.php');




$template->endtemplate();
?>