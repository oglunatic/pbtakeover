function login() {
try{
    var user = $('#user').val();
    if(user == '') {
        alert('No username added.');
        return false;
    }
    var pass = $('#pass').val();
    if(pass == '') {
        alert('No password added.');
        return false;
    }
    var url = 'themes/ajax.caller.php?login=true';
    $('.entry').attr('align', 'center');
        $('.entry').html('<img src="themes/ajax.loader.gif" /><br />Checking Username...').delay(600).queue(function() {
            $.post(url, { username: user }, function(data) {
                if(data == 1) {
                    $('.entry').append('<br /><span style="color: green;">Username Validated.</span>');
                    $('.entry').append('<br />Checking Password...');
                    $.post(url, { username: user, password: pass }, function (data) {
                        if(data == 1) {
                            $('.entry').append('<br /><span style="color: green;">Password Validated.</span>');
                            $('.entry').append('<br />Logging you in...<meta http-equiv="refresh" content="2;url=dashboard.php"/>');
                        } //Password true
                        else {
                            $('.entry').append('<br /><span style="color: red;">Invalid Password.</span>');
                            $('.entry').append('<br />Try again...');
                        } //Password false
                    }) //Password check
                } //Username true
                else {
                    $('.entry').append('<br /><span style="color: red;">Invalid Username.</span>');
                    $('.entry').append('<br />Try again...');
                } //Username False
            }) //Username Check
            $.dequeue(this);
        }) //Change image and queue
} catch(err) {
    alert(err)
}
}