<?php global $setting; ?> 
<ul>
	<li>
		<h2>General</h2>
	<ul style="text-align: justify;">
		<li><a href="../admin">Admin Panel</a></li>
		<li><a href="../staff">Staff Panel</a></li>
		<li><a href="settings.php?cmd=game">General Settings</a></li>
		<li><a href="settings.php?cmd=bulletin">Add a <?php echo ($setting['bulletin']); ?></a></li>
	</ul>

		<h2>Users</h2>
	<ul style="text-align: justify;">
		<li><a href="users.php?cmd=add">Add User</a></li>
		<li><a href="users.php?cmd=edit">Edit User</a></li>
		<li><a href="users.php?cmd=delete">Delete User</a></li>
		<li><a href="users.php?cmd=credit">Credit User</a></li>
		<li><a href="users.php?cmd=mass">Mass Credit Users</a></li>
	</ul>
	</li>
</ul>