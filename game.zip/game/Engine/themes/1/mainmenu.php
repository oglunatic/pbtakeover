<?php
global $db, $user, $setting, $vital;
$jailcount = $db->single($db->execute('SELECT COUNT(`userid`) FROM `users` WHERE (`jail` >  '. time() .');'));
$hospcount = $db->single($db->execute('SELECT COUNT(`userid`) FROM `users` WHERE (`hospital` >  '. time() .');'));
?>
<ul>
	<li>
		<h2><?php echo $user->profile(0,0,0,0); ?></h2>
	<ul style="text-align: justify;">
		<li>Username: <?php echo $user->profile(0,1,1);  ?></li>
		<li>Level: <?php echo format($user->level); ?></li>
		<li>Money: <?php echo format($user->money, $setting['currency']); ?></li>
		<li><?php echo ucwords($setting['token']) ?>s: <?php echo format($user->tokens); ?></li>
		<li><?php echo ($user->messages > 0) ? '<span style="font-weight: bold;">' : ''; ?><a href="messages.php"><?php echo ucwords($setting['message']); ?>s: <?php echo format($user->messages); ?></a><?php echo ($user->messages > 0) ? '</span>' : ''; ?></li>
		<li><?php echo ($user->logs > 0) ? '<span style="font-weight: bold;">' : ''; ?><a href="logs.php"><?php echo ucwords($setting['log']) ?>s: <?php echo format($user->logs); ?></a><?php echo ($user->logs > 0) ? '</span>' : ''; ?></li>
		<li><?php echo ($user->bulletins > 0) ? '<span style="font-weight: bold;">' : ''; ?><a href="bulletins.php"><?php echo ucwords($setting['bulletin']) ?>s: <?php echo format($user->bulletins); ?></a><?php echo ($user->bulletins > 0) ? '</span>' : ''; ?></li>
		<li><?php echo ($jailcount > 0) ? '<span style="font-weight: bold;">' : ''; ?><a href="jail.php"><?php echo $setting['jail']; ?>: <?php echo format($jailcount); ?></a><?php echo ($jailcount > 0) ? '</span>' : ''; ?></li>
		<li><?php echo ($hospcount > 0) ? '<span style="font-weight: bold;">' : ''; ?><a href="hospital.php"><?php echo $setting['hospital']; ?>: <?php echo format($hospcount); ?></a><?php echo ($hospcount > 0) ? '</span>' : ''; ?></li>
	</ul>
		<h2>User Bars</h2>
	<ul style="text-align: center;">
		<li><?php echo ucwords($setting['energy']); ?>:<br /> <img src="lib/bars.php?temp=1&stat=<?php echo floor(($vital->energy/$vital->maxenergy)*100); ?>" title="<?php echo ucwords($setting['energy']); ?>: <?php echo format($vital->energy); ?>/<?php echo format($vital->maxenergy); ?>" /></li>
		<li><?php echo ucwords($setting['aware']); ?>: <br /><img src="lib/bars.php?temp=1&stat=<?php echo floor(($vital->aware/$vital->maxaware)*100); ?>" title="<?php echo ucwords($setting['aware']); ?>: <?php echo format($vital->aware); ?>/<?php echo format($vital->maxaware); ?>" /></li>
		<li><?php echo ucwords($setting['audacity']); ?>: <br /><img src="lib/bars.php?temp=1&stat=<?php echo floor(($vital->audacity/$vital->maxaudacity)*100); ?>" title="<?php echo ucwords($setting['audacity']); ?>: <?php echo format($vital->audacity); ?>/<?php echo format($vital->maxaudacity); ?>" /></li>
		<li><?php echo ucwords($setting['health']); ?>:<br /> <img src="lib/bars.php?temp=1&stat=<?php echo floor(($vital->health/$vital->maxhealth)*100); ?>" title="<?php echo ucwords($setting['health']); ?>: <?php echo format($vital->health); ?>/<?php echo format($vital->maxhealth); ?>" /></li>
		<li><?php echo strtoupper($setting['exp']); ?>: <br /><img src="lib/bars.php?temp=1&stat=<?php echo floor(($vital->exp/$vital->maxexp)*100); ?>" title="<?php echo strtoupper($setting['exp']); ?>: <?php echo floor(($vital->exp/$vital->maxexp)*100); ?>%" /></li>
	</ul>
	</li>
</ul>