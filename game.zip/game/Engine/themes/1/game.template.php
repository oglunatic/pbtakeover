<?php

    function starttemplate() {
        global $setting, $user;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<!--Title-->
<title><?php echo ucwords($setting['name']); ?> | <?php echo title; ?></title>
<!--Set the base-->
<base target="_parent">
<!--<base href="<?php echo $setting['domain']; ?>">-->
<!--Search engine...-->
<meta name="title" content="<?php echo ucwords($setting['name']); ?>" />
<meta name="keywords" content="RPG, FREE, free, rpg, online rpg, text based game, mmorpg, text games, action games, pbbg, pbbgs, PHP, MySQL, <?php echo $setting['keywords']; ?>" />
<meta name="description" content="<?php echo $setting['searchdesc']; ?>" />
<!--Site-->
<meta name="author" content="<?php echo $setting['owner']; ?>" />
<meta name="copyright" content="<?php echo $setting['owner']; ?> - 2009-<?php echo date('Y'); ?>" />
<meta name="email" content="webmaster@<?php echo $setting['domain']; ?>" />
<!--Them-->
<meta name="audience" content="all" />
<meta name="Content-Language" content="english" />
<meta name="page-topic" content="Entertainment, Gaming" />
<meta name="reply-to" content="admin@<?php echo $setting['domain']; ?>" />
<meta name="publisher" content="www.<?php echo $setting['domain']; ?>" />
<!--Robots-->
<meta name="robots" content="INDEX,FOLLOW" />
<meta name="revisit-after" content="7 days" />
<!--FavIcon-->
<link rel="icon" href="favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="apple-touch-icon" href="favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="shortcut icon" href="favicon.ico" type="image/vnd.microsoft.icon"  />
<link href="/Engine/themes/1/style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="/Engine/themes/pagination.css" rel="stylesheet" type="text/css" media="screen" />
<noscript>You seem to have your JavaScript turned off. This game is enhanced by JavaScript, and we would like for you to turn it on before you play the game.</noscript>
</head>
<body>
<div id="wrapper">
    <div id="header">
	<div id="logo">
            <h1><a href="home.php"><?php echo ucwords($setting['name']); ?></a></h1>
		</div>
		<!-- end #logo -->
		<div id="menu">
                    <ul>
		<?php $adminfirst = ($user->access == 'a') ? ' class="first"' : ''; $homefirst = ($adminfirst == '') ? ' class="first"' : '';
	    if($user->access == 'a') {
		echo'<li'.$adminfirst.'><a href="/Engine/admin">Admin</a></li>';
	    }
		?>
                        <li<?php echo $homefirst; ?>><a href="/Engine/home.php">Home</a></li>
			<li><a href="/Engine/town.php">Town</a></li>
			<li><a href="/Engine/settings.php">Settings</a></li>
			<li><a href="/Engine/logout.php">Logout</a></li>
                    </ul>
		</div>
		<!-- end #menu -->
    </div>
	<!-- end #header -->
    <div id="page">
	<div id="bgtop">
            <div id="bgbottom">
		<div id="content">
                    <div class="post">
			<div class="title">
                            <h2><a href="#"><?php echo (defined('title')) ? title : 'Home'; ?></a></h2>
			</div>
                            <div class="entry" style="text-align: center;">
<?php
if((defined('adminmenu') || defined('staffmenu')) && $user->access == 'n') {
    echo'You shouldnt be here!';
    exit();
}
    }
    function menu() {
        global $db; // Used to pass it on to the menu
        (defined('adminmenu')) ? require_once('adminmenu.php') : ((defined('staffmenu')) ? require_once('staffmenu.php') : require_once('mainmenu.php'));
	//require_once('mainmenu.php');
    }
    function endtemp() {
        global $start, $setting;
?>
                            </div>
		    </div>
		</div><!-- end #content -->
                <div id="sidebar" style="text-align: center;">
	<?php
	    menu();
	?>
                </div><!-- end #sidebar -->
	    <div style="clear: both;">&nbsp;</div>
	    </div>
	</div>
    </div><!-- end #page -->
    <div id="footer"><p>
<?php
$time = microtime();
$time = explode(" ", $time);
$time = $time[1] + $time[0];
$finish = $time;
$totaltime = ($finish - $start);
//echo'This page took '. $totaltime .' seconds to load.<br />';
printf ("This page took %f seconds to load.<br />", $totaltime);
?>
		Copyright (&copy;) <?php echo date('Y').' '. ucwords($setting['domain']); ?> Design by <a href="http://www.nodethirtythree.com/">NodeThirtyThree</a></p>
    </div><!-- end #footer -->
<div><!-- end #wrapper -->
</body>
</html>
<?php
    }