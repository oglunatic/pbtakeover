<?php
session_start();
ob_start();
ob_end_flush();
global $setting;
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<!--Title-->
<title><?php echo ucwords($setting['name']); ?> | Login</title>
<!--Set the base-->
<base target="_parent">
<!--<base href="<?php echo $setting['name']; ?>">-->
<!--Search engine...-->
<meta name="title" content="<?php echo ucwords($setting['name']); ?>" />
<meta name="keywords" content="RPG, FREE, free, rpg, online rpg, text based game, mmorpg, text games, action games, pbbg, pbbgs, PHP, MySQL, <?php echo $setting['keywords']; ?>" />
<meta name="description" content="<?php echo $setting['searchdesc']; ?>" />
<!--Site-->
<meta name="author" content="<?php echo $setting['owner']; ?>" />
<meta name="copyright" content="<?php echo $setting['owner']; ?> - 2009-<?php echo date('Y'); ?>" />
<meta name="email" content="webmaster@<?php echo $setting['domain']; ?>" />
<!--Them-->
<meta name="audience" content="all" />
<meta name="Content-Language" content="english" />
<meta name="page-topic" content="Entertainment, Gaming" />
<meta name="reply-to" content="admin@<?php echo $setting['domain']; ?>" />
<meta name="publisher" content="www.<?php echo $setting['domain']; ?>" />
<!--Robots-->
<meta name="robots" content="INDEX,FOLLOW" />
<meta name="revisit-after" content="7 days" />
<!--FavIcon-->
<link rel="icon" href="favicon.ico" type="image/vnd.microsoft.icon" />
<link rel="apple-touch-icon" href="favicon.ico" type  ="image/vnd.microsoft.icon" />
<link rel="shortcut icon" href="favicon.ico" type="image/vnd.microsoft.icon"  />
<link href="themes/2/style.css" rel="stylesheet" type="text/css" media="screen" />
<script>!window.jQuery && document.write('<script src="http://code.jquery.com/jquery-1.4.2.min.js"><\/script>');</script> 
<script>document.write('<script type="text/javascript" src="themes/login.js"><\/script>');</script>
<script>document.write('<script type="text/javascript" src="themes/register.js"><\/script>');</script>
<script>
function isNumber(evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode
	if(charCode > 31 && (charCode < 48 || charCode > 57)) {
	    return false;
	}
	return true;
}
</script>

<noscript>You seem to have your JavaScript turned off. This game is enhanced by JavaScript, and we would like for you to turn it on before you play the game.</noscript>
</head>
<body>
<div id="wrapper">
<!-- start header -->
<div id="logo">
	<h1><a href="#"><?php echo ucwords($setting['name']); ?></a></h1>
	<h2> &raquo;&nbsp;&nbsp;&nbsp;Login</h2>
</div>
<div id="header">
	<div id="menu">
		<ul style="text-align: center;">
			<li class="first"><a href="/login.php">Login</a></li>
			<li><a href="/login.php">Register</a></li>
		</ul>
	</div>
</div>
<!-- end header -->
<!-- start page -->
<div id="page">
	<!-- start content -->
	<div id="content">
		<div class="post">
			<div class="title">
				<h2><a href="#"><?php echo ucwords('About '. $setting['name']); ?></a></h2>
			</div>
					<div class="entry">
						<p><?php echo $setting['logindesc']; ?></p>
					</div>
		</div>
				</div>
				<!-- end #content -->
				<div id="sidebar" style="text-align: center;">
					<ul style="text-align: center;">
                                                <li>
							<h2>Login</h2>
							<form action="javascript: login();">
								<input type="hidden" name="cmd" value="login"> 
								<label for="user">Username:</label><br />
									<input type="text" name="user" id="user" value=""><br />
								<label for="password">Password:</label><br />
									<input type="password" name="pass" id="pass" value=""><br /><br />
								<input type="submit" value="Login!" class="button" name="login" /><br />
									</form>
						</li>
						<li>
							<h2>Register</h2>
							<form action="javascript: register();">
							<input type="hidden" name="cmd" value="register"> 
								<label for="username">Username:</label><br />
									<input type="text" name="username" id="username" value=""><br />
								<label for="password">Password:</label><br />
									<input type="password" name="password" id="password" value=""><br />
								<label for="passcheck">Confirm Password:</label><br />
									<input type="password" name="passcheck" id="passcheck" value=""><br />
								<label for="email">Email:</label><br />
									<input type="text" name="email" id="email" value=""><br />
								<label for="code">Captcha:</label><br />
									<img src="lib/Captcha.php" id="cap"><br />
									<input type="text" name="code" id="code" value="" onKeyPress="return isNumber(event)"><br /><br />
								<input type="submit" value="Register!" class="button" name="register" />
									</form>
						</li>
					</ul>
				</div>
				<!-- end #sidebar -->
				<div style="clear: both;">&nbsp;</div>
			</div>
		</div>
	</div>
	<!-- end #page -->
	<div id="footer">
		<p id="legal">Copyright (&copy;) <?php echo date('Y').' '. ucwords($setting['domain']); ?> Design by <a href="http://www.nodethirtythree.com/">NodeThirtyThree</a> and <a href="http://www.freecsstemplates.org/">FreeCSSTemplates</a></p>
	</div>
	<!-- end #footer -->
</div>
<!-- end #wrapper -->
</body>
</html>
