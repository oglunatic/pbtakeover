function register() {
try{
    var user = $('#username').val(); if(user == '') {alert('No username added.');return false;}
    var pass = $('#password').val(); if(pass == '') {alert('No password added.');return false;}
    var cpass = $('#passcheck').val(); if(cpass == '') {alert('No confirmation password added.'); return false;}
    var email = $('#email').val(); if(email == '') {alert('No email added.'); return false;}
    var code = $('#code').val(); if(code == '') {alert('You didn\'t enter the captcha.'); return false;}
    var url = 'themes/ajax.caller.php?register=true';
    var url2 = 'themes/ajax.caller.php';
    $('.entry').attr('align', 'center');
        $('.entry').html('<img src="themes/ajax.loader.gif" /><br />Checking Username...').delay(600).queue(function() {
            $.post(url, { username: user }, function(data) {
            if(data == 0) {
                $('.entry').append('<br /><span style="color: green;">Username Available.</span>').fadeIn(300);
                $('.entry').append('<br />Checking Password...').fadeIn(300);
                    if(pass == cpass) {
                        $('.entry').append('<br /><span style="color: green;">Password Verified.</span>').fadeIn(300);
                        $('.entry').append('<br />Checking Email...').fadeIn(300);
                            $.post(url, { email: email }, function(data) {
                                if(data == 1) {
                                    $('.entry').append('<br /><span style="color: green;">Email Verified.</span>').fadeIn(300);
                                    $('.entry').append('<br />Checking Captcha...').fadeIn(300);
                                        $.post(url, { code: code }, function(data) {
                                            if(data == 1) {
                                                $('.entry').append('<br /><span style="color: green;">Captcha Verified.</span>').fadeIn(300);
                                                $('.entry').append('<br />Registering User...').fadeIn(300);
                                                    $.post(url2, { reguser: 'true',username: user, password: pass, email: email }, function(data) {
                                                        if(data == 1) {
                                                            $('.entry').append('<br /><span style="color: green;">User has been registered.</span>');
                                                            $('.entry').append('<br />Logging you in.<meta http-equiv="refresh" content="2;url=dashboard.php"/>');
                                                        }
                                                        else {
                                                            $('.entry').append('<br /><span style="color: red;">Something has gone wrong. See below for details.</span>');
                                                            $('.entry').append('<br /><br />' + data);
                                                            return false;
                                                        }
                                                    })
                                            }
                                            else {
                                                $('.entry').append('<br /><span style="color: red;">Captcha Does not match.</span>').fadeIn(300);
                                                $('.entry').append('<br />Try again...<script>reloadcap();</script>').fadeIn(300);
                                                return false;
                                            } 
                                        });
                                }
                                else {
                                    $('.entry').append('<br /><span style="color: red;">False Email.</span>').fadeIn(300);
                                    $('.entry').append('<br />Try again...<script>reloadcap();</script>').fadeIn(300);
                                    return; 
                                }
            });
                    }
                    else {
                        $('.entry').append('<br /><span style="color: red;">Passwords do not match.</span>').fadeIn(300);
                        $('.entry').append('<br />Try again...<script>reloadcap();</script>').fadeIn(300);
                        return false;
                    }
            }
            else {
                $('.entry').append('<br /><span style="color: red;">Username Taken.</span>').fadeIn(300);
                $('.entry').append('<br />Try again...<script>reloadcap();</script>').fadeIn(300);
                return false;
            }
            });
            $.dequeue(this);
        }) //Change image and queue
} catch(err) {
    alert(err)
}
}
function reloadcap() {
try{
    $('#cap').attr('src', 'lib/Captcha.php');
} catch(err) {
    alert(err);
}
}