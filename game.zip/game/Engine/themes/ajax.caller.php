<?php
//Get settings
session_start();
require_once(dirname(dirname(__file__)) .'/includes/game.setting.php');
global $setting;
    //Start the DB
	require_once(dirname(dirname(__file__)) .'/includes/'. $setting['querydriver'] .'.db.php');
	require_once(dirname(dirname(__file__)) .'/includes/settings.db.php');
		$db = new $setting['querydriver'](host, name, pass, db); //make the connection
//////////////////////Login////////////////////////////////
//Username
if(isset($_REQUEST['username'], $_REQUEST['login']) && !isset($_REQUEST['password'])) {
    $_REQUEST['username'] = mysql_real_escape_string($_REQUEST['username']);
        $count = $db->obj($db->execute('SELECT COUNT(`userid`) AS `cnt` FROM `users` WHERE (`username` = "'. $_REQUEST['username'] .'")));');
        //echo $count->cnt;
        echo 1;
}
//Password
if(isset($_REQUEST['username'], $_REQUEST['login'], $_REQUEST['password'])) {
    require_once(dirname(dirname(__FILE__)) .'/includes/password.php');
        $password = new password;
            $salt = $db->obj($db->execute('SELECT `salt`, `userid`, `password` FROM `users` WHERE (`username` = "'. $_REQUEST['username'] .'");'));
            $email = $db->single($db->execute('SELECT `email` FROM `email` WHERE (`userid` = '. $salt->userid .');'));
           $pass = $password->newpass($_REQUEST['password'], $email, $salt->salt);
            if($pass != $salt->password) {
                echo 0;
                exit();
            }
            $_SESSION['userid'] = $salt->userid;
	    $_SESSION['justloggedin'] = 1;
	    $db->execute('UPDATE `users` SET `last_login` = unix_timestamp(), `last_ip` = "'. $_SERVER['REMOTE_ADDR'] .'" WHERE (`userid` = '. $salt->userid .');');
            setcookie('loggedin', 1, time()+60*60*24*30, '/');
	    setcookie('userid', $salt->userid, time()+60*60*24*30, '/');
	    
            echo 1;
}
/////////////////////Register//////////////////////////
// Username
if(isset($_REQUEST['username'], $_REQUEST['register'])) {
    $_REQUEST['username'] = mysql_real_escape_string($_REQUEST['username']);
        $count = $db->obj($db->execute('SELECT COUNT(`userid`) AS `cnt` FROM `users` WHERE (`username` = "'. $_REQUEST['username'] .'");'));
        echo $count->cnt;
}
//Email
if(isset($_REQUEST['email'], $_REQUEST['register'])) {
    	if(!filter_var($_REQUEST['email'], FILTER_VALIDATE_EMAIL)) {
	    echo 0;
            exit();
	}
	    list($before, $domain) = explode('@', $_REQUEST['email']);
	if(!checkdnsrr($domain, 'MX')) {
	    echo 0;
            exit();
	}
         $count = $db->obj($db->execute('SELECT COUNT(`userid`) AS `cnt` FROM `email` WHERE (`email` = "'. $_REQUEST['email'] .'");'));
        if($count->cnt) {
            echo 0;
            exit();
        }
	echo 1;
}

if(isset($_REQUEST['code'], $_REQUEST['register'])) {
    //if($_REQUEST['code'] != $_SESSION['security_code']) {
     //   echo 0;  //    exit();
  //  }
    echo 1;    
}

if(isset($_REQUEST['reguser'], $_REQUEST['username'], $_REQUEST['password'], $_REQUEST['email'])) {
        require_once(dirname(dirname(__FILE__)) .'/includes/password.php');
        $password = new password;
            $salt = $password->newsalt();
        $pass = $password->newpass($_REQUEST['password'], $_REQUEST['email'], $salt);
        
        $db->execute('INSERT INTO `users` (`userid`, `username`, `password`, `salt`, `last_login`, `last_ip`) VALUES (NULL, \''. mysql_real_escape_string($_REQUEST['username']) .'\',\''. $pass .'\', \''. $salt .'\', unix_timestamp(), \''. $_SERVER['REMOTE_ADDR'] .'\');') or die(mysql_error());
        $userid = mysql_insert_id();
        $db->execute('INSERT INTO `email` VALUES (LAST_INSERT_ID(), \''. mysql_real_escape_string($_REQUEST['email']) .'\');') or die(mysql_error());
        $db->execute('INSERT INTO `user_bars` (`userid`) VALUES (LAST_INSERT_ID());') or die(mysql_error());

            setcookie('loggedin', 1, time()+60*60*24*30, '/');
	    setcookie('userid', $userid, time()+60*60*24*30, '/');
    echo 1;
}