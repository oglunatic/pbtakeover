<?php
class template {
	private $template;
	private $loaded;
	public function __construct($temp) {
		$this->template = intval($temp);
	}
	//This is the function called to include the template
	public function template_load() {
	(is_dir('themes/'.$this->template)) ? require_once($this->template .'/game.template.php') : require_once('1/game.template.php');
	    $this->loaded = true;
	}
	//This is the function called to create the template.
	public function template_init() {
		if(!$this->loaded && $this->template) { $this->template_load(); }
		if($this->loaded) {
			starttemplate(); // This functions defined in template file
		}
		else {
			die("Template error. Please refresh and try again.");
		}
	}
	public function endtemplate() {
		if($this->loaded) {
			endtemp(); // This functions defined in template file
		}
		else {
			die("Template error. Please refresh an try again.");
		}
	}
}