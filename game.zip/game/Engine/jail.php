<?php
define('title', 'Jail', true);
define('cost', 2000, true); // cost * their level 
require_once('./system.php');
	$_GET['cmd'] = (isset($_GET['cmd']) && !empty($_GET['cmd'])) ? trim($_GET['cmd']) : false;
	$_GET['ID'] = (isset($_GET['ID']) && !empty($_GET['ID'])) ? intval($_GET['ID']) : false;
    switch($_GET['cmd']) {
	case 'bail' : bail(); break;
	default : jail(); break;
    }
function jail( ) {
global $db, $template, $setting, $user;
    $jails = $db->execute('SELECT `userid`, `jail`, `jailreason` FROM `users` WHERE (`jail` > '. time() .');');
	echo'<table width="100%" class="table" align="center">
		<tr>
		    <th width="25%">Name</th>
		    <th width="25%">Time</th>
		    <th width="25%">Reason</th>
		    <th width="25%">Links</th>
	    	</tr>';
        if(!$db->num_rows($jails)) {
            echo'<tr>
                    <td colspan="4">No one is in '. $setting['jail'] .'</td>
                </tr>
                </table>';
                    exit($template->endtemplate());
        }
	while($jail = $db->obj($jails)) {
	    echo'<tr>
    		<td>'. $user->profile($jail->userid, 1, 1) .'</td>
    		<td>'. timeleft($jail->jail) .'</td>
		<td>'. $jail->jailreason .'</td>
		<td><a href="jail.php?cmd=bail&ID='. $jail->userid .'">Bail</a></td>
		</tr>';
        }
	echo'</table>';
}
function bail( ) {
global $db, $user, $template;
    $jail = $db->obj($db->execute('SELECT `userid`, `username`, `level`, `jail` FROM `users` WHERE (`userid` = '. intval($_GET['ID']) .') LIMIT 1;'));
        if($jail->userid == 0) {
            echo'This isn\'t a real user.';
            exit($template->endtemplate());
        }
	if($jail->jail <= time()) {
	    echo'This user isn\'t in '. strtolower($setting['jail']) .'.';
            exit($template->endtemplate());
        }
	$cost = intval( cost * $jail->level );
	if($user->money < $cost) {
            echo'You don\'t have enough money to bail '. $jail->username .'.';
            exit($template->endtemplate());
        }
        $db->execute('UPDATE `users` SET `money` = `money` - '. $cost .' WHERE (`userid` = '. $user->userid .') LIMIT 1;');
        $db->execute('UPDATE `users` SET `jail` = '. time() .' WHERE (`userid` = '. $jail->userid .') LIMIT 1;');
	echo'You bailed '. $jail->username .' out of '. strtolower($setting['jail']) .' at a cost of '. format($cost, $setting['currency']) .'.';
	$user->logger('You were bailed out of '. strtolower($setting['jail']) .' by '. $user->username .'.', $jail->userid);
	}
$template->endtemplate();
?>