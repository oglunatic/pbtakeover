<?php
session_start();
//Get settigns NB: This is used in the login file, its not just a waste
require_once('./includes/game.setting.php');
global $setting;
//Check Installed
//if(is_dir('install')) {
//    header('Location: install/install.php');
//}
//Which template do we use?
$templateid = (isset($_COOKIE['template'])) ? intval($_COOKIE['template']) : $setting['template'];
//Check loggedin
if(isset($_COOKIE['loggedin']) && isset($_COOKIE['userid'])) {
    header('Location: dashboard.php');
}
//Login/sign up is ajax, so we only need the login file...
require_once('./themes/'. $templateid .'/login.php');