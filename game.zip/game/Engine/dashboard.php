<?php
define('title', 'Dashboard');
define('EXTRAUSERS', ', `last_login`');
require_once('./system.php');
echo'<div id="name">Welcome back '. ucwords($user->username) .'.<br />The last time we saw you was on '. date('j F, Y, g:i:s a', $user->last_login).' </div>
<table width="80%" class="table" align="center">
<tr>
	<th width="60%">'. ucwords($setting['name']) .' news.</th>
	<th>Last 5 '. strtolower($setting['log']) .'s</th>
</tr><tr>
	<td>'. $setting['news'] .'</td>
	<td>
<table width="100%" class="table">
<tr>
	<th>Event</th>
</tr>';
$logs = $db->execute('SELECT `log` FROM `logs` WHERE ((`to` = '. $userid .') AND (`deleted` = 0)) ORDER BY `ID` DESC LIMIT 5;');
if($db->num_rows($logs) == 0) {
echo'<tr>
	<td>No '. $setting['log'] .'s</td>
</tr>';
} else {
while($log = $db->obj($logs)) {
echo'<tr>
	<td>'. $log->log .'</td>
</tr>';
}
}
echo'</table>
	</td>
</tr>
</table>';
$template->endtemplate();