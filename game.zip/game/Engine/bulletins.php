<?php
define('title', 'Bulletins');
require_once('./system.php');
    $limit = (isset($_GET['show']) && !empty($_GET['show'])) ? '' : ' LIMIT 15';
    echo'<h2>'. ucwords($setting['bulletin']) .'s</h2>';
        $bulletins = $db->execute('SELECT * FROM `bulletins`  ORDER BY `id` DESC'. $limit .';');
	if(empty($_GET['show'])) {
            echo'Showing last 15 '. strtolower($setting['bulletin']) .'s<br /><a href="bulletins.php?show=1">Show all '. strtolower($setting['bulletin']) .'s.</a>';
        } else {
            echo'Showing all '. strtolower($setting['bulletin']) .'s.<br /><a href="bulletins.php">Show last 15 '. strtolower($setting['bulletin']) .'s.</a>';
        }
	echo'<table width="100%" class="table" align="center">
		<tr>
                    <th width="25%">Time</th>
                    <th width="65%">'. ucwords($setting['bulletin']) .'</th>
		</tr>';
	if(!$db->num_rows($bulletins)) {
	echo'	<tr>
			<td colspan="2">No '. strtolower($setting['bulletin']) .'s have been announced yet.</td>
		</tr>
	    </table>';
	exit($template->endtemplate());
        }
	while($bulletin = $db->obj($bulletins)) {
		echo'<tr>
				<td>'. date('jS F Y, g:i:s a', $bulletin->time) .'</td>
				<td>'. stripslashes($bulletin->bulletin) .'</td>
			</tr>';
        }
	echo'</table>';
$db->execute('UPDATE `users` SET `bulletins` = 0 WHERE (`userid` = '. $user->userid .');');
$user->bulletins = 0;
$template->endtemplate();
?>
