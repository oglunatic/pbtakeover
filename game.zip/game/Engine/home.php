<?php
define('title', 'Home');
define('EXTRAUSERS', ', `work`, `bank`');
require_once('./system.php');
    list($user->job, $user->timeleft) = explode('|', $user->work);// $user->extra['work']);
echo'
<table width="95%" class="table" align="center">
	<tr>
		<td width="25%">Username:</td>
		<td width="25%">'. $user->profile(0,0,1,0) .'</td>
		<td width="25%">Level:</td>
		<td width="25%">'. format($user->level) .'</td>
	</tr>
	<tr>
		<td>Bank:</td>
		<td>'. (($user->extra['bank'] >= 0) ? format($user->bank, $setting['currency']) : 'No bank') .'</td>
		<td>Access:</td>
		<td>'. access($user->access) .'</td>
	</tr>
	<tr>
		<td>'. ucwords($setting['money']) .'</td>
		<td>'. format($user->money, $setting['currency']) .'</td>
		<td>'. ucwords($setting['token']) .'s</td>
		<td>'. format($user->tokens) .'</td>
	</tr>
	<tr>
		<td colspan="2">Working:</td>
		<td colspan="2">'. (($user->timeleft >= time()) ? worktime($user->timeleft) : 'Not working') .'</td>
	</tr>
</table>';
$template->endtemplate(); 