<?php
$_GET['l'] = (isset($_GET['l']) && !empty($_GET['l'])) ? strtolower(trim($_GET['l'])) : 'user';
define('title', ucwords($_GET['l']) .' list', true);
require_once('./system.php');
require_once('./includes/pagination.php');
	switch($_GET['l']) {
		case 'user' : user(); break;
		case 'staff' : staff(); break;
		case 'online' : online(); break;
		default : user(); break;
	}
function user() {
global $user, $db, $setting, $template;
	$items = 25;  // per page
	$_GET['page'] = (isset($_GET['page']) && !empty($_GET['page'])) ? intval($_GET['page']) : false;
	$count = $db->single($db->execute('SELECT COUNT(`userid`) FROM `users` ORDER BY `userid` ASC;'));
	$page = 1;
if(!empty($_GET['page']) && $page = $_GET['page']) {
	$limit = (($page - 1) * $items) .", $items";
} else {
	$limit = $items;
}
	$p = new pagination;
	$p->target('list.php?l=user');
	$p->items($count);
        $p->parameterName('page');
	$p->limit($items);
	$p->showcounter(true);
	$p->currentPage($page);
	echo'<table width="100%" class="table" align="center">';
	if($count > $limit || ($_GET['page'] == 2)) {//Strange really, if on page two, it doesnt work, so lets manually set it up
	echo'<tr>
		<td>
		    <table width="100%" class="table" align="center">
			<tr>
			    <th><h3>Pages</h3>';
	$p->show();
	}
	$width = round(100/6, 2) .'%';
			echo'</th>
			</tr>
		    </table>
		</td>
	    </tr>
	    <tr>
		<th>
		    <table width="100%" class="table" align="center">
			<tr>
			    <td width="'. $width .'">Name</td>
			    <td width="'. $width .'">Level</td>
			    <td width="'. $width .'">'. ucwords($setting['token']) .'s</td>
			    <td width="'. $width .'">'. ucwords($setting['money']) .'</td>
			    <td width="'. $width .'">Online</td>
			    <td width="'. $width .'">Links</td>
			</tr>';
	$users = $db->execute('SELECT `username`, `userid`, `level`, `tokens`, `money`, `laston` FROM `users` LIMIT '. $limit .';');
		while($list = @$db->obj($users)) {
		echo'<tr>
				<td>'. $user->profile($list->userid) .'</td>
				<td>'. format($list->level) .'</td>
				<td>'. format($list->tokens) .'</td>
				<td>'. format($list->money, $setting['currency']) .'</td>
				<td>'. (($list->laston < time()-60*15) ? '<span style="color: red;">Offline</span>' : '<span style="color: green;">Online</span>') .'</td>
				<td>'. $user->profile($list->userid,1,0,1) .'</td>
			</tr>';
		}
			echo'</table>
			</th>
		</tr>
	</table>';
	exit($template->endtemplate());
}
function staff() {
global $db, $user, $template;
echo'<table width="100%" class="table" align="center"><tr>';
$width = round(100/4, 2) .'%';
echo'<th>
	<table width="100%" class="table" align="center">
	    <tr>
		<td width="'. $width .'">Name</td>
		<td width="'. $width .'">Access Level</td>
		<td width="'. $width .'">Online</td>
		<td width="'. $width .'">Links</td>
	    </tr>';
	$users = $db->execute('SELECT `username`, `userid`, `access`, `laston` FROM `users` WHERE (`access` != \'n\');');
	    while($list = $db->obj($users)) {
		echo'<tr>
				<td>'. $user->profile($list->userid) .'</td>
				<td>'. access($list->access, false, 'name') .'</td>
				<td>'. (($list->laston < time()-60*15) ? '<span style="color: red;">Offline</span>' : '<span style="color: green;">Online</span>') .'</td>
				<td>'. $user->profile($list->userid,1,0,1) .'</td>
			</tr>';
	    }
	echo'</table></th></tr></table>';
	exit($template->endtemplate());
	}
function online() {
global $user, $db, $template, $setting;
	$time = time()-900; // 15 minutes
	$items = 25;  // per page
	$_GET['page'] = (isset($_GET['page']) && !empty($_GET['page'])) ? intval($_GET['page']) : false;
	$count = $db->single($db->execute('SELECT COUNT(`userid`) FROM `users` WHERE (`laston` >= '. $time .')'));
	//die("");
	$page = 1;
if(!empty($_GET['page']) && $page = $_GET['page']) {
	$limit = (($page - 1) * $items) .", $items";
} else {
	$limit = $items;
}
	$p = new pagination;
	$p->target('list.php?l=online');
	$p->items($count);
        $p->parameterName('page');
	$p->limit($items);
	$p->showcounter(true);
	$p->currentPage($page);
	echo'<table width="100%" class="table" align="center">';
	if($count > $limit || ($_GET['page'] == 2)) { //Strange really, if on page two, it doesnt work, so lets manually set it up
	echo'<tr>
		<td>
		    <table width="100%" class="table" align="center">
			<tr>
			    <th><h3>Pages</h3>';
	$p->show();
	}
	$width = round(100/5, 2) .'%';
	echo'</th>
		    </tr>
			</table>
			</td>
		    </tr>
		<tr>
			<th>
			    <table width="100%" class="table" align="center">
				<tr>
					<td width="'. $width .'">Name</td>
					<td width="'. $width .'">Level</td>
					<td width="'. $width .'">Laston</td>
					<td width="'. $width .'">Access Level</td>
					<td width="'. $width .'">Links</td>
				</tr>';
	$users = $db->execute('SELECT `username`, `userid`, `level`, `access`, `laston` FROM `users` WHERE (`laston` >= '. $time .') LIMIT '. $limit .';');
	while($list = $db->obj($users)) {
		echo'<tr>
			<td>'. $user->profile($list->userid) .'</td>
			<td>'. format($list->level) .'</td>
			<td>'. laston($list->laston) .'</td>
			<td>'. access($list->access, false, 'name') .'</td>
			<td>'. $user->profile($list->userid,1,0,1) .'</td>
		</tr>';
	}
		echo'</table></th></tr></table>';
	exit($template->endtemplate());
	}
$template->endtemplate();