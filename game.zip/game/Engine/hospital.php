<?php
define('title', 'Hospital', true);
require_once('./system.php');
$hosp = $db->execute('SELECT `userid`, `hospital`, `hospreason` FROM `users` WHERE (`hospital` > '. time() .');');
echo'<table width="100%" class="table" align="center">
        <tr>
            <th width="33.3%">Name</th>
            <th width="33.4%">Time</th>
            <th width="33.3%">Reason</th>
    	</tr>';
	if(!$db->num_rows($hosp)) {
            echo'<tr>
                    <td colspan="4">No-one is in '. $setting['hospital'] .'</td>
	    	</tr>
	    </table>';
	exit($template->endtemplate());
        }
	while($hosp = @$db->obj($hosp)) {
	    echo'<tr>
		    <td>'. $user->profile($hosp->userid, 1, 1) .'</td>
                    <td>'. timeleft($hosp->hospital) .'</td>
                    <td>'. @$hosp->hospreason .'</td>
	    	</tr>';
        }
	echo'</table>';
$template->endtemplate(); 
?>