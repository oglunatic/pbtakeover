<?php
define('title', 'User Properties');
define('adminmenu', true);
require_once('../system.php');

switch($_GET['cmd']) {
    case 'add' : gamesettings(); break;
    case 'edit' :  bulletin(); break;
    case 'delete' :  bulletin(); break;
    case 'credit' :  bulletin(); break;
    case 'mass' :  bulletin(); break;
    default : header('Location: admin'); break;
}
