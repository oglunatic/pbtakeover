<?php
define('title', 'Admin Settings');
define('adminmenu', true);
require_once('../system.php');

switch($_GET['cmd']) {
    case 'game' : gamesettings(); break;
    case 'bulletin' :  bulletin(); break;
    default : header('Location: admin'); break;
}



function bulletin() {
global $setting, $template;
    if(isset($_POST['bulletin'])) {
        global $db;
        $coms = (isset($_POST['comments'])) ? (($_POST['comments'] == 'on') ? '1' : '0') : '0';
        $value = (file_exists('../bulletin_comments.php')) ?
$db->execute('INSERT INTO `bulletins` VALUES (NULL, \''. strip_tags(mysql_real_escape_string($_POST['bulletin']), '<b><u><i><span>') .'\', '. time() .' ,'. $coms .');')
: $db->execute('INSERT INTO `bulletins` VALUES (NULL, \''. strip_tags(mysql_real_escape_string($_POST['bulletin']), '<b><u><i><span>') .'\', '. time() .');');
        $db->execute('UPDATE `users` SET `bulletins` = `bulletins` + 1;');
        echo $setting['bulletin'] .' has been added!';
        exit($template->endtemplate());
    }
    echo'<h3>Adding a new bulletin</h3>
    
    <form action="" method="post">
    <textarea name="bulletin" style="width: 461px; height: 227px;"></textarea><br />';
echo (file_exists(dirname(dirname(__FILE__)) . '/bulletin_comments.php')) ? '<input type="checkbox" name="comments" checked="checked" /> Enable comments for this '. strtolower($setting['bulletin']) .'?<br />' : '';
    echo'<input type="submit" value="Post!" />';
}


function gamesettings() {
    global $setting;
    if(isset($_POST['name'])) {
$content = '<?php
$setting = array();
';

        foreach($_POST as $k => $v) {
            $content .= '$setting[\''. $k .'\'] = '. ((is_numeric($v)) ? $v : '\''. $v .'\'') .';
';
        }
$content .= '$setting[\'querydriver\'] = \'MySqlDB\';
$setting[\'domain\'] = \'relaxdev.com/Engine\'; //no trailing / and no http://www.';
file_put_contents(dirname(dirname(__FILE__)) .'/includes/game.setting.php', $content);
echo'Settings have been saved.';
global $template;
    exit($template->endtemplate());
    }

    echo'<table width="100% class="table" algin="center">
    <tr>
        <th width="50%">Name</th>
        <th>Value</th>
    </tr><tr><th colspan="2"></td></tr>
    <form action="" method="post">';
    $leaveout = array('querydriver', 'domain');
    $textarea = array('searchdesc', 'logindesc', 'news');
    foreach($setting as $name => $value) {
        if(in_array($name, $leaveout)) {} else {
            if(in_array($name, $textarea)) {
                echo'<tr><th>'. ucwords($name) .'</th><td><textarea name="'. $name .'" cols="20" rows="10">'. $value .'</textarea></td></tr>';
            } else {
                echo'<tr><th>'. ucwords($name) .'</th><td><input type="text" name="'. $name .'" value="'. $value .'" /></tr>';
            }
        }
    }
echo'<tr>
        <th colspan="2"><input type="submit" value="Save!" /></th>
    </tr>
</table>';
}


$template->endtemplate();
?>