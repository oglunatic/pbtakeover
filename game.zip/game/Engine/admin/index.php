<?php
define('title', 'Admin Panel');
define('adminmenu', true);
require_once('../system.php');
echo'<h3>Admin Notepad</h2>';
if(isset($_POST['notepad'])) {
file_put_contents('adminpanel.txt', $_POST['notepad']);
echo'The notepad has been updated.';
}
$notepad = file_get_contents('adminpanel.txt');
echo'<form action="" method="post">
<textarea name="notepad" style="width: 461px; height: 227px;">'. stripslashes($notepad) .'</textarea><br /><input type="submit" value="Save!" /></form>';


$template->endtemplate();
?>