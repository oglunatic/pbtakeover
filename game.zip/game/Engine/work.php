<?php
define('EXTRAUSERS', ', `work`');
define('title', 'Work', true);
require_once('./system.php');
addjquery();
addupdater();
?>
<script type="text/javascript">
function start(id) {
try {
    $.get('lib/work.caller.php?ID=' + id, function(data) {
        update(data, 'work');
    })
    
} catch(err) {
    alert(err)
}
}
</script>
<?php
    list($user->time, $user->job) = explode('|', $user->work);
	echo'<h2>Welcome to the job centre.</h2>
                <div id="work"></div>';
    if(($user->job && $user->time) != 0) {
        $work = $db->single($db->execute('SELECT `name` FROM `work` WHERE (`id` = '. $user->job .') LIMIT 1;'));
        $link = 'off';
            echo'You are currently working as a '. $work .'.<br />You have '. timeleft($user->time) .' left.';
    }
    $worke = $db->execute('SELECT * FROM `work` ORDER BY `id` ASC;');
	echo'<table width="100%" class="table" align="center">
		<tr>
                    <th>Name</th>
                    <th>Description</th>
                    <th width="18%">Days</th>
                    <th width="18%">'. $setting['money'] .'<!-- earned--></th>
                    <th width="18%">'. $setting['token'] .'s<!-- earned--></th>
		</tr>';
	if(!$db->num_rows($worke)) {
            echo'<tr>
                    <td colspan="5">No jobs have been set up yet.</td>
                </tr></table>';
            exit($template->endtemplate());
        }
        while($work = @$db->obj($worke)) {
            echo'<tr>
                    <td><a href="javascript: start('. $work->id .');">'. $work->name .'</a></td>
                    <td>'. $work->desc .'</td>
                    <td>'. worktime($work->seconds) .'<t/d>
                    <td>'. format($work->money, $setting['currency']) .'</td>
                    <td>'. format($work->tokens) .'</td>
                </tr>';
        }
        echo'</table>';
    $template->endtemplate();
?>