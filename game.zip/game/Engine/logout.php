<?php
setcookie('loggedin', 0, time()-60*60*24*30, '/');
setcookie('userid', 0, time()-60*60*24*30, '/');
session_start();
foreach($_SESSION as $name => $value) {
    unset($_SESSION[$name]);
}
session_destroy();
header('Location: login.php');