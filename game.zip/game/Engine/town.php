<?php
define('title', 'Town');
require_once('./system.php');
addjquery();
addupdater();
?><script type="text/javascript">function fetch(what){try{var get="lib/town.caller.php?part="+what;$.get(get, function(page){update(page,"explore");});} catch(err){alert("Error: "+err);}}</script><?php
echo'<div id="explore">
      <h3>Town</h3>	
	<table width="80%" class="table" align="center">
		<tr>
			<td width="100%"><a href="javascript: fetch(\'town\');">Explore</a></td>
		</tr>
		<tr>
			<td width="100%"><a href="javascript: fetch(\'money\');">Money</a></td>
		</tr>
		<tr>
			<td width="100%"><a href="javascript: fetch(\'stats\');">Stats</a></td>
		</tr>
	</table>
      </div>';
$template->endtemplate();
?>
