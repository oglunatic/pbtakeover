<?php
if(!defined('EXTRAUSERS')) {
	define('EXTRAUSERS', '');
}
class users {
	public function __construct($userid) { global $db;
        $this->userid = intval($userid);
        $user = $db->obj($db->execute('SELECT `username`, `level`, `access`, `money`, `tokens`, `messages`, `logs`, `bulletins`, `laston`, `last_ip`'. EXTRAUSERS .' FROM `users`WHERE (`userid` = '. $userid .');'));
            foreach($user as $key => $value) {
                is_string($key) ? $this->$key = $value : false;
            }
	}
	public function profile($_userid = 0, $link = true, $addid = true, $profile = false) { global $db; $_userid = ($_userid == 0) ? intval($this->userid) : $_userid;
        $user = $db->obj($db->execute('SELECT `username` FROM `users` WHERE (`userid` = '. $_userid .');'));
		$output = ($link == true) ? '<a href="profile.php?ID='. $_userid .'">' : '';
		$output .= ($profile == true) ? ucwords($user->username) .'\'s Profile.' : ucwords($user->username);
		$output .= ($addid == true) ? ' ['. number_format($_userid) .']' : '';
		$output .= ($link == true) ? '</a>' : '';
	return $output;
	}
	public function logger($log, $_userid = 0) {
		global $db;
			$userid = ($_userid == 0) ? $this->userid : intval($_userid);
		$db->execute('INSERT INTO `logs` VALUES (\'\', '. $userid .', \''. $log .'\', '. time() .', 0, 0, 0);');
		$db->execute('UPDATE `users` SET `logs` = `logs` + 1 WHERE (`userid` = '. $userid .') LIMIT 1;');
		return true;
	}
	public function levelcheck(/*$_userid = 0*/) {
		global $db;
			//$userid = /*($_userid == 0) ?*/ $this->userid /*: intval($_userid)*/;
		$bar = $db->obj($db->execute('SELECT `exp`, `maxexp` FROM `user_bars` WHERE (`userid` = '. $this->userid .') LIMIT 1;'));
		if($bar->exp >= $bar->maxexp) {
			$newexp = ($bar->maxexp == 250) ? 500 : $bar->maxexp+500;
			$db->execute('UPDATE `user_bars` SET `energy` = `maxenergy` + 5, `maxenergy` = `maxenergy` + 5, `audacity` = `maxaudacity` + 10, `maxaudacity` = `maxaudacity` + 10, `health` = `maxhealth` + 50, `maxhealth` = `maxhealth` + 50, `exp` = 0, `maxexp` = '. $maxexp .' WHERE (`userid` = '. $this->userid .') LIMIT 1;');
			$db->execute('UPDATE `users` SET `level` = `level` +1 WHERE (`userid` = '. $this->userid .') LIMIT 1;');
			$this->logger('You have gained a level, well done.');
		}
}
}
class vital {
	//var $userid;
	public function __construct($userid) {
		global $db;
		$this->userid =  intval($userid); //parent::$userid;
			$user = $db->execute('SELECT * FROM `user_bars` WHERE (`userid` = '. $this->userid .');');
			$users = $db->obj($user);
			foreach($users as $key => $value) {
				if(is_string($key)) {
				$this->$key = $value;
				}
			}
	}
}