<?php

define('host', 'localhost');
define('name', 'danielha');
define('pass', '{d}FTHx:$vwx');
define('db', 'danielha_crystalized');

?>