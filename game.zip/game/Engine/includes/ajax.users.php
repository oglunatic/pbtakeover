<?php
if(!defined('USERS')) {
    define('USERS', '');
}

class user {
    public function init($userid) { global $db;
        $this->userid = intval($userid);
        $user = $db->obj($db->execute('SELECT `userid`, `username`'.USERS.' FROM `users` WHERE (`userid` = '. $userid .');'));
            foreach($user as $key => $value) {
                is_string($key) ? $this->$key = $value : false;
            }
    }
    public function profile($_userid = 0, $link = true, $addid = true, $profile = false) { global $db;
            $user = $db->obj($db->execute('SELECT `username` FROM `users` WHERE (`userid` = '. $_userid .');'));
		$output = ($link == true) ? '<a href="profile.php?ID='. $_userid .'">' : '';
		$output .= ($profile == true) ? ucwords($user->username) .'\'s Profile.' : ucwords($user->username);
		$output .= ($addid == true) ? ' ['. number_format($_userid) .']' : '';
		$output .= ($link == true) ? '</a>' : '';
	return $output;
    }
}
    function access($access = false) {
	switch($access) {
	    case 'a' : return 'Administrator'; break;
	    case 'm' : return 'User Moderator'; break;
	    case 'h' : return 'Helper'; break;
	    case 'f' : return 'Fourm Moderator'; break;
	    case 'n' : return 'Member'; break;
	    default: return 'Member'; break;
	}
    }
function format($number = 0, $currency = false) {
return (($currency == false) ? number_format($number) : $currency.number_format($number));
}
function worktime( $seconds ) {
	$time = intval($seconds);
if($time < 60) {
	return $time .' seconds';
} else if($time/60 < 60) {
	return $time/60 .' minutes';
} else if($time/(60*60) < 60) {
	return $time/(60*60) .' hours';
} else if($time/(60*60*24)) {
	return $time/(60*60*24) .' days';
} else if($time/(60*60*24*364)) {
	return $time/(60*60*24*365) .' years';
} else {
	return $time .' seconds';
}
}