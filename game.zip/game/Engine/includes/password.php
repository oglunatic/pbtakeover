<?php

class password {
/*
	Syntax;
		$chars -> How long the salt should be (Default 7)
	Useage;
		newsalt(); // auto create a salt 7 chars long
		newsalt($number) //auto create a salt a defined length
*/
	public function newsalt($chars = 7) {
		$characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
		$code = '';
		for($i = 0; $i < $chars; $i++) {
			$code .= substr($characters, mt_rand(0, strlen($characters)-1), 1);
		}
		return $code;
	}

/*
	Syntax;
		$pass -> The password that the user selected
		$mail -> The email address of the user
		$salt -> The users salt (Created each time the pass is changed)
	Useage;
		newpass('mypass123', $user->email, newsalt()); // Created a new password using the input figures
*/
	function newpass($pass, $mail, $salt) {
		return hash('whirlpool', hash('md5',$pass.$salt).$mail);
	}
}
?>