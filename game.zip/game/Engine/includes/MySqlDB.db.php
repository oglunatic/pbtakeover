<?php
//PHP MySqlDB class
//Created by Daniel Hanson for RelaxDev Engine
class MySqlDB
    { 
        private  $link;
	private  $lastq;

        public function __construct($server, $user, $pass, $db) { 
            $this->link = mysql_connect($server, $user, $pass) or die(mysql_error());
		$this->execute('USE `'. $db .'`;');
        }

        public function errno() { 
            return mysql_errno($this->link); 
        }

        public function error() { 
            return mysql_error($this->link); 
        }

        public static function clean($string) { 
            return htmlentities(mysql_real_escape_string($string)); 
        }

	public static function dirty($string) {
		return html_entity_decode(stripslashes($string));
	}

        public function execute($query) {
	    $this->lastq = mysql_query($query, $this->link) or die(mysql_error());
            return $this->lastq;
        }

	public function query($query) {
		return $this->execute($query);
	}

	public function obj($query) {
	    if(!$query || empty($query)) {
		$query = $this->lastq;
	    }
	    return mysql_fetch_object($query);
	}

	public function single($query) {
	    if(!$query || empty($query)) {
		$query = $this->lastq;
	    }
	    return mysql_result($query, 0, 0);
	}

	public function affected_rows() {
	    return mysql_affected_rows($this->link);
	}

        public function num_rows($result) {
		if(empty($result)) {
		    $result = $this->lastq;
		}
            return mysql_num_rows($result); 
        }

        public function close()  { 
            return mysql_close($this->link); 
        }
    }