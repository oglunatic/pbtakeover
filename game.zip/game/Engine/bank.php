<?php
define('EXTRAUSERS', ', `bank`');
define('title', 'Bank', true);
require_once('./system.php');
/*////////////////////////////////////
 * Bank setting can be edited on the caler page
 * Found in the lib folder
 * They are below :)
*/////////////////////////////////////
define('cost', 1000, true); //open bank cost (half is put in account if set) default set at $10,000
define('dep_fee', 10, true); //deposit fee in % default set 10%
addjquery();
addupdater();
?>
<script type="text/javascript">
function newbank() {
try {
    $.get('lib/bank.caller.php?cmd=open', function(data) {
        update(data, 'bank');
    })
} catch(err) {
    alert(err)
}
}
function deposit() {
try {
    var money = $('#deposit').val()
    $.get('lib/bank.caller.php?cmd=deposit&money=' + money, function(data) {
        update(data, 'bank')
    })
} catch(err) {
    alert(err)
}
}
function withdraw() {
try {
    var money = $('#withdraw').val()
    $.get('lib/bank.caller.php?cmd=withdraw&money=' + money, function(data) {
      update(data, 'bank')  
    })
} catch(err) {
    alert(err)
}
}
</script>
<?php

echo'<div id="bank"></div>';
    if($user->bank < 0) {
        echo'You currently dont have a bank. You are able to open one for only '. format( cost , $setting['currency']) .'.<br /><big style="font-weight: bold;"><a href="javascript: newbank();">Open an account now!</a></big>';
            exit($template->endtemplate());
    }
	echo'<table width="100%" class="table" align="center">
			<tr>
				<th width="50%">Deposit</th>
				<th width="50%">Widthdraw</th>
			</tr>
			<tr>
				<td>There is a '. dep_fee .'% charge on depostiting money.<br /><br /><form action="javascript: deposit();"><input id="deposit" value="'. $user->money .'" /><br /><input type="submit" value="Deposit" /></form></td>
				<td>There is no fee on withdrawing money.<br /><br /><form action="javascript: withdraw();"><input id="withdraw" name="withdraw" value="'. $user->bank .'" /><br /><input type="submit" value="Withdraw" /></form></td>
			</tr>
		</table>';
$template->endtemplate();
?>