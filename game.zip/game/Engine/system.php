<?php
//To measure time for page load
$time = microtime();
$time = explode(" ", $time);
$time = $time[1] + $time[0];
$start = $time;
// Start session
session_start();
ob_start();
//Check if its in a page
if(!defined('title')) {
	echo'No direct access granted';
	exit();
}
//Get settings
require_once(dirname(__file__) .'/includes/game.setting.php');
//Get some vars
$userid = (isset($_SESSION['userid'])) ? intval($_SESSION['userid']) : ( (isset($_COOKIE['userid'])) ? intval($_COOKIE['userid']) : header('Location: login.php'));
$tempid = (isset($_COOKIE['template'])) ? intval($_COOKIE['template']) : $setting['template'];
	//Start the DB
		require_once(dirname(__file__) .'/includes/'. $setting['querydriver'] .'.db.php');
		require_once(dirname(__file__) .'/includes/settings.db.php');
			$db = new $setting['querydriver'](host, name, pass, db); //make the connection
	//Get the user
		require_once(dirname(__file__) .'/includes/users.php');
	$user = new users($userid);
	//Get the energy etc
	$vital = new vital($userid);
	//Does the user need to be verified as human?
	if((defined('capatcha')  || defined('refer'))) {
		if(!isset($_SESSION['verified']) || $_SESSION['verified'] <= (time()-60*15)) {
			$refer = defined('refer') ? refer : urlencode($_SERVER['SCRIPT_NAME']);
			header('Location: verify.php?cont='. $refer);
		}
	}
	//Get base functions
	require_once(dirname(__file__) .'/lib/functions.php');
	//*run basic user checks*/
		(defined('staffmenu') || defined('adminmenu')) ? null : verifycheck();
		$user->levelcheck();
		workcheck();
                //bannedcheck();

	//Now that we know they dont need to verify, set the laston
	$db->execute('UPDATE `users` SET `laston` = '. time() .' WHERE (`userid` = '. $userid .');');
	//Get template system
	require_once(dirname(__file__) .'/themes/template.index.php');
	//Start template and set header
	$template = new template($tempid);
            $template->template_init();