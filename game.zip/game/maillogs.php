<?php
 
 include(__DIR__.'/header.php');
 
if ($user_class->admin != 1) {
  echo Message("You are not authorized to be here.");
  include(__DIR__.'/footer.php');
  die();
}
 
?>
 
<tr><td class="contenthead">Staff Logs</td></tr>
<tr><td class="contentcontent">
    <?php
    $result = mysql_query("SELECT * FROM `pms` ORDER BY id DESC LIMIT 50");
    echo "<table width=100%>
                <tr align='center'>
                        
                        <td class=contenthead><b>Time</b></td>
                        <td class=contenthead><b>To</b></td>
                        <td class=contenthead><b>From</b></td>
                        <td class=contenthead><b>Text</b></td>
                </tr>";
    while($line = mysql_fetch_array($result, MYSQL_ASSOC)) {
        $usr = new User($line['to']);
        $usr2 = new User($line['from']);
        
        
        
        echo "<tr align=center>
                
                <td class=contentcontent>".date(F." ".d.", ".Y." ".g.":".i.":".sa,$line['timesent'])."</td>
                 <td class=contentcontent>".$line['to']."</td>
                <td class=contentcontent><a href=profiles.php?id=".$line['from'].">".$usr2->formattedname."</a></td>
                <td class=contentcontent>".$line['msgtext']."</td>
              </tr>";
    }
    echo "</table>";
    include(__DIR__.'/footer.php');
?>