<?php
include 'header.php';
 
 
if(isset($_GET['buy'])){
 
if($_GET['buy'] > 3){
    echo Message("That point pack doesn't exist.");
    include 'footer.php';
    die();
}
 
if($_GET['buy'] == '1'){
 
    //take costs
    $cost = 1000000;
    if($user_class->money < $cost){
        echo Message("Not enough money");
        include 'footer.php';
        die();
    }else{
    $newmoney = $user_class->money - $cost;
    $take = "UPDATE grpgusers SET money='".$newmoney."' WHERE id='".$user_class->id."'";
    mysql_query($take);
     
    //give pts
    $newpoints = $user_class->points + 100;
    $give = "UPDATE grpgusers SET points='".$newpoints."' WHERE id='".$user_class->id."'";
    mysql_query($give);
     
    echo Message("You bought the 100 points pack. <a href=pointdealer.php>back</a>");
    }
     
}
 
if($_GET['buy'] == '2'){
 
    //take costs
    $cost = 7200000;
    if($user_class->money < $cost){
        echo Message("Not enough money");
        include 'footer.php';
        die();
    }else{
    $newmoney = $user_class->money - $cost;
    $take = "UPDATE grpgusers SET money='".$newmoney."' WHERE id='".$user_class->id."'";
    mysql_query($take);
     
    //give pts
    $newpoints = $user_class->points + 750;
    $give = "UPDATE grpgusers SET points='".$newpoints."' WHERE id='".$user_class->id."'";
    mysql_query($give);
     
    echo Message("You bought the 750 points pack. <a href=pointdealer.php>back</a>");
    }
     
}
 
if($_GET['buy'] == '3'){
 
    //take costs
    $cost = 9500000;
    if($user_class->money < $cost){
        echo Message("Not enough money");
        include 'footer.php';
        die();
    }else{
    $newmoney = $user_class->money - $cost;
    $take = "UPDATE grpgusers SET money='".$newmoney."' WHERE id='".$user_class->id."'";
    mysql_query($take);
     
    //give pts
    $newpoints = $user_class->points + 1000;
    $give = "UPDATE grpgusers SET points='".$newpoints."' WHERE id='".$user_class->id."'";
    mysql_query($give);
     
    echo Message("You bought the 1000 points pack. <a href=pointdealer.php>back</a>");
    }
     
}
}
?>
 
<tr><td class="contenthead">Point Dealer</td></tr>
<tr><td class="contentcontent">Here you can purchase point packs if you are low on points.<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td><strong>Points</strong></td>
    <td><strong>Price</strong></td>
    <td><strong>Action</strong></td>
  </tr>
  <tr>
    <td>100</td>
    <td>$1,000,000</td>
    <td><a href="pointdealer.php?buy=1">Buy</a></td>
  </tr>
  <tr>
    <td>750</td>
    <td>$7,200,000</td>
    <td><a href="pointdealer.php?buy=2">Buy</a></td>
  </tr>
  <tr>
    <td>1,000</td>
    <td>$9,500,000</td>
    <td><a href="pointdealer.php?buy=3">Buy</a></td>
  </tr>
</table>
</td></tr>
 
<?php
include 'footer.php';
?>